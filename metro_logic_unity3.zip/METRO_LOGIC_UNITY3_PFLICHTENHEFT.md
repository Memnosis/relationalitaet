# METRO_LOGIC_UNITY2_PFLICHTENHEFT

## Pflichtblöcke
- Daten: Vollständige Kernregister
- UI: Browser- und Inspector-Zugriffe auf alle Kernregister
- API: Validierung, Atomzustände, SM-Kanäle, Partikel und Payload abrufbar
- Qualität: Completeness Guard, Function-Test-Matrix, Release-Hygiene
- Forschung: Formeln, QC-Labels, Forschungsfragen und Datenlücken sichtbar
