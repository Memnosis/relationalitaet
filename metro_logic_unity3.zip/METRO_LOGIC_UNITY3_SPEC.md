# METRO_LOGIC_UNITY2_SPEC

Unity2 finalisiert die stabile Basis von metro_logic_unity1. Kernziele sind vollständige Kernregister, maximale Testkontrolle, klare Trennung von Referenzdaten und relationalen Hypothesen sowie ein release-tauglicher, sauberer Hauptstand.

## Kernumfang
- 118 Elemente
- 118 Isotope
- 118 Atomaufbau-Einträge
- 4 offizielle SM-Sektoren
- 26 SM-Referenzparameter
- 26 modellierte Interaktionskanäle
- Partikel- und Hilfsobjekt-Register
- sichtbare Formelpfade mit LaTeX
- Vollständigkeits- und Validierungsberichte
