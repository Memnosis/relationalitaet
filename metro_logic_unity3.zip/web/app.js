
const state = {
  payload: null,
  language: localStorage.getItem('metro_logic_unity2.language') || 'de',
  menu: 'explore',
  browserTab: 'elements',
  browserSelectionId: null,
  selectedNodeId: null,
  selectedEdgeId: null,
  dragNodeId: null,
  dragOffset: { x: 0, y: 0 },
  positionsDirty: false,
};

const COLORS = { relational_core:'#7dd3fc', observable:'#fde68a', chemistry:'#86efac', default:'#c4b5fd' };
const LABELS = {
  de: { explore:'Erkunden', physics:'Physik', chemistry:'Chemie', relational:'Relational', docs:'Doku', tests:'Tests',
        elements:'Elemente', isotopes:'Isotope', atom_states:'Atomzustände', forces:'Kräfte', sm26:'SM26', channels:'Kanäle', particles:'Teilchen', auxiliary:'Hilfsobjekte', node_sheets:'Knotenblätter', edge_formulas:'Kantenformeln', uploads:'Uploads', snippets:'Snippets', formulas:'Formeln', questions:'Fragen', docsTab:'Dokumente', testsTab:'Testfälle',
        next:'Nächste Schritte', browserEmpty:'Kein Eintrag vorhanden.', linked:'Verknüpfte Relationen', quality:'Qualität', details:'Details', formulasTitle:'Formelpfade', source:'Quelle', testsTitle:'Tests', docsTitle:'Dokumente', uploadTitle:'Bundle-Upload', uploadHelp:'JSON-Bundle laden, Vorschau prüfen und lokal in die Workbench einblenden.', uploadImported:'Importiert', uploadSchema:'Schema' },
  en: { explore:'Explore', physics:'Physics', chemistry:'Chemistry', relational:'Relational', docs:'Docs', tests:'Tests',
        elements:'Elements', isotopes:'Isotopes', atom_states:'Atom states', forces:'Forces', sm26:'SM26', channels:'Channels', particles:'Particles', auxiliary:'Auxiliary', node_sheets:'Node sheets', edge_formulas:'Edge formulas', uploads:'Uploads', snippets:'Snippets', formulas:'Formulas', questions:'Questions', docsTab:'Documents', testsTab:'Tests',
        next:'Next steps', browserEmpty:'No entry available.', linked:'Linked relations', quality:'Quality', details:'Details', formulasTitle:'Formula paths', source:'Source', testsTitle:'Tests', docsTitle:'Docs', uploadTitle:'Bundle upload', uploadHelp:'Load a JSON bundle, inspect the preview, and overlay it in the workbench.', uploadImported:'Imported', uploadSchema:'Schema' }
};

function t(key){ return (LABELS[state.language] && LABELS[state.language][key]) || key; }
function pickText(item, deKeys=['name_de','title_de','summary_de','description_de'], enKeys=['name_en','title_en','summary_en','description_en']) {
  const search = state.language === 'de' ? deKeys : enKeys;
  const fallback = state.language === 'de' ? enKeys : deKeys;
  for (const key of [...search, 'label', 'name', 'title']) if (item && item[key]) return String(item[key]);
  for (const key of fallback) if (item && item[key]) return String(item[key]);
  return '';
}

async function loadPayload() {
  const response = await fetch('data/workbench_payload.json');
  state.payload = await response.json();
  state.language = state.payload.metadata.default_language || state.language;
  document.getElementById('languageSelect').value = state.language;
  initViewSelect();
  const firstTab = state.payload.ui?.browser_tabs?.[0] || 'elements';
  state.browserTab = firstTab;
  state.browserSelectionId = (state.payload.browser_datasets[firstTab]||[])[0]?.id || null;
  renderAll();
}

function initViewSelect() {
  const select = document.getElementById('viewSelect');
  select.innerHTML = '';
  const views = Object.entries(state.payload.canvas.available_views || { core_relational_map: 'Core relational map' });
  views.forEach(([id, label]) => {
    const option = document.createElement('option'); option.value = id; option.textContent = label; select.appendChild(option);
  });
  select.value = state.payload.canvas.view_id || views[0]?.[0] || 'core_relational_map';
}

function renderAll(){ renderHeader(); renderMenu(); renderSidebarLists(); renderBrowserTabs(); renderBrowser(); renderCanvas(); renderInspector(); renderFooter(); }

function renderHeader(){
  document.getElementById('title').textContent = state.payload.metadata.app_name;
  document.getElementById('subtitle').textContent = state.language === 'de' ? 'Browser-first Forschung mit Upload-Bundles für Knotenblätter, Kantenformeln und relationale Modelle' : 'Browser-first research with upload bundles for node sheets, edge formulas, and relational models';
  const exp = state.payload.menu_explanations[state.menu] || {de:'', en:''};
  document.getElementById('headerHeadline').textContent = `${t(state.menu)} · ${state.payload.metadata.app_slug || ''}`;
  document.getElementById('headerExplanation').textContent = exp[state.language] || exp.de || '';
  const next = (state.payload.research_program?.recommended_next_steps || []).slice(0,3).join(' · ');
  document.getElementById('headerNext').textContent = `${t('next')}: ${next}`;
  const inv = state.payload.dataset_inventory;
  const uploadCount = (state.payload.upload_support?.bundles || []).length;
  document.getElementById('inventoryPill').textContent = `elements ${inv.elements} · isotopes ${inv.isotopes} · formulas ${inv.formulas} · uploads ${uploadCount}`;
  document.getElementById('qualityPill').textContent = `QC ${state.payload.scientific_analysis.summary.official_relations} official · ${state.payload.scientific_analysis.summary.relational_recalculation_required} relational recalc`;
  document.getElementById('researchPill').textContent = `questions ${state.payload.scientific_analysis.summary.total_questions} · blocked ${state.payload.scientific_analysis.summary.blocked_questions}`;
}

function renderMenu(){
  const menu = document.getElementById('menu'); menu.innerHTML='';
  const groups = state.payload.menu_groups || { core:['explore','physics','chemistry'], research:['relational','tests'], support:['docs'] };
  Object.entries(groups).forEach(([group, items]) => {
    const wrap = document.createElement('div'); wrap.className='group-wrap';
    const label = document.createElement('div'); label.className='muted'; label.style.fontSize='.8rem'; label.style.padding='2px 2px 6px'; label.textContent = group;
    wrap.appendChild(label);
    items.forEach(id => {
      const btn = document.createElement('button');
      btn.className = state.menu === id ? 'active' : '';
      btn.innerHTML = `<strong>${t(id)}</strong><span class="tiny">${(state.payload.menu_explanations[id]?.[state.language] || '').slice(0,72)}</span>`;
      btn.onclick = () => { state.menu = id; renderAll(); };
      wrap.appendChild(btn);
    });
    menu.appendChild(wrap);
  });
}

function renderSidebarLists(){
  fillButtonList('tourList', (state.payload.tours||[]).map(item => ({label: pickText(item,['title_de'],['title_en']) || item.id, summary: (item.steps||[]).length + ' steps', onclick: ()=>selectBrowserPseudo('questions')})));
  fillButtonList('testList', (state.payload.tests.items||[]).slice(0,8).map(item => ({label:item.id, summary:item.category, onclick:()=>{state.menu='tests'; renderAll();}})));
  const helpItems = [
    {label: t('uploadTitle'), summary: t('uploadHelp')},
    {label: state.language==='de' ? 'Canvas nutzen' : 'Use the canvas', summary: state.language==='de' ? 'Ziehen, klicken, hovern, Layout speichern.' : 'Drag, click, hover, save layout.'},
    {label: state.language==='de' ? 'Browser nutzen' : 'Use the browser', summary: state.language==='de' ? 'Tabs filtern die Datensicht und öffnen Details.' : 'Tabs filter the dataset view and open details.'},
    {label: state.language==='de' ? 'Qualität lesen' : 'Read quality labels', summary: 'official_reference / partial_registry / relational_hypothesis'},
    {label: state.language==='de' ? 'Tests & Doku' : 'Tests & docs', summary: state.language==='de' ? 'Über die Menüs jederzeit erreichbar.' : 'Always reachable from the menus.'}
  ];
  fillButtonList('helpList', helpItems);
}

function fillButtonList(id, items){
  const el = document.getElementById(id); el.innerHTML='';
  items.forEach(item => {
    const btn = document.createElement('button'); btn.className='side-link'; btn.innerHTML = `<strong>${item.label}</strong><div class="muted">${item.summary||''}</div>`;
    btn.onclick = item.onclick || null; el.appendChild(btn);
  });
}

function selectBrowserPseudo(tab){ state.browserTab = tab; state.browserSelectionId = state.payload.browser_datasets[tab]?.[0]?.id || null; renderBrowser(); renderInspector(); }

function renderBrowserTabs(){
  const wrap = document.getElementById('browserTabs'); wrap.innerHTML='';
  (state.payload.ui.browser_tabs || []).forEach(tab => {
    const btn = document.createElement('button'); btn.className = state.browserTab===tab ? 'active' : '';
    btn.textContent = t(tab==='docs'?'docsTab':tab==='tests'?'testsTab':tab);
    btn.onclick = ()=>{state.browserTab=tab; state.browserSelectionId = state.payload.browser_datasets[tab]?.[0]?.id || null; renderBrowser(); renderInspector();};
    wrap.appendChild(btn);
  });
}

function currentBrowserItems(){
  let items = state.payload.browser_datasets[state.browserTab] || [];
  const q = (document.getElementById('searchInput').value || '').trim().toLowerCase();
  if (q) items = items.filter(item => JSON.stringify(item).toLowerCase().includes(q));
  if (state.menu === 'physics' && ['elements','isotopes'].includes(state.browserTab)) return [];
  if (state.menu === 'chemistry' && ['forces','questions'].includes(state.browserTab)) return items.slice(0,20);
  return items;
}

function renderBrowser(){
  const list = document.getElementById('browserList'); const detail = document.getElementById('browserDetail');
  list.innerHTML='';
  const items = currentBrowserItems();
  if (!items.length){ list.innerHTML = `<div class="muted">${t('browserEmpty')}</div>`; detail.innerHTML=''; return; }
  items.slice(0,200).forEach(item => {
    const btn = document.createElement('button'); btn.className = state.browserSelectionId===item.id ? 'active' : '';
    btn.innerHTML = `<strong>${item.label || pickText(item)}</strong><div class="muted">${pickText(item,['summary_de'],['summary_en']).slice(0,80)}</div>`;
    btn.onclick = ()=>{ state.browserSelectionId=item.id; renderBrowser(); renderInspector(); };
    list.appendChild(btn);
  });
  const chosen = items.find(item => item.id === state.browserSelectionId) || items[0];
  state.browserSelectionId = chosen.id;
  const details = chosen.details || chosen;
  detail.innerHTML = `<h3>${chosen.label || pickText(chosen)}</h3>
    <div class="meta">${pickText(chosen,['summary_de'],['summary_en'])}</div>
    <div class="chips">${Object.keys(details).slice(0,8).map(key => `<span class="chip" title="${escapeHtml(String(details[key]))}">${escapeHtml(key)}</span>`).join('')}</div>
    <div style="height:10px"></div>
    <div class="kv">${Object.entries(details).slice(0,16).map(([k,v]) => `<strong>${escapeHtml(k)}</strong><div title="${escapeHtml(typeof v==='object'?JSON.stringify(v):String(v))}">${escapeHtml(typeof v==='object' ? JSON.stringify(v).slice(0,300) : String(v).slice(0,300))}</div>`).join('')}</div>`;
}

function visibleNodes(){
  let nodes = [...state.payload.canvas.nodes];
  const q = (document.getElementById('searchInput').value || '').trim().toLowerCase();
  if (q) nodes = nodes.filter(n => JSON.stringify(n).toLowerCase().includes(q));
  if (state.menu === 'physics') nodes = nodes.filter(n => ['observable','relational_core'].includes(n.category) || /force|interaction|w|z|photon|gluon/i.test(n.label));
  if (state.menu === 'chemistry') nodes = nodes.filter(n => /atom|chem|electron|binding|periodic/i.test(JSON.stringify(n)) || n.category==='chemistry');
  if (state.menu === 'relational') nodes = nodes.filter(n => n.quality_label==='relational_hypothesis' || n.category==='relational_core');
  return nodes;
}
function visibleEdges(nodes){ const ids = new Set(nodes.map(n=>n.id)); return state.payload.canvas.edges.filter(e => ids.has(e.source) && ids.has(e.target)); }
function edgePath(source,target){ const sx=source.x+220, sy=source.y+34, tx=target.x, ty=target.y+34; const c=(tx-sx)*0.35; return `M ${sx} ${sy} C ${sx+c} ${sy}, ${tx-c} ${ty}, ${tx} ${ty}`; }

function renderCanvas(){
  const svg = document.getElementById('canvas'); const minimap = document.getElementById('minimap'); svg.innerHTML=''; minimap.innerHTML='';
  const nodes = visibleNodes(); const edges = visibleEdges(nodes); const nodeIndex = Object.fromEntries(nodes.map(n=>[n.id,n]));
  // groups
  const groupMap = {}; nodes.forEach(n=>{ const g=n.category||'default'; (groupMap[g]=groupMap[g]||[]).push(n); });
  Object.entries(groupMap).forEach(([group,items])=>{ if(items.length<2) return; const xs=items.map(n=>n.x), ys=items.map(n=>n.y); const rect=document.createElementNS('http://www.w3.org/2000/svg','rect'); rect.setAttribute('x',Math.min(...xs)-20); rect.setAttribute('y',Math.min(...ys)-20); rect.setAttribute('width',Math.max(...xs)-Math.min(...xs)+260); rect.setAttribute('height',Math.max(...ys)-Math.min(...ys)+110); rect.setAttribute('rx',24); rect.setAttribute('class','group-box'); svg.appendChild(rect); const label=document.createElementNS('http://www.w3.org/2000/svg','text'); label.setAttribute('x',Math.min(...xs)-8); label.setAttribute('y',Math.min(...ys)-4); label.setAttribute('fill','#a8b7d6'); label.setAttribute('font-size','12'); label.textContent=group; svg.appendChild(label); });
  edges.forEach(edge=>{ const source=nodeIndex[edge.source], target=nodeIndex[edge.target]; if(!source||!target) return; const path=document.createElementNS('http://www.w3.org/2000/svg','path'); path.setAttribute('class','edge'); path.setAttribute('d',edgePath(source,target)); path.onclick=()=>{state.selectedEdgeId=edge.id; state.selectedNodeId=null; renderInspector(); renderCanvas();}; path.onmousemove=(evt)=>showTooltip(evt, `<strong>${escapeHtml(edge.label||edge.relation_type)}</strong><br>${escapeHtml(pickEdgeText(edge))}`); path.onmouseleave=hideTooltip; svg.appendChild(path); const text=document.createElementNS('http://www.w3.org/2000/svg','text'); text.setAttribute('class','edge-label'); text.setAttribute('x',(source.x+target.x)/2+40); text.setAttribute('y',(source.y+target.y)/2+16); text.textContent=edge.label || edge.relation_type; svg.appendChild(text); });
  nodes.forEach(node=>{ const g=document.createElementNS('http://www.w3.org/2000/svg','g'); g.setAttribute('class',`node${state.selectedNodeId===node.id?' active':''}`); g.setAttribute('transform',`translate(${node.x}, ${node.y})`); const rect=document.createElementNS('http://www.w3.org/2000/svg','rect'); rect.setAttribute('width',220); rect.setAttribute('height',68); rect.setAttribute('stroke',COLORS[node.category]||COLORS.default); const t1=document.createElementNS('http://www.w3.org/2000/svg','text'); t1.setAttribute('x',14); t1.setAttribute('y',26); t1.setAttribute('font-size','16'); t1.setAttribute('font-weight','700'); t1.textContent=node.label; const t2=document.createElementNS('http://www.w3.org/2000/svg','text'); t2.setAttribute('x',14); t2.setAttribute('y',48); t2.setAttribute('font-size','12'); t2.setAttribute('fill','#a8b7d6'); t2.textContent=pickNodeText(node).slice(0,36); g.append(rect,t1,t2); g.onmousedown=(evt)=>beginDrag(evt,node.id); g.onclick=(evt)=>{evt.stopPropagation(); state.selectedNodeId=node.id; state.selectedEdgeId=null; renderInspector(); renderCanvas();}; g.onmousemove=(evt)=>showTooltip(evt, `<strong>${escapeHtml(node.label)}</strong><br>${escapeHtml(pickNodeText(node))}<br><em>${escapeHtml(node.quality_label||'')}</em>`); g.onmouseleave=hideTooltip; svg.appendChild(g); });
  nodes.forEach(node=>{ const circle=document.createElementNS('http://www.w3.org/2000/svg','circle'); circle.setAttribute('cx',node.x/8+10); circle.setAttribute('cy',node.y/8+10); circle.setAttribute('r',4); circle.setAttribute('fill',COLORS[node.category]||COLORS.default); minimap.appendChild(circle); });
  svg.onclick=()=>{state.selectedNodeId=null; state.selectedEdgeId=null; renderInspector(); renderCanvas();};
  document.getElementById('viewStat').textContent = `${state.payload.canvas.view_id || 'view'} · ${state.menu}`;
  document.getElementById('nodeStat').textContent = `nodes ${nodes.length}`;
  document.getElementById('edgeStat').textContent = `edges ${edges.length}`;
  document.getElementById('gapStat').textContent = `gaps ${state.payload.scientific_analysis.summary.blocked_questions}`;
}
function pickNodeText(node){ return state.language==='de' ? (node.short_info_de||node.long_info_de||node.short_info_en||'') : (node.short_info_en||node.long_info_en||node.short_info_de||''); }
function pickEdgeText(edge){ return state.language==='de' ? (edge.short_info_de||edge.short_info_en||'') : (edge.short_info_en||edge.short_info_de||''); }

function uploadCardHtml(){ const uploads = state.payload.upload_support?.bundles || []; const schema = state.payload.upload_support?.schema || {}; return `<div class="card"><h3>${t('uploadTitle')}</h3><p class="muted">${t('uploadHelp')}</p><input id="bundleFile" type="file" accept="application/json" /><div class="toolbar" style="margin-top:10px"><button id="showSchemaBtn">${t('uploadSchema')}</button></div><div class="card-list">${uploads.map(u=>`<div class="card-mini"><strong>${escapeHtml(u.title||u.bundle_id)}</strong><div class="muted">${t('uploadImported')}: ${escapeHtml(u.bundle_id)}</div><div class="muted">node sheets ${u.node_datasheets||0} · edge formulas ${u.edge_formulas||0}</div></div>`).join('')}</div><div id="uploadPreview" class="code" style="margin-top:10px">${escapeHtml(JSON.stringify(schema, null, 2).slice(0,600))}</div></div>`; }

function renderInspector(){
  const inspector = document.getElementById('inspector');
  const browserItems = state.payload.browser_datasets[state.browserTab] || [];
  const browserChosen = browserItems.find(item => item.id === state.browserSelectionId) || browserItems[0];
  if (state.menu === 'tests') { inspector.innerHTML = testsCardHtml(); return; }
  if (state.menu === 'docs') { inspector.innerHTML = docsCardHtml(); return; }
  if (state.browserTab === 'uploads') { inspector.innerHTML = uploadCardHtml(); attachUploadEvents(); return; }
  if (state.selectedEdgeId) {
    const edge = state.payload.canvas.edges.find(e => e.id === state.selectedEdgeId);
    const snippet = state.payload.snippets.find(s => s.snippet_id === edge.code_snippet_id);
    inspector.innerHTML = `<div class="card"><h3>${escapeHtml(edge.label || edge.relation_type)}</h3><p class="muted">${escapeHtml(pickEdgeText(edge))}</p><div class="chips"><span class="chip">${edge.source} → ${edge.target}</span><span class="chip">${edge.quality_label || 'partial_registry'}</span></div></div>${snippet?snippetCardHtml(snippet):''}${formulaCardsHtml()}`; return;
  }
  const node = state.payload.canvas.nodes.find(n => n.id === state.selectedNodeId) || state.payload.canvas.nodes[0];
  const linkedEdges = state.payload.canvas.edges.filter(e => e.source===node.id || e.target===node.id);
  const browserCard = browserChosen ? `<div class="card"><h3>${t('details')} · ${t(state.browserTab==='docs'?'docsTab':state.browserTab==='tests'?'testsTab':state.browserTab)}</h3><p class="muted">${escapeHtml(pickText(browserChosen,['summary_de'],['summary_en']))}</p><div class="kv">${Object.entries(browserChosen.details || browserChosen).slice(0,10).map(([k,v])=>`<strong>${escapeHtml(k)}</strong><div>${escapeHtml(typeof v==='object'?JSON.stringify(v).slice(0,180):String(v).slice(0,180))}</div>`).join('')}</div></div>` : '';
  inspector.innerHTML = `
    <div class="card"><h3>${escapeHtml(node.label)}</h3><p class="muted">${escapeHtml(state.language==='de' ? (node.long_info_de||node.short_info_de||'') : (node.long_info_en||node.short_info_en||''))}</p><div class="chips"><span class="chip">${escapeHtml(node.category||'')}</span><span class="chip">${escapeHtml(node.status||'')}</span><span class="chip">${escapeHtml(node.quality_label||'partial_registry')}</span></div></div>
    <div class="card"><h3>${t('linked')}</h3><div class="card-list">${linkedEdges.map(e=>`<div class="card-mini"><strong>${escapeHtml(e.label||e.relation_type)}</strong><div class="muted">${escapeHtml(e.source)} → ${escapeHtml(e.target)}</div></div>`).join('')}</div></div>
    ${browserCard}
    ${formulaCardsHtml(node.id)}
  `;
}
function testsCardHtml(){ const items=state.payload.tests.items||[]; return `<div class="card"><h3>${t('testsTitle')}</h3><p class="muted">${escapeHtml(state.payload.tests.how_to_run||'')}</p><div class="card-list">${items.map(i=>`<div class="card-mini"><strong>${escapeHtml(i.id)}</strong><div class="muted">${escapeHtml(i.category)} · ${escapeHtml(i.path)}</div></div>`).join('')}</div></div>`; }
function docsCardHtml(){ const groups=state.payload.docs_index||{}; return Object.entries(groups).map(([group,entries])=>`<div class="card"><h3>${escapeHtml(group)}</h3><div class="card-list">${entries.slice(0,12).map(d=>`<div class="card-mini"><strong>${escapeHtml(d.title)}</strong><div class="muted">${escapeHtml(d.path)}</div><div>${escapeHtml(d.preview||'')}</div></div>`).join('')}</div></div>`).join(''); }
function snippetCardHtml(snippet){ return `<div class="card"><h3>Code snippet</h3><div class="chips"><span class="chip">${escapeHtml(snippet.language||'')}</span><span class="chip">editable ${escapeHtml(String(snippet.editable))}</span></div><div class="code">${escapeHtml(snippet.code||'')}</div></div>`; }
function formulaCardsHtml(nodeId){
  let formulas = state.payload.formulas || [];
  if (nodeId) formulas = formulas.filter(f => (f.relation_ids||[]).some(r => String(r).toLowerCase().includes(String(nodeId).toLowerCase())));
  if (!formulas.length) formulas = state.payload.formulas.slice(0,4);
  return `<div class="card"><h3>${t('formulasTitle')}</h3><div class="card-list">${formulas.slice(0,6).map(f=>`<div class="card-mini"><strong>${escapeHtml(f.name)}</strong><div class="formula">${escapeHtml(f.latex||f.equation_latex||'')}</div><div class="chips"><span class="chip">${escapeHtml(f.status||'')}</span><span class="chip">inputs ${(f.inputs||[]).length}</span><span class="chip">outputs ${(f.outputs||[]).length}</span></div>${f.source_doc_id?`<div class="muted">${t('source')}: ${escapeHtml(f.source_doc_id)}</div>`:''}</div>`).join('')}</div></div>`;
}
function applyBundleOverlay(bundle){
  const nodeSheets = (bundle.node_datasheets||[]).map(item=>({id:`bundle-node-${bundle.metadata?.bundle_id||'local'}-${item.node_id}`, label:item.label||item.title_de||item.title_en||item.node_id, name_de:item.title_de||item.label||item.node_id, name_en:item.title_en||item.label||item.node_id, summary_de:item.summary_de||'', summary_en:item.summary_en||'', details:{...item, bundle_id:bundle.metadata?.bundle_id||'local'}}));
  const edgeFormulas = (bundle.edge_formulas||[]).map(item=>({id:`bundle-edge-${bundle.metadata?.bundle_id||'local'}-${item.formula_id}`, label:item.name||item.formula_id, name_de:item.name||item.formula_id, name_en:item.name||item.formula_id, summary_de:item.description_de||'', summary_en:item.description_en||'', details:{...item, bundle_id:bundle.metadata?.bundle_id||'local'}}));
  state.payload.browser_datasets.node_sheets = [...nodeSheets, ...(state.payload.browser_datasets.node_sheets||[])];
  state.payload.browser_datasets.edge_formulas = [...edgeFormulas, ...(state.payload.browser_datasets.edge_formulas||[])];
  state.payload.upload_support = state.payload.upload_support || {};
  state.payload.upload_support.bundles = [{bundle_id:bundle.metadata?.bundle_id||'local', title:bundle.metadata?.title||'Local bundle', node_datasheets:nodeSheets.length, edge_formulas:edgeFormulas.length}, ...(state.payload.upload_support.bundles||[])];
  renderBrowser(); renderInspector(); renderHeader();
}

function attachUploadEvents(){ const input=document.getElementById('bundleFile'); if(input&&!input.dataset.bound){ input.dataset.bound='1'; input.addEventListener('change', async evt=>{ const file=evt.target.files?.[0]; if(!file) return; const text=await file.text(); const bundle=JSON.parse(text); applyBundleOverlay(bundle); document.getElementById('uploadPreview').textContent = JSON.stringify(bundle, null, 2).slice(0,1600); }); } const schemaBtn=document.getElementById('showSchemaBtn'); if(schemaBtn&&!schemaBtn.dataset.bound){ schemaBtn.dataset.bound='1'; schemaBtn.addEventListener('click', ()=>{ document.getElementById('uploadPreview').textContent = JSON.stringify(state.payload.upload_support?.schema||{}, null, 2); }); } }

function renderFooter(){ document.getElementById('footerText').textContent = state.language==='de' ? 'Die Workbench trennt Referenzdaten, partielle Registries und relationale Hypothesen. Layout lokal speichern, um deinen Fokus im Canvas zu halten.' : 'The workbench separates reference data, partial registries, and relational hypotheses. Save the layout locally to keep your focus on the canvas.'; }

function beginDrag(evt,nodeId){ const node=state.payload.canvas.nodes.find(n=>n.id===nodeId); state.dragNodeId=nodeId; const point=svgPoint(evt); state.dragOffset={x:point.x-node.x,y:point.y-node.y}; window.addEventListener('mousemove',onDrag); window.addEventListener('mouseup',endDrag,{once:true}); }
function onDrag(evt){ if(!state.dragNodeId) return; const node=state.payload.canvas.nodes.find(n=>n.id===state.dragNodeId); const point=svgPoint(evt); node.x=Math.max(20,Math.min(1160,point.x-state.dragOffset.x)); node.y=Math.max(20,Math.min(720,point.y-state.dragOffset.y)); state.positionsDirty=true; renderCanvas(); }
function endDrag(){ state.dragNodeId=null; window.removeEventListener('mousemove',onDrag); }
function svgPoint(evt){ const svg=document.getElementById('canvas'); const pt=svg.createSVGPoint(); pt.x=evt.clientX; pt.y=evt.clientY; return pt.matrixTransform(svg.getScreenCTM().inverse()); }
function showTooltip(evt,html){ const t=document.getElementById('tooltip'); t.innerHTML=html; t.style.display='block'; t.style.left=(evt.offsetX+24)+'px'; t.style.top=(evt.offsetY+24)+'px'; }
function hideTooltip(){ document.getElementById('tooltip').style.display='none'; }
function escapeHtml(v){ return String(v ?? '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s])); }

function saveLayout(){ localStorage.setItem('metro_logic_unity2.layout', JSON.stringify(state.payload.canvas.nodes.map(({id,x,y})=>({id,x,y})))); state.positionsDirty=false; }
function loadLayout(){ const raw=localStorage.getItem('metro_logic_unity2.layout'); if(!raw) return; try{ const rows=JSON.parse(raw); rows.forEach(row=>{ const node=state.payload.canvas.nodes.find(n=>n.id===row.id); if(node){ node.x=row.x; node.y=row.y; } }); } catch(e){} }
function resetLayout(){ localStorage.removeItem('metro_logic_unity2.layout'); location.reload(); }

function attachEvents(){
  document.getElementById('searchInput').addEventListener('input', ()=>{ renderBrowser(); renderCanvas(); renderInspector(); });
  document.getElementById('languageSelect').addEventListener('change', evt => { state.language = evt.target.value; localStorage.setItem('metro_logic_unity2.language', state.language); renderAll(); });
  document.getElementById('saveLayoutBtn').addEventListener('click', saveLayout);
  document.getElementById('resetLayoutBtn').addEventListener('click', resetLayout);
}

loadPayload().then(()=>{ loadLayout(); attachEvents(); renderAll(); });
