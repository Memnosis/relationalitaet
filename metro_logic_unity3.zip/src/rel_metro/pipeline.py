from __future__ import annotations
"""Central orchestration pipeline.

The pipeline keeps three things stable: reproducible run artifacts, explicit dependency propagation,
and relation diagnostics that can be rerun whenever relation code changes.
"""
import json
from .config import merge_config
from .dependency import recompute_plan, graph_snapshot
from .logsystem import RunLogger
from .models_alpha import run_alpha
from .models_higgs import run_higgs
from .models_weinberg import run_weinberg
from .models_w import run_w
from .models_hierarchy import run_hierarchy
from .models_closure import run_closure
from .models_chemistry import run_chemistry
from .audit import build_audit
from .parameter_registry import load_parameter_registry
from .relation_engine import evaluate_all_relations, relation_test_suite
from .freedom import freedom_balance
from .research_core import research_summary

SECTORS = {'alpha': run_alpha, 'higgs': run_higgs, 'weinberg': run_weinberg, 'w': run_w, 'hierarchy': run_hierarchy, 'closure': run_closure, 'chemistry': run_chemistry}


def json_like_markdown(payload):
    return '# payload\n\n```json\n' + json.dumps(payload, ensure_ascii=False, indent=2) + '\n```\n'


def execute(profile_name='default_project', inline_overrides=None, active_reference_sets=None, run_relation_tests=False, run_research_suite=False):
    cfg = merge_config(profile_name, inline_overrides=inline_overrides, active_reference_sets=active_reference_sets)
    logger = RunLogger.create('rel_metro')
    logger.log('config', 'config_loaded', {'profile': profile_name, 'diff': cfg.diff, 'active_reference_sets': cfg.active_reference_sets})
    logger.write_json('meta/run_manifest.json', {'profile': profile_name, 'metadata': cfg.metadata})
    logger.write_json('meta/config_diff.json', cfg.diff)
    logger.write_json('inputs/values.json', cfg.values)
    logger.write_json('inputs/references.json', cfg.references)
    logger.write_json('inputs/parameter_catalog.json', load_parameter_registry())
    plan = recompute_plan(cfg.diff.keys())
    logger.write_json('meta/recompute_plan.json', plan)
    sector_payloads = {}
    flat_outputs = {}
    for sector_name, runner in SECTORS.items():
        logger.log('model', 'sector_start', {'sector': sector_name})
        payload = runner(cfg.values)
        sector_payloads[sector_name] = payload
        flat_outputs.update(payload.get('outputs', {}))
        logger.log('model', 'sector_done', {'sector': sector_name, 'outputs': payload.get('outputs', {})})
    dependency_report = {**plan, 'graph': graph_snapshot()}
    logger.write_json('outputs/results.json', {'sectors': sector_payloads, 'flat_outputs': flat_outputs})
    logger.write_json('outputs/dependency_analysis.json', dependency_report)
    audit = build_audit(flat_outputs, cfg.references)
    logger.write_json('outputs/audit.json', audit)
    metrics = {
        'exact_hit': sum(1 for rec in audit.values() if rec.get('status') == 'exact_hit'),
        'near_hit': sum(1 for rec in audit.values() if rec.get('status') == 'near_hit'),
        'tension': sum(1 for rec in audit.values() if rec.get('status') == 'tension'),
        'not_comparable': sum(1 for rec in audit.values() if rec.get('status') == 'not_comparable'),
    }
    logger.write_json('outputs/metrics.json', metrics)

    freedom = freedom_balance(flat_outputs, cfg.values)
    research = research_summary(cfg.values, flat_outputs)
    logger.write_json('outputs/freedom_balance.json', freedom)
    logger.write_json('outputs/research_summary.json', research)
    relation_results = evaluate_all_relations({**cfg.values, **flat_outputs})
    logger.write_json('outputs/relation_results.json', relation_results)
    relation_tests = {}
    if run_relation_tests:
        relation_tests = relation_test_suite(profile_name, layers=['official', 'relational_known', 'relational_assumed'])
        logger.write_json('outputs/relation_test_suite.json', relation_tests)
        logger.write_json('outputs/sensitivity_matrix.json', relation_tests.get('sensitivity_matrix', {}))
        logger.write_json('outputs/influence_matrix.json', relation_tests.get('influence_matrix', {}))
    summary = [
        '# rel_metro run summary',
        f'- profile: {profile_name}',
        f"- changed inputs: {', '.join(sorted(cfg.diff)) if cfg.diff else 'none'}",
        f"- active reference sets: {', '.join(cfg.active_reference_sets)}",
        f"- relation tests: {'enabled' if run_relation_tests else 'disabled'}",
        f"- research suite: {'enabled' if run_research_suite else 'disabled'}",
    ]
    logger.write_markdown('reports/summary.md', '\n'.join(summary) + '\n')
    logger.write_markdown('reports/recompute_overview.md', json_like_markdown(plan))
    logger.write_markdown('reports/relation_validation.md', json_like_markdown({'relations': list(relation_results.keys()), 'tests_enabled': run_relation_tests}))
    logger.write_markdown('reports/freedom_balance.md', json_like_markdown(freedom))
    logger.write_markdown('reports/research_summary.md', json_like_markdown(research))
    if run_relation_tests:
        logger.write_markdown('reports/sensitivity_summary.md', json_like_markdown(relation_tests.get('sensitivity_matrix', {})))
        logger.write_markdown('reports/influence_summary.md', json_like_markdown(relation_tests.get('influence_matrix', {})))

    research_suite = {}
    if run_research_suite:
        from .sm_relation_lab import combined_research_suite
        research_suite = combined_research_suite(profile_name, inline_overrides=inline_overrides, active_reference_sets=active_reference_sets)
        logger.write_json('outputs/research_suite.json', research_suite)
    return {
        'run_dir': str(logger.run_dir),
        'results': sector_payloads,
        'flat_outputs': flat_outputs,
        'audit': audit,
        'metrics': metrics,
        'dependency': dependency_report,
        'relation_results': relation_results,
        'freedom_balance': freedom,
        'research_summary': research,
        'relation_tests': relation_tests,
        'research_suite': research_suite,
        'config': {'profile_name': profile_name, 'diff': cfg.diff, 'active_reference_sets': cfg.active_reference_sets, 'values': cfg.values, 'references': cfg.references},
    }
