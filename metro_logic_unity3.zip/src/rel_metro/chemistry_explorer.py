
"""Explorer-facing helpers and graph preparation.

This module provides data structures suitable for GUI rendering: element lists,
isotope tables, trend cards and a lightweight dependency graph layout.
"""
from __future__ import annotations
import math
from .atom_registry import list_elements, list_isotopes, get_element
from .relation_registry import all_relations
from .atom_bridge import chemistry_observable_matrix, valence_bridge, classify_isotope_stability

def element_table_rows(z_min: int = 1, z_max: int = 86) -> list[dict]:
    return [
        {
            "Z": e["atomic_number"],
            "symbol": e["symbol"],
            "name_en": e["name_en"],
            "group": e["group"],
            "period": e["period"],
            "block": e["block"],
            "class": e["class"],
            "outer_electrons": e["outer_electrons"],
            "default_valence": e["default_valence"],
        }
        for e in list_elements()
        if z_min <= e["atomic_number"] <= z_max
    ]

def isotope_table_rows(symbol: str | None = None) -> list[dict]:
    isotopes = list_isotopes(symbol)
    rows = []
    for iso in isotopes:
        rows.append({
            "element": iso["element"],
            "A": iso["mass_number"],
            "N": iso["neutron_number"],
            "parity": iso["parity_class"],
            "score": iso["stability_rule_output"]["score"],
            "classification": iso["stability_rule_output"]["classification"],
        })
    return rows

def element_detail(symbol: str) -> dict:
    element = get_element(symbol)
    return {
        "element": element,
        "valence_bridge": valence_bridge(symbol),
        "isotope_stability": classify_isotope_stability(symbol),
    }

def dependency_graph_for_element(symbol: str) -> dict:
    element = get_element(symbol)
    base_nodes = ["atomic_number", "group", "period", "outer_electrons", "default_valence", "covalent_radius_pm", symbol]
    nodes = [{"id": node, "label": node} for node in base_nodes]
    edges = [
        {"source": "atomic_number", "target": symbol},
        {"source": symbol, "target": "group"},
        {"source": symbol, "target": "period"},
        {"source": symbol, "target": "outer_electrons"},
        {"source": symbol, "target": "default_valence"},
        {"source": symbol, "target": "covalent_radius_pm"},
    ]
    # circular layout for simple graphical explorer
    radius = 150
    positioned_nodes = []
    for idx, node in enumerate(nodes):
        angle = 2 * math.pi * idx / max(1, len(nodes))
        positioned_nodes.append({
            **node,
            "x": 220 + radius * math.cos(angle),
            "y": 220 + radius * math.sin(angle),
        })
    return {"element": symbol, "nodes": positioned_nodes, "edges": edges, "relations": all_relations()}

def observable_heatmap_data(z_min: int = 1, z_max: int = 20) -> dict:
    matrix = chemistry_observable_matrix(z_min=z_min, z_max=z_max)
    columns = ["outer_electrons", "default_valence", "covalent_radius_pm", "vdw_radius_pm", "atomic_weight"]
    return {"columns": columns, "rows": matrix["rows"], "metrics": matrix["metrics"]}
