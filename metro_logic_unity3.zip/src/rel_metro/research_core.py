
from __future__ import annotations
"""Research-core helpers for blocks A and B of master_final.

The purpose of this module is to expose assumption inventory, necessity probes,
and research-suite summaries in a reproducible and loggable form.
"""
import json
from pathlib import Path
from .relation_engine import compute_relational_w_explicit, compute_relational_w_inherited, compute_delta_alpha_only

ROOT = Path(__file__).resolve().parents[2]


def _load(name: str) -> dict:
    return json.loads((ROOT / 'configs' / name).read_text(encoding='utf-8'))


def load_assumptions() -> dict:
    return _load('assumption_registry.json')


def load_necessity_registry() -> dict:
    return _load('necessity_registry.json')


def necessity_report(values: dict, flat_outputs: dict) -> dict:
    delta = compute_delta_alpha_only(values)
    w_explicit = compute_relational_w_explicit(values)
    w_inherited = compute_relational_w_inherited(values)
    return {
        'anchor_shift_layer': {
            'delta_alpha': delta,
            'active': delta != 0,
        },
        'w_paths': {
            'explicit_kappa_w': w_explicit,
            'inherited_lambda_w': w_inherited,
            'difference_abs': abs(w_explicit - w_inherited),
        },
        'chemistry_bridge': {
            'active': all(k in flat_outputs for k in ['chemistry_element_count', 'chemistry_shell_closure_count']),
            'element_count': flat_outputs.get('chemistry_element_count'),
        },
    }


def research_summary(values: dict, flat_outputs: dict) -> dict:
    assumptions = load_assumptions()
    necessity = necessity_report(values, flat_outputs)
    return {
        'assumptions': assumptions['assumptions'],
        'necessity': necessity,
        'open_questions': [
            'Can inherited W closure replace explicit kappa_w without degraded agreement?',
            'Which provisional parameters are structurally necessary versus cosmetic?',
            'How much chemistry structure can be exposed before full relational derivation exists?',
        ],
    }
