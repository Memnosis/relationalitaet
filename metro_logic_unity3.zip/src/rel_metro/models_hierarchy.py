from __future__ import annotations

def run_hierarchy(values):
    gamma = values['gamma_family']
    norms = {'L_tb': values['gap_tb'] / gamma, 'L_cs': values['gap_cs'] / gamma, 'T_e': values['gap_mu_e'] / gamma - 1.0}
    return {'outputs': {'hierarchy_norms': norms}, 'derived_values': norms, 'steps': ['L_tb = gap_tb/gamma', 'L_cs = gap_cs/gamma', 'T_e = gap_mu_e/gamma - 1']}
