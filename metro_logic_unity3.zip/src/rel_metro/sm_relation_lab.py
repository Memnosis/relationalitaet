from __future__ import annotations
"""Research-grade relation diagnostics for official Standard Model and relational hypothesis layers.

This module turns relation definitions into inspectable test artefacts. It separates officially
recognized relations from relational overlays, inventories assumptions, probes necessity of
optional compensators, and produces reports consumable by GUI, API and regression tests.
"""

import json
from pathlib import Path
from typing import Any

from .config import merge_config
from .pipeline import execute
from .relation_engine import evaluate_relation, relation_test_suite
from .relation_registry import load_official_relations, load_relational_relations

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'


def _read_json(name: str) -> dict[str, Any]:
    with (CONFIGS / name).open('r', encoding='utf-8') as handle:
        return json.load(handle)


def load_assumption_registry() -> dict[str, Any]:
    return _read_json('assumption_registry.json')


def load_necessity_registry() -> dict[str, Any]:
    return _read_json('necessity_registry.json')


def load_research_testset() -> dict[str, Any]:
    return _read_json('research_testset.json')


def _build_base_values(profile_name: str, inline_overrides=None, active_reference_sets=None):
    run = execute(
        profile_name,
        inline_overrides=inline_overrides,
        active_reference_sets=active_reference_sets,
        run_relation_tests=False,
        run_research_suite=False,
    )
    values = {**run['config']['values'], **run['flat_outputs']}
    return run, values


def _flatten_references(references: dict[str, Any]) -> dict[str, Any]:
    flat: dict[str, Any] = {}
    for refset in references.values():
        flat.update(refset.get('observables', {}))
    return flat


def _relation_suite(relations: list[dict[str, Any]], values: dict[str, Any], references: dict[str, Any]) -> dict[str, Any]:
    results: dict[str, Any] = {}
    flat_references = _flatten_references(references)
    for relation in relations:
        computed = evaluate_relation(relation['relation_id'], values)['computed']
        outputs: dict[str, Any] = {}
        if isinstance(computed, dict):
            for key in relation.get('outputs', []):
                outputs[key] = computed.get(key)
        elif len(relation.get('outputs', [])) == 1:
            outputs[relation['outputs'][0]] = computed
        comparisons: dict[str, Any] = {}
        for output, value in outputs.items():
            ref = flat_references.get(output)
            if isinstance(ref, dict) and isinstance(value, (int, float)) and isinstance(ref.get('value'), (int, float)):
                diff = value - ref['value']
                sigma = ref.get('uncertainty')
                comparisons[output] = {
                    'reference_value': ref['value'],
                    'difference': diff,
                    'sigma_deviation': diff / sigma if sigma else None,
                }
            elif output in values and isinstance(value, (int, float)) and isinstance(values.get(output), (int, float)):
                comparisons[output] = {
                    'current_model_value': values[output],
                    'difference_to_model': value - values[output],
                }
            else:
                comparisons[output] = {'status': 'no_numeric_target'}
        results[relation['relation_id']] = {
            'layer': relation['layer'],
            'relation_type': relation.get('relation_type', 'unknown'),
            'inputs': relation.get('inputs', []),
            'outputs': outputs,
            'comparisons': comparisons,
        }
    return results


def official_relation_suite(profile_name='default_project', inline_overrides=None, active_reference_sets=None):
    run, values = _build_base_values(profile_name, inline_overrides, active_reference_sets)
    return {
        'profile_name': profile_name,
        'run_dir': run['run_dir'],
        'relations': _relation_suite(load_official_relations()['relations'], values, run['config']['references']),
    }


def relational_relation_suite(profile_name='default_project', inline_overrides=None, active_reference_sets=None):
    run, values = _build_base_values(profile_name, inline_overrides, active_reference_sets)
    return {
        'profile_name': profile_name,
        'run_dir': run['run_dir'],
        'relations': _relation_suite(load_relational_relations()['relations'], values, run['config']['references']),
    }


def assumption_map(profile_name='default_project', inline_overrides=None, active_reference_sets=None):
    cfg = merge_config(profile_name, inline_overrides=inline_overrides, active_reference_sets=active_reference_sets)
    assumption_registry = load_assumption_registry()['assumptions']
    parameter_map = {}
    for key, value in cfg.values.items():
        catalog = cfg.value_catalog.get(key, {})
        parameter_map[key] = {
            'value': value,
            'status': catalog.get('status', 'unknown'),
            'editable': catalog.get('editable', False),
        }
    return {
        'profile_name': profile_name,
        'assumptions': assumption_registry,
        'parameters': parameter_map,
        'active_reference_sets': cfg.active_reference_sets,
    }


def _necessity_score(output_value, reference_record):
    if not isinstance(reference_record, dict) or not isinstance(output_value, (int, float)):
        return None
    reference_value = reference_record.get('value')
    sigma = reference_record.get('uncertainty')
    if not isinstance(reference_value, (int, float)):
        return None
    diff = abs(output_value - reference_value)
    return {'abs_diff': diff, 'sigma_diff': diff / sigma if sigma else None}


def necessity_suite(profile_name='default_project', inline_overrides=None, active_reference_sets=None):
    run, values = _build_base_values(profile_name, inline_overrides, active_reference_sets)
    flat_refs = _flatten_references(run['config']['references'])
    records = {}
    for test in load_necessity_registry()['tests']:
        baseline_eval = evaluate_relation(test['baseline_relation'], values)
        baseline_output = baseline_eval['computed']
        target = test['target']
        baseline_value = baseline_output.get(target) if isinstance(baseline_output, dict) else baseline_output
        baseline_score = _necessity_score(baseline_value, flat_refs.get(test['reference_key']))
        variants = {}
        reduced_id = test.get('reduced_relation')
        alternative_relations = list(test.get('alternative_relations', []))
        if reduced_id:
            alternative_relations = [reduced_id] + alternative_relations
        for rel_id in alternative_relations:
            try:
                alt_eval = evaluate_relation(rel_id, values)
                alt_output = alt_eval['computed']
                alt_value = alt_output.get(target) if isinstance(alt_output, dict) else alt_output
                variants[rel_id] = {
                    'value': alt_value,
                    'score': _necessity_score(alt_value, flat_refs.get(test['reference_key'])),
                }
            except KeyError:
                variants[rel_id] = {'status': 'relation_missing_in_current_registry'}
        records[test['test_id']] = {
            'description_en': test.get('description_en'),
            'baseline_relation': test['baseline_relation'],
            'baseline_value': baseline_value,
            'baseline_score': baseline_score,
            'variants': variants,
        }
    return {'profile_name': profile_name, 'run_dir': run['run_dir'], 'tests': records}


def combined_research_suite(profile_name='default_project', inline_overrides=None, active_reference_sets=None):
    return {
        'metadata': load_research_testset().get('metadata', {}),
        'official': official_relation_suite(profile_name, inline_overrides, active_reference_sets),
        'relational': relational_relation_suite(profile_name, inline_overrides, active_reference_sets),
        'assumptions': assumption_map(profile_name, inline_overrides, active_reference_sets),
        'necessity': necessity_suite(profile_name, inline_overrides, active_reference_sets),
        'perturbation': relation_test_suite(profile_name, layers=['official', 'relational_known', 'relational_assumed']),
    }
