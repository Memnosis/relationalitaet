from __future__ import annotations
"""Tkinter-based metro_logic workbench.

This GUI is intentionally conservative but genuinely interactive: it offers a draggable graph
canvas, node/edge inspector, editable connections, multi-field edge editing, filters, grouping,
minimap and tour-triggered backend tests.
"""
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

from .pipeline import execute
from .comparison import compare_run_directories
from .dataset_importer import validate_profile_payload, import_json
from .profile_manager import save_profile
from .dataset_exporter import export_json
from .benchmarks import run_profile_series
from .chemistry_explorer import element_table_rows, isotope_table_rows, observable_heatmap_data, element_detail
from .graph_workbench import list_views, list_tours, list_snippets, canvas_view, inspect_node, inspect_edge, update_edge, update_multiple_edges, run_tour
from .ui_models import build_start_view, build_inputs_view, build_results_view, build_audit_view, build_dependency_view, build_dataset_admin_view


class MetroLogicApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('metro_logic secure block 2')
        self.geometry('1600x980')
        self.profile_var = tk.StringVar(value='default_project')
        self.reference_var = tk.StringVar(value='nist_codata_2022')
        self.compare_left_var = tk.StringVar(value='')
        self.compare_right_var = tk.StringVar(value='')
        self.dependency_node_var = tk.StringVar(value='')
        self.current_run = None
        self.recent_runs: list[str] = []
        self.edit_entries = {}
        self.import_status_var = tk.StringVar(value='No dataset imported yet.')
        self.current_view_var = tk.StringVar(value='core_relational_map')
        self.filter_text_var = tk.StringVar(value='')
        self.group_by_var = tk.StringVar(value='category')
        self.tour_var = tk.StringVar(value='software_intro')
        self.selected_node_id: str | None = None
        self.selected_edge_id: str | None = None
        self.canvas_nodes = {}
        self.canvas_edges = {}
        self.dragging_node = None
        self.drag_offset = (0, 0)
        self._build()

    def _json_text(self, parent):
        widget = tk.Text(parent, wrap='word')
        widget.pack(fill='both', expand=True, padx=8, pady=8)
        return widget

    def _build(self):
        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True)
        self.tabs = {}
        for name in ['Start', 'Inputs', 'Results', 'Audit', 'Dependencies', 'Relations', 'Chemistry', 'Compare', 'Datasets', 'Logs', 'Graph', 'Papers', 'Formulas', 'Effects']:
            frame = ttk.Frame(nb)
            nb.add(frame, text=name)
            self.tabs[name] = frame
        self._build_start(); self._build_inputs(); self._build_results(); self._build_audit(); self._build_dependencies(); self._build_relations(); self._build_chemistry(); self._build_compare(); self._build_datasets(); self._build_logs(); self._build_graph(); self._build_papers(); self._build_formulas(); self._build_effects()

    def _build_start(self):
        frame = self.tabs['Start']
        top = ttk.Frame(frame); top.pack(fill='x', padx=8, pady=8)
        view = build_start_view()
        ttk.Label(top, text='Profile').grid(row=0, column=0, sticky='w')
        ttk.Combobox(top, textvariable=self.profile_var, values=view['profiles'], state='readonly', width=28).grid(row=1, column=0, sticky='w')
        ttk.Label(top, text='Reference set').grid(row=0, column=1, sticky='w')
        ttk.Combobox(top, textvariable=self.reference_var, values=list(view['reference_sets'].keys()), state='readonly', width=28).grid(row=1, column=1, sticky='w')
        ttk.Button(top, text='Load inputs', command=self.refresh_inputs).grid(row=1, column=2, padx=6)
        ttk.Button(top, text='Run', command=self.run_pipeline).grid(row=1, column=3, padx=6)
        self.start_text = self._json_text(frame)
        self.start_text.insert('1.0', json.dumps(view, ensure_ascii=False, indent=2))
        self.start_text.configure(state='disabled')

    def _build_inputs(self):
        frame = self.tabs['Inputs']
        cmd = ttk.Frame(frame); cmd.pack(fill='x', padx=8, pady=8)
        ttk.Button(cmd, text='Reload input form', command=self.refresh_inputs).pack(side='left')
        ttk.Button(cmd, text='Save current values as profile', command=self.save_current_profile).pack(side='left', padx=6)
        form_outer = ttk.Frame(frame); form_outer.pack(fill='both', expand=False, padx=8, pady=8)
        canvas = tk.Canvas(form_outer, height=320)
        scrollbar = ttk.Scrollbar(form_outer, orient='vertical', command=canvas.yview)
        self.inputs_form = ttk.Frame(canvas)
        self.inputs_form.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0, 0), window=self.inputs_form, anchor='nw')
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        self.inputs_text = self._json_text(frame)
        self.refresh_inputs()

    def _build_results(self): self.results_text = self._json_text(self.tabs['Results'])
    def _build_audit(self): self.audit_text = self._json_text(self.tabs['Audit'])

    def _build_dependencies(self):
        frame = self.tabs['Dependencies']
        bar = ttk.Frame(frame); bar.pack(fill='x', padx=8, pady=8)
        ttk.Label(bar, text='Node').pack(side='left')
        ttk.Entry(bar, textvariable=self.dependency_node_var, width=22).pack(side='left')
        ttk.Button(bar, text='Refresh', command=self.refresh_dependency_view).pack(side='left', padx=6)
        self.dep_canvas = tk.Canvas(frame, width=700, height=420, background='white')
        self.dep_canvas.pack(fill='both', expand=False, padx=8, pady=8)
        self.dep_text = self._json_text(frame)
        self.refresh_dependency_view()

    def _build_relations(self):
        frame = self.tabs['Relations']
        upper = ttk.Frame(frame); upper.pack(fill='x', padx=8, pady=8)
        ttk.Button(upper, text='Refresh relation tests', command=self.refresh_relation_view).pack(side='left')
        self.rel_canvas = tk.Canvas(frame, width=980, height=280, background='white')
        self.rel_canvas.pack(fill='x', padx=8, pady=8)
        self.rel_text = self._json_text(frame)

    def _build_chemistry(self):
        frame = self.tabs['Chemistry']
        bar = ttk.Frame(frame); bar.pack(fill='x', padx=8, pady=8)
        ttk.Button(bar, text='Refresh chemistry view', command=self.refresh_chemistry_view).pack(side='left')
        self.chem_text = self._json_text(frame)
        self.refresh_chemistry_view()

    def _build_compare(self):
        frame = self.tabs['Compare']
        bar = ttk.Frame(frame); bar.pack(fill='x', padx=8, pady=8)
        ttk.Label(bar, text='Left run').grid(row=0, column=0, sticky='w')
        ttk.Entry(bar, textvariable=self.compare_left_var, width=64).grid(row=1, column=0, sticky='we')
        ttk.Label(bar, text='Right run').grid(row=2, column=0, sticky='w')
        ttk.Entry(bar, textvariable=self.compare_right_var, width=64).grid(row=3, column=0, sticky='we')
        ttk.Button(bar, text='Use current + last previous', command=self.use_recent_for_compare).grid(row=1, column=1, padx=6)
        ttk.Button(bar, text='Compare runs', command=self.compare_selected_runs).grid(row=3, column=1, padx=6)
        self.compare_text = self._json_text(frame)

    def _build_datasets(self):
        frame = self.tabs['Datasets']
        bar = ttk.Frame(frame); bar.pack(fill='x', padx=8, pady=8)
        ttk.Button(bar, text='Import dataset/profile…', command=self.import_dataset_from_gui).pack(side='left')
        ttk.Button(bar, text='Benchmark series', command=self.run_benchmarks).pack(side='left', padx=6)
        ttk.Button(bar, text='Export current run…', command=self.export_current_run).pack(side='left', padx=6)
        ttk.Label(frame, textvariable=self.import_status_var).pack(anchor='w', padx=8)
        self.datasets_text = self._json_text(frame)
        self.datasets_text.insert('1.0', json.dumps(build_dataset_admin_view(), ensure_ascii=False, indent=2))
        self.datasets_text.configure(state='disabled')

    def _build_logs(self): self.logs_text = self._json_text(self.tabs['Logs'])

    def _build_papers(self):
        self.papers_text = self._json_text(self.tabs['Papers'])
        self.papers_text.insert('1.0', json.dumps({'message': 'paper provenance remains available in API/registry'}, ensure_ascii=False, indent=2))

    def _build_formulas(self):
        self.formulas_text = self._json_text(self.tabs['Formulas'])
        self.formulas_text.insert('1.0', json.dumps({'message': 'formula provenance remains available in API/registry'}, ensure_ascii=False, indent=2))

    def _build_effects(self):
        self.effects_text = self._json_text(self.tabs['Effects'])
        self.effects_text.insert('1.0', json.dumps({'message': 'effect summaries remain available in API/registry'}, ensure_ascii=False, indent=2))

    def _build_graph(self):
        frame = self.tabs['Graph']
        top = ttk.Frame(frame); top.pack(fill='x', padx=8, pady=6)
        ttk.Label(top, text='View').grid(row=0, column=0, sticky='w')
        ttk.Combobox(top, textvariable=self.current_view_var, values=[v['view_id'] for v in list_views()], state='readonly', width=24).grid(row=1, column=0, sticky='w')
        ttk.Label(top, text='Filter').grid(row=0, column=1, sticky='w')
        ttk.Entry(top, textvariable=self.filter_text_var, width=24).grid(row=1, column=1, sticky='w')
        ttk.Label(top, text='Group by').grid(row=0, column=2, sticky='w')
        ttk.Combobox(top, textvariable=self.group_by_var, values=['category', 'status', 'none'], state='readonly', width=16).grid(row=1, column=2, sticky='w')
        ttk.Button(top, text='Refresh graph', command=self.refresh_graph_view).grid(row=1, column=3, padx=6)
        ttk.Label(top, text='Tour').grid(row=0, column=4, sticky='w')
        ttk.Combobox(top, textvariable=self.tour_var, values=[t['tour_id'] for t in list_tours()], state='readonly', width=24).grid(row=1, column=4, sticky='w')
        ttk.Button(top, text='Run tour', command=self.run_selected_tour).grid(row=1, column=5, padx=6)

        body = ttk.Frame(frame); body.pack(fill='both', expand=True)
        left = ttk.Frame(body); left.pack(side='left', fill='both', expand=True)
        right = ttk.Frame(body); right.pack(side='right', fill='y')

        self.graph_canvas = tk.Canvas(left, width=1050, height=650, background='white')
        self.graph_canvas.pack(fill='both', expand=True, padx=8, pady=8)
        self.graph_canvas.bind('<Button-1>', self._on_canvas_click)
        self.graph_canvas.bind('<B1-Motion>', self._on_canvas_drag)
        self.graph_canvas.bind('<ButtonRelease-1>', self._on_canvas_release)

        ttk.Label(right, text='Inspector', font=('Arial', 10, 'bold')).pack(anchor='w', padx=8, pady=(8, 2))
        self.inspector_text = tk.Text(right, wrap='word', width=56, height=26)
        self.inspector_text.pack(fill='both', expand=False, padx=8, pady=4)
        edit_box = ttk.LabelFrame(right, text='Edge editor')
        edit_box.pack(fill='x', padx=8, pady=6)
        self.edge_status_var = tk.StringVar(value='')
        self.edge_label_var = tk.StringVar(value='')
        self.edge_strength_var = tk.StringVar(value='')
        self.edge_short_en_var = tk.StringVar(value='')
        self.edge_short_de_var = tk.StringVar(value='')
        fields = [
            ('status', self.edge_status_var),
            ('label', self.edge_label_var),
            ('strength', self.edge_strength_var),
            ('short EN', self.edge_short_en_var),
            ('short DE', self.edge_short_de_var),
        ]
        for i, (lab, var) in enumerate(fields):
            ttk.Label(edit_box, text=lab).grid(row=i, column=0, sticky='w', padx=4, pady=2)
            ttk.Entry(edit_box, textvariable=var, width=32).grid(row=i, column=1, sticky='we', padx=4, pady=2)
        ttk.Button(edit_box, text='Apply to selected edge', command=self.apply_edge_changes).grid(row=len(fields), column=0, columnspan=2, pady=6)

        batch_box = ttk.LabelFrame(right, text='Multi-edge update')
        batch_box.pack(fill='both', padx=8, pady=6)
        ttk.Label(batch_box, text='JSON list of {edge_id, updates}').pack(anchor='w', padx=4, pady=2)
        self.multi_edit_text = tk.Text(batch_box, wrap='word', width=48, height=8)
        self.multi_edit_text.pack(fill='both', expand=True, padx=4, pady=4)
        ttk.Button(batch_box, text='Apply batch updates', command=self.apply_multi_edge_changes).pack(pady=4)

        mini_box = ttk.LabelFrame(right, text='Minimap')
        mini_box.pack(fill='x', padx=8, pady=6)
        self.minimap_canvas = tk.Canvas(mini_box, width=220, height=130, background='#f7f7f7')
        self.minimap_canvas.pack(fill='x', padx=4, pady=4)

        self.graph_log_text = tk.Text(right, wrap='word', width=56, height=10)
        self.graph_log_text.pack(fill='both', expand=False, padx=8, pady=6)
        self.refresh_graph_view()

    def refresh_inputs(self):
        values = execute(self.profile_var.get())['config']['values']
        rows = build_inputs_view(values, self.profile_var.get())
        for child in self.inputs_form.winfo_children(): child.destroy()
        self.edit_entries = {}
        headers = ['id', 'value', 'status', 'editable', 'description']
        for c, header in enumerate(headers):
            ttk.Label(self.inputs_form, text=header, font=('Arial', 9, 'bold')).grid(row=0, column=c, sticky='w', padx=4)
        for idx, row in enumerate(rows, start=1):
            ttk.Label(self.inputs_form, text=row['id']).grid(row=idx, column=0, sticky='w', padx=4)
            var = tk.StringVar(value=str(row['value']))
            entry = ttk.Entry(self.inputs_form, textvariable=var, width=14)
            if not row['editable']: entry.state(['disabled'])
            entry.grid(row=idx, column=1, sticky='w', padx=4)
            ttk.Label(self.inputs_form, text=row['status']).grid(row=idx, column=2, sticky='w', padx=4)
            ttk.Label(self.inputs_form, text='yes' if row['editable'] else 'no').grid(row=idx, column=3, sticky='w', padx=4)
            ttk.Label(self.inputs_form, text=row['description_en']).grid(row=idx, column=4, sticky='w', padx=4)
            self.edit_entries[row['id']] = {'var': var, 'editable': row['editable']}
        self.inputs_text.configure(state='normal'); self.inputs_text.delete('1.0', 'end'); self.inputs_text.insert('1.0', json.dumps(rows, ensure_ascii=False, indent=2)); self.inputs_text.configure(state='disabled')

    def _collect_overrides(self):
        out = {}
        for key, bundle in self.edit_entries.items():
            if bundle['editable']:
                try: out[key] = float(bundle['var'].get())
                except ValueError: pass
        return out

    def run_pipeline(self):
        self.current_run = execute(self.profile_var.get(), inline_overrides=self._collect_overrides(), active_reference_sets=[self.reference_var.get()], run_relation_tests=True)
        self.recent_runs.append(self.current_run['run_dir'])
        self.results_text.configure(state='normal'); self.results_text.delete('1.0', 'end'); self.results_text.insert('1.0', json.dumps(build_results_view(self.current_run), ensure_ascii=False, indent=2)); self.results_text.configure(state='disabled')
        self.audit_text.configure(state='normal'); self.audit_text.delete('1.0', 'end'); self.audit_text.insert('1.0', json.dumps(build_audit_view(self.current_run), ensure_ascii=False, indent=2)); self.audit_text.configure(state='disabled')
        self.logs_text.configure(state='normal'); self.logs_text.delete('1.0', 'end'); self.logs_text.insert('1.0', json.dumps({'run_dir': self.current_run['run_dir'], 'recent_runs': self.recent_runs[-10:]}, ensure_ascii=False, indent=2)); self.logs_text.configure(state='disabled')
        self.refresh_dependency_view(); self.refresh_relation_view(); self.refresh_graph_view()

    def refresh_dependency_view(self):
        payload = build_dependency_view(self.dependency_node_var.get().strip() or None)
        self.dep_text.configure(state='normal'); self.dep_text.delete('1.0', 'end'); self.dep_text.insert('1.0', json.dumps(payload, ensure_ascii=False, indent=2)); self.dep_text.configure(state='disabled')
        self.dep_canvas.delete('all')
        pos = payload['graph_layout']['positions']
        for edge in payload['graph']['edges']:
            if edge['from'] in pos and edge['to'] in pos:
                x1, y1 = pos[edge['from']]['x'], pos[edge['from']]['y']
                x2, y2 = pos[edge['to']]['x'], pos[edge['to']]['y']
                self.dep_canvas.create_line(x1, y1, x2, y2, fill='#999')
        target = self.dependency_node_var.get().strip()
        for node, xy in pos.items():
            x, y = xy['x'], xy['y']; r = 18
            fill = '#ffdd99' if target == node else '#cfe8ff'
            self.dep_canvas.create_oval(x-r, y-r, x+r, y+r, fill=fill, outline='#336699')
            self.dep_canvas.create_text(x, y, text=node[:10], font=('Arial', 7))

    def refresh_relation_view(self):
        payload = self.current_run['relation_tests'] if self.current_run else execute(self.profile_var.get(), run_relation_tests=True)['relation_tests']
        self.rel_text.configure(state='normal'); self.rel_text.delete('1.0', 'end'); self.rel_text.insert('1.0', json.dumps(payload, ensure_ascii=False, indent=2)); self.rel_text.configure(state='disabled')
        self.rel_canvas.delete('all')
        matrix = payload.get('influence_matrix', {})
        xs = list(matrix.keys())[:8]
        ys = sorted({y for targets in matrix.values() for y in targets})[:10]
        cell_w, cell_h = 90, 24
        for ix, x in enumerate(xs):
            self.rel_canvas.create_text(120 + ix * cell_w, 15, text=x[:10], anchor='w', font=('Arial', 8, 'bold'))
        for iy, y in enumerate(ys):
            self.rel_canvas.create_text(5, 35 + iy * cell_h, text=y[:14], anchor='w', font=('Arial', 8))
            for ix, x in enumerate(xs):
                info = matrix.get(x, {}).get(y, {'influence': 'none', 'sensitivity': None})
                color = {'none': '#eeeeee', 'weak': '#d7ebff', 'moderate': '#ffe39f', 'strong': '#ffb3a7'}.get(info['influence'], '#eeeeee')
                x0 = 100 + ix * cell_w; y0 = 25 + iy * cell_h
                self.rel_canvas.create_rectangle(x0, y0, x0 + 80, y0 + 20, fill=color, outline='#888')
                self.rel_canvas.create_text(x0 + 40, y0 + 10, text=info['influence'][0].upper(), font=('Arial', 8, 'bold'))

    def refresh_chemistry_view(self):
        payload = {
            'elements_sample': element_table_rows(1, 20),
            'isotopes_sample': isotope_table_rows('Fe'),
            'heatmap': observable_heatmap_data(1, 12),
            'detail_example': element_detail('O'),
        }
        self.chem_text.configure(state='normal'); self.chem_text.delete('1.0', 'end'); self.chem_text.insert('1.0', json.dumps(payload, ensure_ascii=False, indent=2)); self.chem_text.configure(state='disabled')

    def save_current_profile(self):
        save_profile(f'saved_{self.profile_var.get()}', self._collect_overrides(), metadata={'title': 'saved from ui'}, reference_sets=[self.reference_var.get()])
        messagebox.showinfo('metro_logic', 'Profile saved.')

    def import_dataset_from_gui(self):
        path = filedialog.askopenfilename(title='Select dataset/profile JSON', filetypes=[('JSON files', '*.json'), ('All files', '*.*')])
        if not path: return
        try:
            payload = import_json(path)
            errors = validate_profile_payload(payload)
            if errors:
                self.import_status_var.set('Import failed.')
                messagebox.showerror('Validation failed', '\n'.join(errors))
                return
            save_profile(payload.get('profile_name', 'imported_from_gui'), payload.get('overrides', {}), metadata=payload.get('metadata'), reference_sets=payload.get('reference_sets'))
            self.import_status_var.set(f'Imported: {Path(path).name}')
            self.datasets_text.configure(state='normal'); self.datasets_text.delete('1.0', 'end'); self.datasets_text.insert('1.0', json.dumps(payload, ensure_ascii=False, indent=2)); self.datasets_text.configure(state='disabled')
        except Exception as exc:
            self.import_status_var.set('Import failed.')
            messagebox.showerror('Import error', str(exc))

    def export_current_run(self):
        if not self.current_run:
            messagebox.showwarning('metro_logic', 'No current run to export.')
            return
        path = filedialog.asksaveasfilename(title='Export current run JSON', defaultextension='.json', filetypes=[('JSON files', '*.json')])
        if not path: return
        export_json(path, self.current_run)
        messagebox.showinfo('metro_logic', f'Exported to {path}')

    def run_benchmarks(self):
        suite = run_profile_series(['default_project', 'sanity_shifted', 'closure_inherited'], run_relation_tests=True)
        self.datasets_text.configure(state='normal'); self.datasets_text.delete('1.0', 'end'); self.datasets_text.insert('1.0', json.dumps(suite, ensure_ascii=False, indent=2)); self.datasets_text.configure(state='disabled')
        messagebox.showinfo('metro_logic', 'Benchmark series executed.')

    def use_recent_for_compare(self):
        if len(self.recent_runs) >= 2:
            self.compare_left_var.set(self.recent_runs[-2]); self.compare_right_var.set(self.recent_runs[-1])
        elif self.current_run:
            self.compare_left_var.set(self.current_run['run_dir']); self.compare_right_var.set(self.current_run['run_dir'])

    def compare_selected_runs(self):
        if not self.compare_left_var.get() or not self.compare_right_var.get():
            messagebox.showwarning('metro_logic', 'Need two run directories.')
            return
        payload = compare_run_directories(self.compare_left_var.get(), self.compare_right_var.get())
        self.compare_text.configure(state='normal'); self.compare_text.delete('1.0', 'end'); self.compare_text.insert('1.0', json.dumps(payload, ensure_ascii=False, indent=2)); self.compare_text.configure(state='disabled')

    # Graph workbench
    def _graph_filters(self):
        flt = {}
        text = self.filter_text_var.get().strip()
        if text: flt['text'] = text
        return flt

    def refresh_graph_view(self):
        group_by = None if self.group_by_var.get() in ('', 'none') else self.group_by_var.get()
        self.current_canvas_payload = canvas_view(self.current_view_var.get(), filters=self._graph_filters(), group_by=group_by)
        self._draw_graph_canvas(self.current_canvas_payload)
        self._draw_minimap(self.current_canvas_payload['minimap'])
        self._log_graph_payload({'action': 'refresh_graph', 'view': self.current_view_var.get(), 'groups': self.current_canvas_payload['groups']})

    def _draw_graph_canvas(self, payload):
        self.graph_canvas.delete('all')
        self.canvas_nodes = {}
        self.canvas_edges = {}
        nodes = {n['id']: n for n in payload['nodes'] if n['visible']}
        for edge in [e for e in payload['edges'] if e['visible']]:
            src, tgt = nodes.get(edge['source']), nodes.get(edge['target'])
            if not src or not tgt: continue
            color = '#7a7a7a'
            width = 2 if edge.get('status') == 'implemented' else 1
            line = self.graph_canvas.create_line(src['x'], src['y'], tgt['x'], tgt['y'], fill=color, width=width, smooth=True)
            mx, my = (src['x'] + tgt['x']) / 2, (src['y'] + tgt['y']) / 2
            txt = self.graph_canvas.create_text(mx, my - 10, text=edge['id'][:18], font=('Arial', 8), fill='#444')
            self.canvas_edges[line] = edge['id']; self.canvas_edges[txt] = edge['id']
        for node in nodes.values():
            x, y, r = node['x'], node['y'], 28
            fill = {'relational_core':'#d7ecff','parameter':'#dff6dd','derived':'#fff0c9','observable':'#ffd8d8','bridge':'#e6d8ff','chemistry':'#d7fff2'}.get(node['category'], '#eeeeee')
            oval = self.graph_canvas.create_oval(x-r, y-r, x+r, y+r, fill=fill, outline='#336699', width=2)
            txt = self.graph_canvas.create_text(x, y, text=node['label'][:14], font=('Arial', 8, 'bold'))
            self.canvas_nodes[oval] = node['id']; self.canvas_nodes[txt] = node['id']

    def _draw_minimap(self, minimap):
        self.minimap_canvas.delete('all')
        for node in minimap.get('nodes', []):
            x, y = node['x'], node['y']
            self.minimap_canvas.create_oval(x-3, y-3, x+3, y+3, fill='#4477aa', outline='')

    def _on_canvas_click(self, event):
        item = self.graph_canvas.find_withtag('current')
        if not item: return
        item_id = item[0]
        if item_id in self.canvas_nodes:
            self.selected_node_id = self.canvas_nodes[item_id]; self.selected_edge_id = None
            self.dragging_node = self.selected_node_id
            self.drag_offset = (event.x, event.y)
            info = inspect_node(self.current_view_var.get(), self.selected_node_id)
            self._show_inspector(info)
        elif item_id in self.canvas_edges:
            self.selected_edge_id = self.canvas_edges[item_id]; self.selected_node_id = None
            info = inspect_edge(self.current_view_var.get(), self.selected_edge_id)
            self._load_edge_into_editor(info)
            self._show_inspector(info)

    def _on_canvas_drag(self, event):
        if not self.dragging_node: return
        # visual-only dragging in current session
        self.refresh_graph_view()
        for item_id, nid in self.canvas_nodes.items():
            if nid == self.dragging_node:
                # identify center by bbox
                bbox = self.graph_canvas.bbox(item_id)
                if bbox:
                    cx = (bbox[0] + bbox[2]) / 2; cy = (bbox[1] + bbox[3]) / 2
                    dx = event.x - cx; dy = event.y - cy
                    linked = [item_id]
                    for iid, node_id in self.canvas_nodes.items():
                        if node_id == nid and iid != item_id: linked.append(iid)
                    for iid in linked: self.graph_canvas.move(iid, dx, dy)
        self._log_graph_payload({'action':'drag_node','node_id': self.dragging_node, 'x': event.x, 'y': event.y})

    def _on_canvas_release(self, event):
        self.dragging_node = None

    def _show_inspector(self, payload):
        self.inspector_text.delete('1.0', 'end')
        self.inspector_text.insert('1.0', json.dumps(payload, ensure_ascii=False, indent=2))

    def _load_edge_into_editor(self, payload):
        edge = payload.get('edge') or {}
        self.edge_status_var.set(str(edge.get('status','')))
        self.edge_label_var.set(str(edge.get('label') or ''))
        self.edge_strength_var.set('' if edge.get('strength') is None else str(edge.get('strength')))
        self.edge_short_en_var.set(str(edge.get('short_info_en','')))
        self.edge_short_de_var.set(str(edge.get('short_info_de','')))

    def apply_edge_changes(self):
        if not self.selected_edge_id:
            messagebox.showwarning('metro_logic', 'Select an edge first.')
            return
        updates = {
            'status': self.edge_status_var.get().strip(),
            'label': self.edge_label_var.get().strip() or None,
            'short_info_en': self.edge_short_en_var.get().strip(),
            'short_info_de': self.edge_short_de_var.get().strip(),
        }
        strength = self.edge_strength_var.get().strip()
        if strength:
            try: updates['strength'] = float(strength)
            except ValueError: pass
        payload = update_edge(self.selected_edge_id, updates)
        self._log_graph_payload({'action': 'update_edge', 'payload': payload})
        self.refresh_graph_view()

    def apply_multi_edge_changes(self):
        raw = self.multi_edit_text.get('1.0', 'end').strip()
        if not raw:
            messagebox.showwarning('metro_logic', 'No batch payload entered.')
            return
        try:
            payload = json.loads(raw)
            result = update_multiple_edges(payload)
            self._log_graph_payload({'action': 'batch_update_edges', 'payload': result})
            self.refresh_graph_view()
        except Exception as exc:
            messagebox.showerror('Batch update failed', str(exc))

    def run_selected_tour(self):
        payload = run_tour(self.tour_var.get(), profile_name=self.profile_var.get(), active_reference_sets=[self.reference_var.get()])
        self._show_inspector(payload)
        if payload.get('final_run_dir'):
            self.recent_runs.append(payload['final_run_dir'])
        self._log_graph_payload({'action':'run_tour','tour_id': self.tour_var.get(), 'final_run_dir': payload.get('final_run_dir')})

    def _log_graph_payload(self, payload):
        self.graph_log_text.insert('end', json.dumps(payload, ensure_ascii=False) + '\n')
        self.graph_log_text.see('end')


def launch():
    app = MetroLogicApp()
    app.mainloop()


if __name__ == '__main__':
    launch()


def main():
    launch()
