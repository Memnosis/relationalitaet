from __future__ import annotations
import json
from pathlib import Path
from .atom_registry import list_elements, list_isotopes
import json
from .standard_model_registry import interaction_summary
from .snippet_library import snippet_catalog_summary
from .tour_catalog import tour_summary
ROOT = Path(__file__).resolve().parents[2]

def load_missing_profiles() -> dict:
    path = ROOT / 'configs' / 'missing_profiles_registry.json'
    if not path.exists():
        return {'profiles': []}
    return json.loads(path.read_text(encoding='utf-8'))

def _rel_chemistry_element_count() -> int:
    path = ROOT / 'configs' / 'rel_chemistry_registry.json'
    if not path.exists():
        return 0
    payload = json.loads(path.read_text(encoding='utf-8'))
    return len(payload.get('elements', []))

def data_inventory() -> dict:
    return {'elements': max(len(list_elements()), _rel_chemistry_element_count()), 'isotopes': len(list_isotopes()), 'standard_model': interaction_summary(), 'snippets': snippet_catalog_summary(), 'tours': tour_summary(), 'missing_profiles': len(load_missing_profiles().get('profiles', []))}

def detect_missing_data_profiles() -> list[dict]:
    rows = []
    for item in load_missing_profiles().get('profiles', []):
        rows.append({'profile_id': item.get('profile_id') or item.get('id') or item.get('name', 'unknown_profile'), 'domain': item.get('domain', 'unknown'), 'priority': item.get('priority', 'unspecified'), 'needed_for': item.get('needed_for') or item.get('use_case') or item.get('research_target', ''), 'why_missing': item.get('why_missing') or item.get('gap') or item.get('note', '')})
    return rows

def relational_force_requirements() -> list[dict]:
    return [
        {'force': 'electromagnetic', 'required_relational_quantities': ['running_coupling_anchor', 'charge_screening_profile', 'threshold_link_map']},
        {'force': 'weak', 'required_relational_quantities': ['mixing_angle_anchor', 'chirality_rule', 'threshold_mass_hierarchy']},
        {'force': 'strong', 'required_relational_quantities': ['confinement_closure', 'scale_cascade_map', 'color_screening_constraints']},
        {'force': 'gravity_interface', 'required_relational_quantities': ['cross_sector_normalization', 'hierarchy_lock', 'dimensionless_bridge_candidates']},
    ]

def challenge_map_standard_model() -> list[dict]:
    return [
        {'question': 'Which accepted parameters are fitted instead of relationally derived?', 'criterion': 'reduce free parameters across sectors'},
        {'question': 'Which cross-sector equalities fail under current relational constraints?', 'criterion': 'publish reproducible tension matrix'},
        {'question': 'Which missing datasets block predictive force derivations?', 'criterion': 'complete high-priority missing profiles'},
        {'question': 'Which current formulas can be re-expressed as relational closure tests?', 'criterion': 'convert narrative claims into executable checks'},
    ]

def research_readiness_report() -> dict:
    gaps = detect_missing_data_profiles()
    return {'inventory': data_inventory(), 'gap_count': len(gaps), 'high_priority_gaps': [g for g in gaps if str(g.get('priority', '')).lower() in {'high','critical','p1'}], 'force_requirements': relational_force_requirements(), 'challenge_map': challenge_map_standard_model()}


def force_question_inventory() -> dict:
    try:
        from .force_research_program import question_summary
        return question_summary()
    except Exception:
        return {'question_count': 0, 'theme_count': 0, 'force_mentions': {}}
