from __future__ import annotations
import math

def run_w(values):
    delta = 1.0 / (math.pi * values['anchor_ln_R0_lp'])
    base = values['m_z_gev'] * math.sqrt(max(0.0, 1.0 - values['sin2_theta_w_ideal']))
    explicit = base + values['kappa_w'] * delta * values['m_z_gev']
    inherited = base + (1.0 + values['lambda_q'] + values['lambda_l']) * delta * values['m_z_gev']
    return {'outputs': {'w_mass_gev': explicit, 'w_mass_inherited_gev': inherited}, 'derived_values': {'base_w_mass': base, 'delta_alpha_like': delta}, 'steps': ['base electroweak mass', 'explicit kappa correction', 'inherited closure correction']}
