
from __future__ import annotations
import ast, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
PACKAGES = ['rel_metro', 'metro_logic', 'metro_logic_unity']
IGNORED_RUNTIME_DIRS = {'__pycache__', '.pytest_cache'}

def load_completeness_contract() -> dict:
    return json.loads((ROOT / 'configs' / 'completeness_contract.json').read_text(encoding='utf-8'))

def existing_public_functions() -> list[str]:
    rows = []
    for package in PACKAGES:
        for path in sorted((ROOT / 'src' / package).glob('*.py')):
            tree = ast.parse(path.read_text(encoding='utf-8'))
            for node in tree.body:
                if isinstance(node, ast.FunctionDef) and not node.name.startswith('_'):
                    rows.append(f'{package}.{path.stem}.{node.name}')
    return sorted(rows)

def find_release_hygiene_violations() -> list[str]:
    bad = []
    for path in ROOT.rglob('*'):
        if any(part in IGNORED_RUNTIME_DIRS for part in path.parts):
            continue
        if path.suffix == '.pyc':
            bad.append(path.relative_to(ROOT).as_posix())
    return sorted(bad)

def evaluate_completeness() -> dict:
    contract = load_completeness_contract()
    missing_files = [item for item in contract.get('required_files', []) if not (ROOT / item).exists()]
    matrix = json.loads((ROOT / 'configs' / 'function_test_matrix.json').read_text(encoding='utf-8'))
    mapped = {item['function'] for item in matrix.get('entries', [])}
    public_functions = set(existing_public_functions())
    hygiene = find_release_hygiene_violations()
    return {
        'required_files_present': not missing_files,
        'missing_files': missing_files,
        'public_function_count': len(public_functions),
        'mapped_function_count': len(public_functions & mapped),
        'unmapped_functions': sorted(public_functions - mapped),
        'release_hygiene_violations': hygiene,
        'ok': not missing_files and not hygiene and public_functions <= mapped,
    }
