from __future__ import annotations
from .config import load_reference_sets


def get_reference_summary():
    return {name: {'title': payload.get('metadata', {}).get('title'), 'source_url': payload.get('metadata', {}).get('source_url')} for name, payload in load_reference_sets().items()}
