from __future__ import annotations
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

def load_snippet_library() -> dict:
    return json.loads((ROOT / 'configs' / 'snippet_registry.json').read_text(encoding='utf-8'))

def list_snippets() -> list[dict]:
    return load_snippet_library().get('snippets', [])

def snippet_index() -> dict[str, dict]:
    return {item['snippet_id']: item for item in list_snippets() if 'snippet_id' in item}

def get_snippet(snippet_id: str) -> dict:
    return snippet_index()[snippet_id]

def search_snippets(text: str = '', category: str | None = None) -> list[dict]:
    text = text.lower().strip()
    rows = []
    for item in list_snippets():
        blob = ' '.join(str(item.get(k, '')) for k in ('title', 'description_en', 'description_de', 'code', 'latex_formula', 'category')).lower()
        if text and text not in blob:
            continue
        if category and item.get('category') != category:
            continue
        rows.append(item)
    return rows

def snippet_catalog_summary() -> dict:
    snippets = list_snippets()
    return {'snippet_count': len(snippets), 'with_latex': sum(1 for s in snippets if s.get('latex_formula')), 'with_descriptions': sum(1 for s in snippets if s.get('description_en') or s.get('description_de'))}
