
from __future__ import annotations
"""Provenance mapping from papers to formulas, relations and visible effects."""
from .paper_registry import paper_index
from .formula_registry import formulas_for_relation, load_formula_registry
from .relation_registry import all_relations

def relation_index() -> dict:
    return {r['relation_id']: r for r in all_relations()}

def relation_provenance(relation_id: str) -> dict:
    rel = relation_index()[relation_id]
    pidx = paper_index()
    formulas = formulas_for_relation(relation_id)
    papers = [pidx[d] for d in rel.get('source_doc_ids', []) if d in pidx]
    affected = list(dict.fromkeys(list(rel.get('outputs', [])) + [o for f in formulas for o in f.get('outputs', [])]))
    return {'relation': rel, 'papers': papers, 'formulas': formulas, 'affected_outputs': affected}

def paper_effect_summary(doc_id: str) -> dict:
    p = paper_index().get(doc_id)
    rels = [r for r in all_relations() if doc_id in r.get('source_doc_ids', [])]
    return {
        'paper': p,
        'relations': rels,
        'relation_count': len(rels),
        'affected_outputs': sorted({o for r in rels for o in r.get('outputs', [])}),
    }
