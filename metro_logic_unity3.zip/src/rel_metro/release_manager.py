
from __future__ import annotations
import hashlib, json, zipfile
from pathlib import Path
from .completeness_guard import evaluate_completeness
ROOT = Path(__file__).resolve().parents[2]
EXCLUDE_PARTS = {'__pycache__', '.pytest_cache', 'runs', 'downloads'}
EXCLUDE_SUFFIXES = {'.pyc', '.pyo', '.zip'}


def iter_release_files(base_dir: str | Path | None = None):
    base = Path(base_dir) if base_dir else ROOT
    for path in sorted(base.rglob('*')):
        if not path.is_file():
            continue
        if any(part in EXCLUDE_PARTS for part in path.parts):
            continue
        if path.suffix.lower() in EXCLUDE_SUFFIXES:
            continue
        yield path


def build_manifest(base_dir: str | Path | None = None) -> dict:
    base = Path(base_dir) if base_dir else ROOT
    files = []
    for path in iter_release_files(base):
        files.append({'path': path.relative_to(base).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'size': path.stat().st_size})
    return {'root': str(base), 'file_count': len(files), 'files': files, 'completeness': evaluate_completeness()}


def write_manifest(destination: str | Path, base_dir: str | Path | None = None) -> Path:
    dest = Path(destination)
    dest.write_text(json.dumps(build_manifest(base_dir), ensure_ascii=False, indent=2), encoding='utf-8')
    return dest


def create_release_zip(zip_path: str | Path, base_dir: str | Path | None = None) -> Path:
    base = Path(base_dir) if base_dir else ROOT
    zip_path = Path(zip_path)
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for path in iter_release_files(base):
            zf.write(path, path.relative_to(base).as_posix())
    return zip_path


def verify_release_zip(zip_path: str | Path) -> dict:
    zip_path = Path(zip_path)
    with zipfile.ZipFile(zip_path, 'r') as zf:
        bad = zf.testzip(); names = zf.namelist()
    return {'zip_path': str(zip_path), 'ok': bad is None, 'bad_entry': bad, 'entry_count': len(names)}
