
"""Atomic and isotopic registry access for rel_metro chemistry expansion.

This module is deliberately data-driven. Runtime code reads static JSON files that
were generated from known periodic-table information and then frozen into the
package so local execution does not require third-party chemistry libraries.
"""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def _read_json(name: str) -> dict:
    return json.loads((ROOT / "configs" / name).read_text(encoding="utf-8"))

def load_atom_registry() -> dict:
    return _read_json("atom_registry.json")

def load_isotope_registry() -> dict:
    return _read_json("isotope_registry.json")

def list_elements() -> list[dict]:
    return load_atom_registry()["elements"]

def get_element(symbol: str) -> dict:
    for element in list_elements():
        if element["symbol"] == symbol:
            return element
    raise KeyError(symbol)

def get_element_by_atomic_number(z: int) -> dict:
    for element in list_elements():
        if element["atomic_number"] == z:
            return element
    raise KeyError(z)

def list_isotopes(symbol: str | None = None) -> list[dict]:
    isotopes = load_isotope_registry()["isotopes"]
    if symbol is None:
        return isotopes
    return [iso for iso in isotopes if iso["element"] == symbol]
