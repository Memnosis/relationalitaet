
from __future__ import annotations
"""Formula registry linking papers to relations and code bindings."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'

def load_formula_registry() -> dict:
    return json.loads((CONFIGS / 'formula_registry.json').read_text(encoding='utf-8'))

def formula_index() -> dict:
    return {f['formula_id']: f for f in load_formula_registry().get('formulas', [])}

def formulas_for_relation(relation_id: str) -> list[dict]:
    return [f for f in load_formula_registry().get('formulas', []) if relation_id in f.get('relation_ids', [])]
