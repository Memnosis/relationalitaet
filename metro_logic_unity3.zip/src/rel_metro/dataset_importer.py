from __future__ import annotations
"""Dataset/profile import with schema-style validation."""
import json
from pathlib import Path

REQUIRED_PROFILE_KEYS = {'overrides'}
ALLOWED_TOP_LEVEL_KEYS = {'profile_name', 'metadata', 'reference_sets', 'overrides', 'project_values', 'dataset_name', 'dataset_version'}


def import_json(path):
    with Path(path).open('r', encoding='utf-8') as handle:
        return json.load(handle)


def validate_profile_payload(payload):
    errors = []
    unknown = sorted(set(payload) - ALLOWED_TOP_LEVEL_KEYS)
    if unknown:
        errors.append(f'unknown keys: {unknown}')
    missing = REQUIRED_PROFILE_KEYS - payload.keys()
    if missing:
        errors.append(f'missing keys: {sorted(missing)}')
    if 'overrides' in payload and not isinstance(payload['overrides'], dict):
        errors.append('overrides must be a dictionary')
    if 'reference_sets' in payload and not isinstance(payload['reference_sets'], list):
        errors.append('reference_sets must be a list')
    for key, value in payload.get('overrides', {}).items():
        if not isinstance(key, str):
            errors.append('override keys must be strings')
        if not isinstance(value, (int, float)):
            errors.append(f'override value for {key} must be numeric')
    return errors


def load_profile_payload(path):
    payload = import_json(path)
    errors = validate_profile_payload(payload)
    if errors:
        raise ValueError('Invalid profile payload: ' + '; '.join(errors))
    return payload
