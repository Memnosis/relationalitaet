from __future__ import annotations
"""Registry layer for official and relational relations.

Each relation is a first-class object that can be displayed, tested, perturbed and compared.
This module keeps the source-of-truth split between official relations and relational relations,
while also exposing combined lookup helpers for node-centric exploration in GUI and API.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'


def _read(path: Path):
    with path.open('r', encoding='utf-8') as handle:
        return json.load(handle)


def load_official_relations():
    return _read(CONFIGS / 'official_relations.json')


def load_relational_relations():
    return _read(CONFIGS / 'relational_relations.json')


def load_relation_registry():
    off = load_official_relations()
    rel = load_relational_relations()
    return {
        'metadata': {
            'official_version': off.get('metadata', {}).get('version', 'n/a'),
            'relational_version': rel.get('metadata', {}).get('version', 'n/a'),
        },
        'relations': off.get('relations', []) + rel.get('relations', []),
    }


def relation_index():
    return {item['relation_id']: item for item in load_relation_registry()['relations']}


def relations_for_node(node_id: str):
    incoming, outgoing, touching = [], [], []
    for relation in load_relation_registry()['relations']:
        if node_id in relation.get('outputs', []):
            incoming.append(relation)
        if node_id in relation.get('inputs', []):
            outgoing.append(relation)
        if node_id in relation.get('inputs', []) or node_id in relation.get('outputs', []):
            touching.append(relation)
    return {'incoming_relations': incoming, 'outgoing_relations': outgoing, 'touching_relations': touching}


def grouped_relations():
    groups = {}
    for relation in load_relation_registry()['relations']:
        groups.setdefault(relation['layer'], []).append(relation)
    return {k: sorted(v, key=lambda x: x['relation_id']) for k, v in sorted(groups.items())}


def all_relations():
    return load_relation_registry()['relations']
