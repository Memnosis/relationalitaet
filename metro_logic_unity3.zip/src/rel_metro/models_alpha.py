from __future__ import annotations
import math

def run_alpha(values):
    delta = 1.0 / (math.pi * values['anchor_ln_R0_lp'])
    alpha_inv = values['alpha_ideal_inv'] + delta
    return {'outputs': {'alpha_inverse': alpha_inv}, 'derived_values': {'delta_alpha': delta}, 'steps': ['delta_alpha from anchor', 'alpha_inverse = alpha_ideal_inv + delta_alpha']}
