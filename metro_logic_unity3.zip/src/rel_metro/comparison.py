from __future__ import annotations
"""Run-to-run comparison helpers."""
import json
from pathlib import Path


def compare_outputs(left, right):
    comparison = {}
    for key in sorted(set(left) | set(right)):
        lv = left.get(key)
        rv = right.get(key)
        comparison[key] = {
            'left': lv,
            'right': rv,
            'delta': None if lv is None or rv is None or not isinstance(lv, (int, float)) or not isinstance(rv, (int, float)) else rv - lv,
        }
    return comparison


def compare_runs(left_run, right_run):
    return {
        'left_profile': left_run.get('config', {}).get('profile_name'),
        'right_profile': right_run.get('config', {}).get('profile_name'),
        'output_comparison': compare_outputs(left_run.get('flat_outputs', {}), right_run.get('flat_outputs', {})),
        'metric_comparison': compare_outputs(left_run.get('metrics', {}), right_run.get('metrics', {})),
    }


def load_run_payload(run_dir):
    base = Path(run_dir)
    with (base / 'outputs' / 'results.json').open('r', encoding='utf-8') as handle:
        results = json.load(handle)
    with (base / 'outputs' / 'metrics.json').open('r', encoding='utf-8') as handle:
        metrics = json.load(handle)
    manifest = json.loads((base / 'meta' / 'run_manifest.json').read_text(encoding='utf-8')) if (base / 'meta' / 'run_manifest.json').exists() else {}
    return {'config': {'profile_name': manifest.get('profile')}, 'flat_outputs': results.get('flat_outputs', {}), 'metrics': metrics, 'run_dir': str(base)}


def compare_run_directories(left_run_dir, right_run_dir):
    return compare_runs(load_run_payload(left_run_dir), load_run_payload(right_run_dir))
