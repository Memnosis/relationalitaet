from __future__ import annotations
import json
from collections import Counter, defaultdict
from pathlib import Path
from .research_questions import data_inventory, detect_missing_data_profiles
ROOT = Path(__file__).resolve().parents[2]


def load_force_research_questions() -> dict:
    return json.loads((ROOT / 'configs' / 'force_research_questions_registry.json').read_text(encoding='utf-8'))


def list_force_research_questions(theme_id: str | None = None, force: str | None = None, only_blocked: bool = False) -> list[dict]:
    rows = load_force_research_questions().get('questions', [])
    out = []
    for item in rows:
        if theme_id and item.get('theme_id') != theme_id:
            continue
        if force and force not in item.get('forces', []):
            continue
        if only_blocked and not item.get('blocked_by_missing_data'):
            continue
        out.append(item)
    return out


def question_summary() -> dict:
    payload = load_force_research_questions()
    questions = payload.get('questions', [])
    theme_counter = Counter(item.get('theme_id') for item in questions)
    force_counter = Counter(force for item in questions for force in item.get('forces', []))
    blocked = sum(1 for item in questions if item.get('blocked_by_missing_data'))
    return {
        'question_count': len(questions),
        'theme_count': len(theme_counter),
        'force_mentions': dict(force_counter),
        'blocked_question_count': blocked,
        'theme_distribution': dict(theme_counter),
    }


def research_gap_matrix() -> list[dict]:
    payload = load_force_research_questions()
    bank = payload.get('dataset_bank', {})
    counts = defaultdict(int)
    question_ids = defaultdict(list)
    for item in payload.get('questions', []):
        for dataset in item.get('required_datasets', []):
            counts[dataset] += 1
            question_ids[dataset].append(item.get('question_id'))
    rows = []
    for dataset_id, info in bank.items():
        rows.append({
            'dataset_id': dataset_id,
            'status': info.get('status', 'unknown'),
            'why': info.get('why', ''),
            'question_count': counts.get(dataset_id, 0),
            'sample_question_ids': question_ids.get(dataset_id, [])[:5],
        })
    rows.sort(key=lambda row: ({'missing': 0, 'partial': 1, 'present': 2}.get(row['status'], 9), -row['question_count'], row['dataset_id']))
    return rows


def software_requirement_matrix() -> list[dict]:
    payload = load_force_research_questions()
    capability_text = payload.get('software_capabilities', {})
    counts = defaultdict(int)
    blocked_counts = defaultdict(int)
    for item in payload.get('questions', []):
        for capability in item.get('software_capabilities_needed', []):
            counts[capability] += 1
            if item.get('blocked_by_missing_data'):
                blocked_counts[capability] += 1
    rows = []
    for capability_id, description in capability_text.items():
        rows.append({
            'capability_id': capability_id,
            'description': description,
            'question_count': counts.get(capability_id, 0),
            'blocked_question_count': blocked_counts.get(capability_id, 0),
        })
    rows.sort(key=lambda row: (-row['question_count'], row['capability_id']))
    return rows


def recommended_next_steps(limit: int = 12) -> list[dict]:
    questions = list_force_research_questions(only_blocked=True)
    gaps = {row['dataset_id']: row for row in research_gap_matrix()}
    software = {row['capability_id']: row for row in software_requirement_matrix()}
    rows = []
    for item in questions:
        missing = [dataset for dataset, status in item.get('dataset_status', {}).items() if status == 'missing']
        impact = sum(gaps[d]['question_count'] for d in missing if d in gaps)
        capability_pressure = sum(software[c]['question_count'] for c in item.get('software_capabilities_needed', []) if c in software)
        rows.append({
            'question_id': item['question_id'],
            'theme_id': item['theme_id'],
            'question': item['question'],
            'missing_datasets': missing,
            'impact_score': impact,
            'capability_pressure': capability_pressure,
        })
    rows.sort(key=lambda row: (-row['impact_score'], -row['capability_pressure'], row['question_id']))
    return rows[:limit]


def relational_research_program_report() -> dict:
    return {
        'inventory': data_inventory(),
        'question_summary': question_summary(),
        'gap_matrix': research_gap_matrix(),
        'software_requirements': software_requirement_matrix(),
        'missing_profiles': detect_missing_data_profiles(),
        'next_steps': recommended_next_steps(),
    }
