from __future__ import annotations
from .pipeline import execute
from .comparison import compare_outputs


def run_profile_series(profiles, run_relation_tests=False):
    results = {name: execute(name, run_relation_tests=run_relation_tests) for name in profiles}
    names = list(results.keys())
    comparisons = {}
    if names:
        base = names[0]
        for other in names[1:]:
            comparisons[f'{base}_vs_{other}'] = compare_outputs(results[base]['flat_outputs'], results[other]['flat_outputs'])
    return {'runs': results, 'comparisons': comparisons}
