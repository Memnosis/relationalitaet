
"""Atom and chemistry bridge utilities.

This module converts registry rows into richer state objects and bridge-specific
summaries. It intentionally keeps official/reference data separate from
provisional relational classes and hints.
"""
from __future__ import annotations
from statistics import mean
from .atom_registry import list_elements, get_element, list_isotopes

SHELL_CAPACITIES = {1: 2, 2: 8, 3: 18, 4: 32, 5: 32, 6: 18}

def build_atom_state(symbol: str) -> dict:
    element = get_element(symbol)
    return {
        "identity": {
            "symbol": element["symbol"],
            "name_en": element["name_en"],
            "name_de": element["name_de"],
            "atomic_number": element["atomic_number"],
        },
        "periodic": {
            "group": element["group"],
            "period": element["period"],
            "block": element["block"],
            "class": element["class"],
            "group_family": element["group_family"],
        },
        "state_vector": element["state_template"],
        "electron": {
            "configuration": element["electron_configuration"],
            "outer_electrons": element["outer_electrons"],
            "default_valence": element["default_valence"],
            "valence_list": element["valence_list"],
        },
        "observables": {
            "typical_valence": element["outer_electrons"],
            "default_valence": element["default_valence"],
            "atomic_weight": element["atomic_weight"],
            "covalent_radius_pm": element["covalent_radius_pm"],
            "vdw_radius_pm": element["vdw_radius_pm"],
            "most_common_isotope": element["most_common_isotope"],
            "most_common_isotope_abundance_percent": element["most_common_isotope_abundance_percent"],
        },
        "relational_state": element["state_template"],
        "status": {
            "official_status": element["status"],
            "relational_status": element["relational_status"],
            "compute_ready": element["compute_ready"],
        },
    }

def shell_closure_symbols() -> list[str]:
    return [
        element["symbol"]
        for element in list_elements()
        if element["state_template"]["phase_class"] == "shell_closure"
    ]

def valence_bridge(symbol: str) -> dict:
    element = get_element(symbol)
    outer = element["outer_electrons"]
    if element["group"] == 18:
        tendency = "closed_shell"
    elif outer in (1, 7):
        tendency = "high_reactivity_edge"
    elif outer in (2, 6):
        tendency = "strong_pairing_or_acceptance"
    else:
        tendency = "intermediate_or_transition"
    return {
        "symbol": symbol,
        "outer_electrons": outer,
        "default_valence": element["default_valence"],
        "valence_list": element["valence_list"],
        "group_family": element["group_family"],
        "bridge_tendency": tendency,
        "grid_tension_hint": element["state_template"]["grid_tension_hint"],
    }

def classify_isotope_stability(symbol: str) -> dict:
    isotopes = list_isotopes(symbol)
    if not isotopes:
        raise KeyError(symbol)
    isotope = isotopes[0]
    score = isotope["stability_rule_output"]["score"]
    if score >= 4:
        label = "stable_favored"
    elif score >= 1:
        label = "conditionally_stable"
    else:
        label = "unstable_or_needs_model_refinement"
    return {
        "element": symbol,
        "mass_number": isotope["mass_number"],
        "neutron_number": isotope["neutron_number"],
        "parity_class": isotope["parity_class"],
        "magic_flags": isotope["magic_flags"],
        "score": score,
        "classification": label,
    }

def chemistry_observable_matrix(z_min: int = 1, z_max: int = 20) -> dict:
    rows = []
    selected = [e for e in list_elements() if z_min <= e["atomic_number"] <= z_max]
    for element in selected:
        rows.append({
            "symbol": element["symbol"],
            "atomic_number": element["atomic_number"],
            "period": element["period"],
            "group": element["group"],
            "outer_electrons": element["outer_electrons"],
            "default_valence": element["default_valence"],
            "covalent_radius_pm": element["covalent_radius_pm"],
            "vdw_radius_pm": element["vdw_radius_pm"],
            "atomic_weight": element["atomic_weight"],
        })
    metrics = {
        "count": len(rows),
        "avg_covalent_radius_pm": round(mean(r["covalent_radius_pm"] for r in rows), 3) if rows else None,
        "avg_atomic_weight": round(mean(r["atomic_weight"] for r in rows), 3) if rows else None,
        "shell_closure_symbols": [r["symbol"] for r in rows if r["group"] == 18],
    }
    return {"rows": rows, "metrics": metrics}

def periodic_trend_report() -> dict:
    elements = list_elements()
    by_period = {}
    by_group = {}
    for element in elements:
        by_period.setdefault(str(element["period"]), []).append(element["symbol"])
        key = "inner" if element["group"] is None else str(element["group"])
        by_group.setdefault(key, []).append(element["symbol"])
    return {
        "periods": by_period,
        "groups": by_group,
        "shell_capacity_reference": SHELL_CAPACITIES,
        "shell_closure_symbols": shell_closure_symbols(),
    }


def periodic_trend_slice(z_min: int = 1, z_max: int = 20) -> list[dict]:
    return chemistry_observable_matrix(z_min, z_max)['rows']

def atom_dependency_overview(symbol: str) -> dict:
    element = get_element(symbol)
    direct = list(element.get('dependencies', []))
    if 'global_anchor_387_26' not in direct:
        direct.append('global_anchor_387_26')
    return {
        'symbol': symbol,
        'direct_dependencies': direct,
        'observable_fields': list(element.get('observables', [])),
        'known_unknowns': ['isotope_stability_rule', 'multi_force_chemistry_panel'],
        'compute_ready': bool(element.get('compute_ready')),
    }
