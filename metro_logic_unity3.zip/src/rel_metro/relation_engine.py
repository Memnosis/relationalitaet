from __future__ import annotations
"""Evaluation and diagnostics for official and relational relation objects.

This module intentionally treats relations as testable software entities. Each relation can be
executed, sanity-checked, perturbed and folded into sensitivity or influence outputs. That makes
scientific dependency assumptions inspectable and helps detect coding errors when dependencies are
redefined later.
"""
import math
from .relation_registry import load_relation_registry, relation_index


def compute_on_shell_weinberg(values):
    return 1.0 - (values['w_mass_gev'] / values['m_z_gev']) ** 2


def compute_on_shell_w(values):
    return values['m_z_gev'] * math.sqrt(max(0.0, 1.0 - values['sin2_theta_w']))


def compute_relational_alpha(values):
    return values['alpha_ideal_inv'] + 1.0 / (math.pi * values['anchor_ln_R0_lp'])


def compute_delta_alpha_only(values):
    return 1.0 / (math.pi * values['anchor_ln_R0_lp'])


def compute_relational_higgs(values):
    delta = compute_delta_alpha_only(values)
    return (math.sqrt(8.0 / math.pi**3) + delta) * values['vev_gev']


def compute_relational_weinberg(values):
    delta = compute_delta_alpha_only(values)
    return values['sin2_theta_w_ideal'] - delta


def compute_relational_w_explicit(values):
    delta = compute_delta_alpha_only(values)
    return values['m_z_gev'] * math.sqrt(max(0.0, 1.0 - values['sin2_theta_w_ideal'])) + values['kappa_w'] * delta * values['m_z_gev']


def compute_relational_w_inherited(values):
    delta = compute_delta_alpha_only(values)
    coeff = 1.0 + values['lambda_q'] + values['lambda_l']
    return values['m_z_gev'] * math.sqrt(max(0.0, 1.0 - values['sin2_theta_w_ideal'])) + coeff * delta * values['m_z_gev']


def compute_hierarchy_norms(values):
    gamma = values['gamma_family']
    return {'L_tb': values['gap_tb'] / gamma, 'L_cs': values['gap_cs'] / gamma, 'T_e': values['gap_mu_e'] / gamma - 1.0}


def compute_closure_summary(values):
    return {
        'closure_strength': values['gamma_family'] * (1.0 + values['lambda_q'] + values['lambda_l'] + values['sigma_e']),
        'observable_bridge_strength': values['gamma_family'] * (1.0 + values['lambda_q'] + values['lambda_l']),
    }


def compute_ckm_first_row_unitarity(values):
    return values['Vud'] ** 2 + values['Vus'] ** 2 + values['Vub'] ** 2


def compute_ckm_second_row_unitarity(values):
    return values['Vcd'] ** 2 + values['Vcs'] ** 2 + values['Vcb'] ** 2


def compute_vus_from_wolfenstein(values):
    return values['wolf_lambda']


def compute_vcb_from_wolfenstein(values):
    return values['wolf_A'] * values['wolf_lambda'] ** 2


def registry_only_no_direct_formula(values):
    return {'status': 'registry_only'}


def reference_passthrough(values):
    return None


_BINDINGS = {
    'compute_on_shell_weinberg': compute_on_shell_weinberg,
    'compute_on_shell_w': compute_on_shell_w,
    'reference_passthrough': reference_passthrough,
    'compute_relational_alpha': compute_relational_alpha,
    'compute_delta_alpha_only': compute_delta_alpha_only,
    'compute_relational_higgs': compute_relational_higgs,
    'compute_relational_weinberg': compute_relational_weinberg,
    'compute_relational_w_explicit': compute_relational_w_explicit,
    'compute_relational_w_inherited': compute_relational_w_inherited,
    'compute_hierarchy_norms': compute_hierarchy_norms,
    'compute_closure_summary': compute_closure_summary,
    'compute_ckm_first_row_unitarity': compute_ckm_first_row_unitarity,
    'compute_ckm_second_row_unitarity': compute_ckm_second_row_unitarity,
    'compute_vus_from_wolfenstein': compute_vus_from_wolfenstein,
    'compute_vcb_from_wolfenstein': compute_vcb_from_wolfenstein,
    'registry_only_no_direct_formula': registry_only_no_direct_formula,
}


def evaluate_relation(relation_id: str, values):
    relation = relation_index()[relation_id]
    code_binding = relation.get('code_binding')
    if not code_binding:
        return {'relation': relation, 'computed': {'status': 'registry_only_no_direct_formula'}}
    binding = _BINDINGS[code_binding]
    return {'relation': relation, 'computed': binding(values)}


def evaluate_all_relations(values):
    return {rel['relation_id']: evaluate_relation(rel['relation_id'], values) for rel in load_relation_registry()['relations']}


def _numeric_outputs(relation, computed):
    if isinstance(computed, dict):
        return {k: v for k, v in computed.items() if isinstance(v, (int, float))}
    if len(relation['outputs']) == 1 and isinstance(computed, (int, float)):
        return {relation['outputs'][0]: computed}
    return {}


def build_influence_matrix(sensitivity_matrix):
    matrix = {}
    for src, targets in sensitivity_matrix.items():
        matrix[src] = {}
        for dst, value in targets.items():
            if value is None or abs(value) < 1e-12:
                tag = 'none'
            elif abs(value) < 1e-3:
                tag = 'weak'
            elif abs(value) < 1e-1:
                tag = 'moderate'
            else:
                tag = 'strong'
            matrix[src][dst] = {'sensitivity': value, 'influence': tag}
    return matrix


def relation_test_suite(profile_name='default_project', epsilon=1e-3, layers=None):
    from .pipeline import execute
    baseline = execute(profile_name)
    allowed_layers = set(layers or [])
    relation_results = {}
    sensitivity_matrix = {}
    base_values = {**baseline['config']['values'], **baseline['flat_outputs']}
    for relation in load_relation_registry()['relations']:
        if allowed_layers and relation['layer'] not in allowed_layers:
            continue
        rel_id = relation['relation_id']
        computed = evaluate_relation(rel_id, base_values)['computed']
        numeric = _numeric_outputs(relation, computed)
        relation_results[rel_id] = {
            'layer': relation['layer'],
            'inputs': relation['inputs'],
            'outputs': relation['outputs'],
            'computed': computed,
            'numeric_outputs': numeric,
            'status': 'ok',
        }
        for input_key in [i for i in relation['inputs'] if not i.startswith('reference:')]:
            if input_key not in baseline['config']['values']:
                continue
            base_val = baseline['config']['values'][input_key]
            if not isinstance(base_val, (int, float)):
                continue
            perturbed = execute(profile_name, inline_overrides={input_key: base_val + epsilon})
            sensitivity_matrix.setdefault(input_key, {})
            for output_key in set(list(relation['outputs']) + list(numeric.keys())):
                base_out = baseline['flat_outputs'].get(output_key)
                new_out = perturbed['flat_outputs'].get(output_key)
                if isinstance(base_out, (int, float)) and isinstance(new_out, (int, float)):
                    sensitivity_matrix[input_key][output_key] = (new_out - base_out) / epsilon
                elif output_key in numeric and isinstance(numeric[output_key], (int, float)):
                    p_eval = evaluate_relation(rel_id, {**perturbed['config']['values'], **perturbed['flat_outputs']})['computed']
                    p_num = _numeric_outputs(relation, p_eval)
                    if output_key in p_num:
                        sensitivity_matrix[input_key][output_key] = (p_num[output_key] - numeric[output_key]) / epsilon
    influence_matrix = build_influence_matrix(sensitivity_matrix)
    return {
        'baseline_run_dir': baseline['run_dir'],
        'relation_results': relation_results,
        'sensitivity_matrix': sensitivity_matrix,
        'influence_matrix': influence_matrix,
    }
