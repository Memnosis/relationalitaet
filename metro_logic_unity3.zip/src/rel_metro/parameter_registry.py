from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parents[2]
REGISTRY = ROOT / "configs" / "parameter_registry.json"


def load_parameter_registry() -> list[Dict[str, Any]]:
    with REGISTRY.open("r", encoding="utf-8") as handle:
        return json.load(handle)["elements"]


def registry_index() -> Dict[str, Dict[str, Any]]:
    return {row["id"]: row for row in load_parameter_registry()}
