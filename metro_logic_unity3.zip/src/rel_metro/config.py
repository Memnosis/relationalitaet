from __future__ import annotations
import json
from pathlib import Path
from dataclasses import dataclass
from typing import Any, Dict, Iterable

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / "configs"

@dataclass
class LoadedConfig:
    values: Dict[str, float]
    metadata: Dict[str, Any]
    references: Dict[str, Any]
    profile_name: str
    diff: Dict[str, Dict[str, float]]
    value_catalog: Dict[str, Any]
    active_reference_sets: list[str]


def _read_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def load_project_defaults() -> Dict[str, Any]:
    return _read_json(CONFIGS / "project_data.json")


def load_reference_sets() -> Dict[str, Any]:
    refs = {}
    for path in sorted((CONFIGS / "reference_sets").glob("*.json")):
        refs[path.stem] = _read_json(path)
    return refs


def list_reference_sets() -> list[str]:
    return sorted(load_reference_sets().keys())


def load_profile(name: str = "default_project") -> Dict[str, Any]:
    return _read_json(CONFIGS / "profiles" / f"{name}.json")


def list_profiles() -> list[str]:
    return sorted(path.stem for path in (CONFIGS / "profiles").glob("*.json"))


def save_profile(name: str, payload: Dict[str, Any]) -> Path:
    target = CONFIGS / "profiles" / f"{name}.json"
    _write_json(target, payload)
    return target


def collect_value_catalog() -> Dict[str, Any]:
    project = load_project_defaults()
    catalog = {}
    for key, entry in project.get("project_values", {}).items():
        catalog[key] = {
            "value": entry.get("value"),
            "status": entry.get("status"),
            "editable": entry.get("editable", True),
            "description_de": entry.get("description_de", ""),
            "description_en": entry.get("description_en", ""),
        }
    return catalog


def _filter_references(reference_sets: Dict[str, Any], active_names: Iterable[str] | None) -> Dict[str, Any]:
    if not active_names:
        return reference_sets
    active = list(active_names)
    return {name: reference_sets[name] for name in active if name in reference_sets}


def merge_config(
    profile_name: str = "default_project",
    inline_overrides: Dict[str, float] | None = None,
    active_reference_sets: list[str] | None = None,
) -> LoadedConfig:
    project = load_project_defaults()
    all_references = load_reference_sets()
    profile = load_profile(profile_name)
    value_catalog = collect_value_catalog()
    values = {key: entry["value"] for key, entry in project["project_values"].items()}
    diff: Dict[str, Dict[str, float]] = {}
    for key, new_value in profile.get("overrides", {}).items():
        old_value = values.get(key)
        values[key] = new_value
        diff[key] = {"old": old_value, "new": new_value}
    if inline_overrides:
        for key, new_value in inline_overrides.items():
            old_value = values.get(key)
            values[key] = new_value
            diff[key] = {"old": old_value, "new": new_value}
    selected_reference_sets = active_reference_sets or profile.get("reference_sets") or list(all_references.keys())
    references = _filter_references(all_references, selected_reference_sets)
    metadata = project.get("metadata", {}).copy()
    metadata.update(profile.get("metadata", {}))
    metadata["project_dataset"] = project.get("metadata", {}).get("dataset_name")
    metadata["profile_name"] = profile_name
    metadata["active_reference_sets"] = selected_reference_sets
    return LoadedConfig(
        values=values,
        metadata=metadata,
        references=references,
        profile_name=profile_name,
        diff=diff,
        value_catalog=value_catalog,
        active_reference_sets=list(selected_reference_sets),
    )
