
from __future__ import annotations
"""HTTP API for external orchestration of rel_metro."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
from .pipeline import execute
from .config import list_profiles, list_reference_sets
from .parameter_registry import load_parameter_registry
from .dependency import graph_snapshot, explain_node
from .profile_manager import save_profile
from .comparison import compare_runs, compare_run_directories
from .benchmarks import run_profile_series
from .relation_registry import load_relation_registry
from .paper_registry import load_paper_registry
from .formula_registry import load_formula_registry
from .doi_provenance import relation_provenance, paper_effect_summary
from .graph_workbench import list_views, canvas_view, list_tours, list_snippets, inspect_node as graph_inspect_node, inspect_edge as graph_inspect_edge, update_edge as graph_update_edge, update_multiple_edges as graph_update_multiple_edges, update_node as graph_update_node, update_multiple_nodes as graph_update_multiple_nodes, save_node_positions as graph_save_node_positions, run_tour as graph_run_tour
from .force_research_program import list_force_research_questions, question_summary as force_question_summary, research_gap_matrix, software_requirement_matrix, recommended_next_steps, relational_research_program_report
from .research_analysis import scientific_analysis_report
from .research_workbench import build_workbench_payload, write_workbench_payload
from metro_logic.bundle_ingest import bundle_schema, import_bundle, list_uploaded_bundles, load_uploaded_bundle_details


class _Handler(BaseHTTPRequestHandler):
    server_version = 'rel_metro_api/2.7'

    def _send(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get('Content-Length', '0'))
        raw = self.rfile.read(length) if length else b'{}'
        return json.loads(raw.decode('utf-8'))

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/health':
            return self._send(200, {'status': 'ok'})
        if parsed.path == '/profiles':
            return self._send(200, {'profiles': list_profiles()})
        if parsed.path == '/references':
            return self._send(200, {'reference_sets': list_reference_sets()})
        if parsed.path == '/registry':
            return self._send(200, {'parameter_registry': load_parameter_registry()})
        if parsed.path == '/relations':
            return self._send(200, load_relation_registry())
        if parsed.path == '/dependencies':
            qs = parse_qs(parsed.query); node = qs.get('node', [None])[0]
            return self._send(200, {'graph': graph_snapshot(), 'selected': explain_node(node) if node else None})
        if parsed.path == '/papers':
            return self._send(200, load_paper_registry())
        if parsed.path == '/formulas':
            return self._send(200, load_formula_registry())
        if parsed.path == '/relation-provenance':
            rel = parse_qs(parsed.query).get('relation_id', [None])[0]
            return self._send(200, relation_provenance(rel) if rel else {'error': 'missing_relation_id'})
        if parsed.path == '/graph/views':
            return self._send(200, {'views': list_views()})
        if parsed.path == '/graph/tours':
            return self._send(200, {'tours': list_tours()})
        if parsed.path == '/graph/snippets':
            return self._send(200, {'snippets': list_snippets()})
        if parsed.path == '/graph/view':
            qs = parse_qs(parsed.query)
            view_id = qs.get('view_id', ['core_relational_map'])[0]
            text_filter = qs.get('text', [''])[0]
            group_by = qs.get('group_by', [None])[0]
            return self._send(200, canvas_view(view_id, filters={'text': text_filter} if text_filter else None, group_by=group_by))
        if parsed.path == '/graph/node':
            qs = parse_qs(parsed.query)
            return self._send(200, graph_inspect_node(qs.get('view_id', ['core_relational_map'])[0], qs['node_id'][0]))
        if parsed.path == '/graph/edge':
            qs = parse_qs(parsed.query)
            return self._send(200, graph_inspect_edge(qs.get('view_id', ['core_relational_map'])[0], qs['edge_id'][0]))
        if parsed.path == '/paper-effects':
            doc = parse_qs(parsed.query).get('doc_id', [None])[0]
            return self._send(200, paper_effect_summary(doc) if doc else {'error': 'missing_doc_id'})
        if parsed.path == '/research/questions':
            qs = parse_qs(parsed.query)
            theme_id = qs.get('theme_id', [None])[0]
            force = qs.get('force', [None])[0]
            only_blocked = qs.get('only_blocked', ['false'])[0].lower() in {'1','true','yes'}
            return self._send(200, {'questions': list_force_research_questions(theme_id=theme_id, force=force, only_blocked=only_blocked)})
        if parsed.path == '/research/questions/summary':
            return self._send(200, force_question_summary())
        if parsed.path == '/research/gaps':
            return self._send(200, {'gaps': research_gap_matrix()})
        if parsed.path == '/research/software-requirements':
            return self._send(200, {'capabilities': software_requirement_matrix()})
        if parsed.path == '/research/program-report':
            return self._send(200, relational_research_program_report())
        if parsed.path == '/research/scientific-analysis':
            return self._send(200, scientific_analysis_report())
        if parsed.path == '/research/workbench':
            qs = parse_qs(parsed.query)
            return self._send(200, build_workbench_payload(view_id=qs.get('view_id', ['core_relational_map'])[0], language=qs.get('language', ['de'])[0]))
        if parsed.path == '/bundle/schema':
            return self._send(200, bundle_schema())
        if parsed.path == '/bundle/registry':
            return self._send(200, {'bundles': list_uploaded_bundles(), 'details': load_uploaded_bundle_details()})
        self._send(404, {'error': 'not_found', 'path': parsed.path})

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path == '/run':
                payload = self._read_json()
                return self._send(200, execute(payload.get('profile_name', 'default_project'), inline_overrides=payload.get('inline_overrides'), active_reference_sets=payload.get('active_reference_sets'), run_relation_tests=payload.get('run_relation_tests', False)))
            if parsed.path == '/profiles/import':
                payload = self._read_json(); name = payload.get('profile_name') or 'imported_profile'
                save_profile(name, payload.get('overrides', {}), metadata=payload.get('metadata'), reference_sets=payload.get('reference_sets'))
                return self._send(200, {'saved_profile': name})
            if parsed.path == '/compare':
                payload = self._read_json(); left = execute(payload.get('left_profile', 'default_project')); right = execute(payload.get('right_profile', 'sanity_shifted'))
                return self._send(200, compare_runs(left, right))
            if parsed.path == '/compare-runs':
                payload = self._read_json()
                return self._send(200, compare_run_directories(payload['left_run_dir'], payload['right_run_dir']))
            if parsed.path in ('/benchmarks/run', '/benchmarks/series'):
                payload = self._read_json(); profiles = payload.get('profiles', ['default_project', 'sanity_shifted', 'closure_inherited'])
                return self._send(200, run_profile_series(profiles, run_relation_tests=payload.get('run_relation_tests', False)))
            if parsed.path == '/graph/edge/update':
                payload = self._read_json()
                return self._send(200, graph_update_edge(payload['edge_id'], payload.get('updates', {})))
            if parsed.path == '/graph/edges/update':
                payload = self._read_json()
                return self._send(200, graph_update_multiple_edges(payload.get('updates', [])))
            if parsed.path == '/graph/node/update':
                payload = self._read_json()
                return self._send(200, graph_update_node(payload['node_id'], payload.get('updates', {})))
            if parsed.path == '/graph/nodes/update':
                payload = self._read_json()
                return self._send(200, graph_update_multiple_nodes(payload.get('updates', [])))
            if parsed.path == '/graph/node/positions':
                payload = self._read_json()
                return self._send(200, graph_save_node_positions(payload.get('positions', [])))
            if parsed.path == '/graph/tour/run':
                payload = self._read_json()
                return self._send(200, graph_run_tour(payload.get('tour_id', 'software_intro'), profile_name=payload.get('profile_name', 'default_project'), active_reference_sets=payload.get('active_reference_sets')))
            if parsed.path == '/research/workbench/export':
                path = write_workbench_payload()
                return self._send(200, {'written': str(path)})
            if parsed.path == '/bundle/import':
                payload = self._read_json()
                return self._send(200, import_bundle(payload))
            self._send(404, {'error': 'not_found', 'path': parsed.path})
        except Exception as exc:
            self._send(500, {'error': 'server_error', 'message': str(exc)})


def make_server(host='127.0.0.1', port=0):
    return ThreadingHTTPServer((host, port), _Handler)


def serve(host='127.0.0.1', port=8765):
    httpd = make_server(host, port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
