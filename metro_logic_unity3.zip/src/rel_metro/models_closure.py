from __future__ import annotations

def run_closure(values):
    summary = {'gamma_family': values['gamma_family'], 'lambda_q': values['lambda_q'], 'lambda_l': values['lambda_l'], 'sigma_e': values['sigma_e'], 'closure_strength': values['gamma_family'] * (1.0 + values['lambda_q'] + values['lambda_l'] + values['sigma_e'])}
    return {'outputs': {'closure_summary': summary}, 'derived_values': summary, 'steps': ['closure diagnostics from gamma, lambda_q, lambda_l, sigma_e']}
