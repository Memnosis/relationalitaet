from __future__ import annotations
import json, datetime
from pathlib import Path
from dataclasses import dataclass

ROOT = Path(__file__).resolve().parents[2]
RUNS = ROOT / 'runs'

@dataclass
class RunLogger:
    run_dir: Path

    @classmethod
    def create(cls, prefix: str) -> 'RunLogger':
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        run_dir = RUNS / f'{prefix}_{ts}'
        for folder in ['meta','inputs','logs','outputs','reports']:
            (run_dir/folder).mkdir(parents=True, exist_ok=True)
        return cls(run_dir)

    def write_json(self, relative: str, payload):
        target = self.run_dir / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

    def write_markdown(self, relative: str, content: str):
        target = self.run_dir / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding='utf-8')

    def log(self, stream: str, event: str, payload):
        target = self.run_dir / 'logs' / f'{stream}.jsonl'
        row = {'event': event, 'payload': payload}
        with target.open('a', encoding='utf-8') as handle:
            handle.write(json.dumps(row, ensure_ascii=False) + '\n')
