from __future__ import annotations
"""Dependency graph utilities for direct and indirect value propagation."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'


def _load_registry():
    with (CONFIGS / 'dependency_registry.json').open('r', encoding='utf-8') as handle:
        return json.load(handle)


def graph_snapshot():
    payload = _load_registry()
    nodes = payload.get('nodes', [])
    edges = payload.get('edges', [])
    positions = {}
    radius = 150
    cx, cy = 300, 180
    import math
    norm_nodes = []
    for idx, node in enumerate(nodes):
        node_id = node['id'] if isinstance(node, dict) else node
        angle = (2 * math.pi * idx) / max(1, len(nodes))
        positions[node_id] = {'x': cx + radius * math.cos(angle), 'y': cy + radius * math.sin(angle)}
        norm_nodes.append(node if isinstance(node, dict) else {'id': node_id})
    return {'nodes': norm_nodes, 'edges': edges, 'positions': positions}


def explain_node(node_id: str | None):
    snap = graph_snapshot()
    if not node_id:
        return None
    node = next((n for n in snap['nodes'] if n['id'] == node_id), None)
    incoming = [e for e in snap['edges'] if e['to'] == node_id]
    outgoing = [e for e in snap['edges'] if e['from'] == node_id]
    return {'node': node, 'incoming': incoming, 'outgoing': outgoing}


def recompute_plan(changed_keys):
    snap = graph_snapshot()
    changed = set(changed_keys)
    affected = set(changed)
    frontier = list(changed)
    while frontier:
        current = frontier.pop(0)
        for edge in snap['edges']:
            if edge['from'] == current and edge['to'] not in affected:
                affected.add(edge['to'])
                frontier.append(edge['to'])
    ordered = [n['id'] for n in snap['nodes'] if n['id'] in affected]
    return {'changed_inputs': sorted(changed), 'affected_nodes': ordered, 'graph_layout': {'positions': snap['positions']}}


def impacted_nodes(changed_keys):
    return recompute_plan(changed_keys)['affected_nodes']
