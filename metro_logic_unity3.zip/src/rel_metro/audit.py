from __future__ import annotations

def build_audit(outputs, references):
    audit = {}
    ref_observables = {}
    for ref in references.values():
        ref_observables.update(ref.get('observables', {}))
    for key, val in outputs.items():
        ref = ref_observables.get(key)
        if ref is None or not isinstance(val, (int, float)):
            audit[key] = {'status': 'not_comparable', 'reference': None, 'difference': None, 'sigma': None}
            continue
        diff = val - ref['value']
        sigma = diff / ref['uncertainty'] if ref.get('uncertainty') else None
        status = 'exact_hit' if abs(diff) < 1e-12 else ('near_hit' if sigma is not None and abs(sigma) <= 1.0 else 'tension')
        audit[key] = {'status': status, 'reference': ref['value'], 'uncertainty': ref.get('uncertainty'), 'difference': diff, 'sigma': sigma}
    return audit
