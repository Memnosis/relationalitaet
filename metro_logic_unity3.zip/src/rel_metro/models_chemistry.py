
from __future__ import annotations
"""Chemistry sector wrapper for the integrated pipeline.

This sector does not claim a closed relational chemistry derivation. It exposes
stable data-driven summary observables so chemistry/atom information becomes part
of the same audited and logged run as the particle and relation sectors.
"""
from .atom_registry import list_elements, list_isotopes
from .atom_bridge import shell_closure_symbols, chemistry_observable_matrix, periodic_trend_report


def run_chemistry(values: dict) -> dict:
    elements = list_elements()
    isotopes = list_isotopes()
    matrix = chemistry_observable_matrix(1, 20)
    trend = periodic_trend_report()
    outputs = {
        'chemistry_element_count': len(elements),
        'chemistry_isotope_count': len(isotopes),
        'chemistry_shell_closure_count': len(shell_closure_symbols()),
        'chemistry_avg_atomic_weight_1_20': matrix['metrics']['avg_atomic_weight'],
    }
    return {
        'inputs': {'chemistry_registry_loaded': True},
        'derived_values': {
            'shell_closure_symbols': shell_closure_symbols(),
            'period_count': len(trend['periods']),
            'group_count': len(trend['groups']),
        },
        'steps': [
            'load chemistry element registry',
            'load isotope registry',
            'compute shell closure signatures',
            'compute observable matrix for elements 1..20',
        ],
        'outputs': outputs,
        'messages': ['Chemistry sector is data-rich and partially compute-ready.'],
    }
