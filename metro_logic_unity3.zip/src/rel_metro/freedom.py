from __future__ import annotations
"""Freedom and prediction balance diagnostics."""
from .parameter_registry import load_parameter_registry

def freedom_balance(flat_outputs: dict, config_values: dict) -> dict:
    registry = load_parameter_registry()
    by_status = {}
    editable = 0
    for item in registry:
        status = item.get("status", "unknown")
        by_status[status] = by_status.get(status, 0) + 1
        if item.get("editable"):
            editable += 1
    return {
        "registered_parameter_count": len(registry),
        "configured_value_count": len(config_values),
        "computed_output_count": len(flat_outputs),
        "editable_parameter_count": editable,
        "status_counts": by_status,
        "provisional_parameter_count": by_status.get("project_provisional", 0),
    }
