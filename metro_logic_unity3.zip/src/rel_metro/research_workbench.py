
from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .graph_workbench import GraphWorkbench
from .formula_registry import load_formula_registry
from .standard_model_registry import load_standard_model_registry
from .snippet_library import load_snippet_library
from .tour_catalog import load_combined_tours
from .research_analysis import scientific_analysis_report
from .force_research_program import relational_research_program_report

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'
DOCS = ROOT / 'docs'
TESTS = ROOT / 'tests'

MENU_EXPLANATIONS = {
    'explore': {'de': 'Canvas-Ansicht für Knoten, Kanten, Formeln und Datengüte. Hier beginnst du mit Suche, Hover, Klick und Touren.', 'en': 'Canvas view for nodes, edges, formulas, and data quality. Start here with search, hover, click, and tours.'},
    'physics': {'de': 'Physik-Fokus: Grundkräfte, Träger, Standardformeln, QC-Labels und Forschungsfragen.', 'en': 'Physics focus: fundamental forces, carriers, standard formulas, QC labels, and research questions.'},
    'chemistry': {'de': 'Chemie-Fokus: Elemente, Isotope, Brücken zur Physik und fehlende Datensätze für belastbare Schlüsse.', 'en': 'Chemistry focus: elements, isotopes, bridges to physics, and missing datasets for reliable conclusions.'},
    'relational': {'de': 'Relationaler Modus: REL0/REL1, Anker, Hypothesen, Provenienz und Nachrechenpflicht.', 'en': 'Relational mode: REL0/REL1, anchors, hypotheses, provenance, and recalculation obligations.'},
    'tours': {'de': 'Geführte Einstiege in Software, Physik, Chemie und relationale Forschung.', 'en': 'Guided introductions to software, physics, chemistry, and relational research.'},
    'tests': {'de': 'Zeigt Funktions-, Stabilitäts- und Forschungs-Tests sowie bekannte Datenlücken.', 'en': 'Shows functional, stability, and research tests together with known data gaps.'},
    'docs': {'de': 'Kurz erklärter Zugang zu Spezifikation, Pflichtenheft, Doku und Forschungsberichten.', 'en': 'Short guided access to specification, duty matrix, docs, and research reports.'},
}


def _read_json(path: Path, default: Any):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default


def _data_quality_label(status: str | None) -> str:
    status = (status or '').lower()
    if 'official' in status or 'reference' in status:
        return 'official_reference'
    if 'provisional' in status or 'project' in status:
        return 'relational_hypothesis'
    if 'registry_only' in status:
        return 'partial_registry'
    if 'derived' in status:
        return 'derived'
    return 'partial_registry'


def _test_summary() -> dict[str, Any]:
    collected = []
    for path in sorted(TESTS.glob('test_*.py')):
        collected.append({'id': path.stem, 'title': path.stem.replace('_', ' '), 'path': path.relative_to(ROOT).as_posix(), 'category': 'verification' if 'api' in path.stem or 'graph' in path.stem or 'release' in path.stem else 'research'})
    return {'count': len(collected), 'items': collected, 'how_to_run': 'python -m pytest tests -q'}


def _docs_summary() -> list[dict[str, Any]]:
    docs = []
    for path in sorted(DOCS.glob('*.md')):
        lines = path.read_text(encoding='utf-8').splitlines()
        preview = next((ln.strip() for ln in lines if ln.strip()), '')
        docs.append({'title': path.name, 'path': path.relative_to(ROOT).as_posix(), 'preview': preview[:180]})
    return docs[:25]


def _formula_cards() -> list[dict[str, Any]]:
    formulas = load_formula_registry().get('formulas', [])
    cards = []
    for formula in formulas:
        cards.append({'formula_id': formula['formula_id'], 'name': formula['name'], 'latex': formula.get('equation_latex', ''), 'status': formula.get('status', 'unknown'), 'quality_label': _data_quality_label(formula.get('status')), 'inputs': formula.get('inputs', []), 'outputs': formula.get('outputs', []), 'source_doc_id': formula.get('source_doc_id'), 'relation_ids': formula.get('relation_ids', [])})
    return cards


def _analysis_summary(analysis: dict[str, Any], program: dict[str, Any]) -> dict[str, Any]:
    return {
        'total_questions': program.get('question_summary', {}).get('question_count', 0),
        'blocked_questions': program.get('question_summary', {}).get('blocked_question_count', 0),
        'official_relations': sum(1 for row in analysis.get('clear_relationships', []) if row.get('relationship_status') == 'officially_clear'),
        'relational_recalculation_required': len(analysis.get('relational_recalculation_targets', [])),
    }


def build_workbench_payload(view_id: str = 'core_relational_map', language: str = 'de') -> dict[str, Any]:
    graph = GraphWorkbench()
    canvas = graph.build_canvas(view_id)
    analysis = scientific_analysis_report()
    program = relational_research_program_report()
    interactions = load_standard_model_registry().get('interactions', [])
    snippet_library = load_snippet_library().get('snippets', [])
    tours = load_combined_tours().get('tours', [])

    dataset_inventory = {
        'elements': len(_read_json(CONFIGS / 'atom_registry.json', {}).get('elements', [])),
        'isotopes': len(_read_json(CONFIGS / 'isotope_registry.json', {}).get('isotopes', [])),
        'forces': len(interactions),
        'snippets': len(snippet_library),
        'tours': len(tours),
        'formulas': len(_formula_cards()),
        'research_questions': program.get('question_summary', {}).get('question_count', 0),
    }
    analysis['summary'] = _analysis_summary(analysis, program)
    return {'metadata': {'app_name': 'rel_metro Block 11 Research Workbench', 'default_language': language, 'supported_languages': ['de', 'en']}, 'menu_explanations': MENU_EXPLANATIONS, 'canvas': canvas, 'interactions': interactions, 'formulas': _formula_cards(), 'snippets': snippet_library, 'tours': tours, 'research_program': {'summary': program.get('question_summary', {}), 'questions': load_force_questions(program), 'gap_matrix': program.get('gap_matrix', []), 'software_requirements': program.get('software_requirements', []), 'recommended_next_steps': [item.get('question', item) if isinstance(item, dict) else item for item in program.get('next_steps', [])]}, 'scientific_analysis': analysis, 'tests': _test_summary(), 'docs': _docs_summary(), 'dataset_inventory': dataset_inventory}


def load_force_questions(program: dict[str, Any]) -> list[dict[str, Any]]:
    payload = _read_json(CONFIGS / 'force_research_questions_registry.json', {})
    return payload.get('questions', [])[:100]


def write_workbench_payload(destination: str | Path | None = None) -> Path:
    destination = Path(destination) if destination else ROOT / 'web' / 'data' / 'workbench_payload.json'
    payload = build_workbench_payload()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    return destination
