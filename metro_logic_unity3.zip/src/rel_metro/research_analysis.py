from __future__ import annotations
import json
from collections import Counter, defaultdict
from pathlib import Path
from .force_research_program import load_force_research_questions, research_gap_matrix, software_requirement_matrix
from .research_questions import data_inventory, detect_missing_data_profiles, relational_force_requirements, challenge_map_standard_model
from .standard_model_registry import list_interactions

ROOT = Path(__file__).resolve().parents[2]


def official_force_map() -> list[dict]:
    """Return the currently explicit official interaction objects in the project."""
    rows = []
    for item in list_interactions():
        rows.append({
            'force_id': item.get('id') or item.get('interaction_id') or item.get('name_en') or item.get('name'),
            'name_en': item.get('name_en') or item.get('name') or item.get('id', 'unknown'),
            'name_de': item.get('name_de') or item.get('name') or item.get('id', 'unbekannt'),
            'carrier': item.get('carrier', 'unspecified'),
            'status': item.get('status', 'unknown'),
        })
    return rows


def force_question_force_map() -> dict:
    payload = load_force_research_questions()
    counter = Counter(force for item in payload.get('questions', []) for force in item.get('forces', []))
    return dict(counter)


def clear_object_relationships() -> list[dict]:
    payload = load_force_research_questions()
    rows: dict[tuple[str, str], dict] = {}
    for item in payload.get('questions', []):
        forces = sorted(item.get('forces', []))
        for i, left in enumerate(forces):
            for right in forces[i+1:]:
                key = (left, right)
                row = rows.setdefault(key, {
                    'left': left,
                    'right': right,
                    'question_count': 0,
                    'blocked_question_count': 0,
                    'example_observables': set(),
                    'needs_relational_recalculation': False,
                    'relationship_status': 'hypothesis',
                })
                row['question_count'] += 1
                if item.get('blocked_by_missing_data'):
                    row['blocked_question_count'] += 1
                row['example_observables'].update(item.get('measurable_observables', [])[:2])
                if 'gravity_interface' in key:
                    row['needs_relational_recalculation'] = True
                    row['relationship_status'] = 'relational_bridge_needed'
                elif key == ('electromagnetic', 'weak'):
                    row['relationship_status'] = 'officially_clear'
                elif 'strong' in key and 'weak' in key:
                    row['relationship_status'] = 'experimentally_indirect'
                elif 'electromagnetic' in key and 'strong' in key:
                    row['relationship_status'] = 'chemistry_bridge_candidate'
                else:
                    row['needs_relational_recalculation'] = True
        
    result = []
    for row in rows.values():
        row['example_observables'] = sorted(row['example_observables'])[:4]
        if row['relationship_status'] != 'officially_clear' and row['blocked_question_count'] > 0:
            row['needs_relational_recalculation'] = True
        result.append(row)
    result.sort(key=lambda r: (-r['question_count'], -r['blocked_question_count'], r['left'], r['right']))
    return result


def dataset_reliability_summary() -> dict:
    payload = load_force_research_questions()
    bank = payload.get('dataset_bank', {})
    inventory = data_inventory()
    missing_profiles = detect_missing_data_profiles()
    question_counter = Counter()
    for item in payload.get('questions', []):
        for dataset_id in item.get('required_datasets', []):
            question_counter[dataset_id] += 1
    statuses = Counter(info.get('status', 'unknown') for info in bank.values())
    present = [k for k, info in bank.items() if info.get('status') == 'present']
    partial = [k for k, info in bank.items() if info.get('status') == 'partial']
    missing = [k for k, info in bank.items() if info.get('status') == 'missing']
    return {
        'inventory': inventory,
        'dataset_status_counts': dict(statuses),
        'present_datasets': sorted(present),
        'partial_datasets': sorted(partial),
        'missing_datasets': sorted(missing),
        'most_blocking_datasets': [
            {'dataset_id': dataset_id, 'question_count': question_counter[dataset_id], 'status': bank.get(dataset_id, {}).get('status', 'unknown')}
            for dataset_id, _ in question_counter.most_common()
        ],
        'missing_profiles': missing_profiles,
    }


def relational_recalculation_targets() -> list[dict]:
    rows = []
    payload = load_force_research_questions()
    bank = payload.get('dataset_bank', {})
    for req in relational_force_requirements():
        force = req['force']
        related_questions = [q for q in payload.get('questions', []) if force in q.get('forces', [])]
        missing_data = sorted({ds for q in related_questions for ds, st in q.get('dataset_status', {}).items() if st != 'available'})
        rows.append({
            'force': force,
            'required_relational_quantities': req['required_relational_quantities'],
            'question_count': len(related_questions),
            'missing_or_partial_datasets': missing_data,
            'why_not_yet_derived': [bank.get(ds, {}).get('why', 'dataset not modeled') for ds in missing_data[:4]],
        })
    rows.sort(key=lambda r: (-r['question_count'], r['force']))
    return rows


def optimization_results() -> dict:
    gaps = research_gap_matrix()
    capabilities = software_requirement_matrix()
    relationships = clear_object_relationships()
    return {
        'top_software_priorities': [
            {
                'capability_id': row['capability_id'],
                'question_count': row['question_count'],
                'blocked_question_count': row['blocked_question_count'],
                'reason': row['description'],
            }
            for row in capabilities[:6]
        ],
        'top_dataset_priorities': [
            {
                'dataset_id': row['dataset_id'],
                'status': row['status'],
                'question_count': row['question_count'],
                'reason': row['why'],
            }
            for row in gaps[:6]
        ],
        'relationship_hotspots': relationships[:6],
        'standard_model_challenge_map': challenge_map_standard_model(),
        'recommended_expansions': [
            'Executable running-coupling grid with provenance and uncertainty propagation',
            'Cross-sector threshold matrix spanning particle, atomic and chemical levels',
            'Snippet-to-edge compiler with LaTeX formula rendering and validation hooks',
            'Relational recalculation workspace separating official references from derived claims',
            'Graph explorer mode for blocked questions, missing datasets and falsification paths',
            'Dataset QC checks that label every data object as official, partial, estimated or relationally derived',
        ],
    }


def scientific_analysis_report() -> dict:
    return {
        'official_force_map': official_force_map(),
        'force_mentions': force_question_force_map(),
        'clear_relationships': clear_object_relationships(),
        'dataset_reliability': dataset_reliability_summary(),
        'relational_recalculation_targets': relational_recalculation_targets(),
        'optimization_results': optimization_results(),
    }


def write_scientific_analysis_report(path: str | Path | None = None) -> Path:
    target = Path(path) if path else ROOT / 'docs' / 'BLOCK10_SCIENTIFIC_ANALYSIS_REPORT.json'
    payload = scientific_analysis_report()
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    return target
