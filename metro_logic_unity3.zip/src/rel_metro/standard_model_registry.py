from __future__ import annotations
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

def load_standard_model_registry() -> dict:
    return json.loads((ROOT / 'configs' / 'standard_model_full_registry.json').read_text(encoding='utf-8'))

def list_interactions() -> list[dict]:
    return load_standard_model_registry().get('interactions', [])

def list_sm_parameters() -> list[dict]:
    return load_standard_model_registry().get('sm26_parameters', [])

def interaction_index() -> dict[str, dict]:
    rows = {}
    for item in list_interactions():
        key = item.get('interaction_id') or item.get('name') or item.get('force') or f"interaction_{len(rows)+1}"
        rows[key] = item
    return rows

def get_interaction(interaction_id: str) -> dict:
    idx = interaction_index()
    if interaction_id in idx:
        return idx[interaction_id]
    raise KeyError(interaction_id)

def list_particles() -> list[dict]:
    seen, items = set(), []
    for interaction in list_interactions():
        for key in ('gauge_bosons', 'fermions', 'participants', 'mediators'):
            for value in interaction.get(key, []) or []:
                if isinstance(value, dict):
                    pid = value.get('id') or value.get('symbol') or value.get('name')
                    particle = value
                else:
                    pid = str(value)
                    particle = {'name': str(value)}
                if pid and pid not in seen:
                    seen.add(pid)
                    items.append(particle)
    return items

def interaction_summary() -> dict:
    interactions = list_interactions()
    return {'interaction_count': len(interactions), 'parameter_count': len(list_sm_parameters()), 'particle_count': len(list_particles())}
