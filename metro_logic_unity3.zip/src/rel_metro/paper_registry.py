
from __future__ import annotations
"""Registry for DOI and project source papers used in rel_metro.

This layer preserves provenance so users can see which paper contributes which concepts and so
future code changes can be tested against source-linked expectations.
"""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'

def load_paper_registry() -> dict:
    return json.loads((CONFIGS / 'paper_registry.json').read_text(encoding='utf-8'))

def paper_index() -> dict:
    return {p['doc_id']: p for p in load_paper_registry().get('papers', [])}
