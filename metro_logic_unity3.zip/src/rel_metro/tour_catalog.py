
from __future__ import annotations
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

def _load(name: str) -> list[dict]:
    path = ROOT / 'configs' / name
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding='utf-8')).get('tours', [])

def list_all_tours() -> list[dict]:
    seen = {}
    for tour in _load('tour_registry.json') + _load('chemistry_tour_registry.json') + _load('atom_tour_registry.json'):
        tid = tour.get('tour_id') or tour.get('id') or f"tour_{len(seen)+1}"
        seen.setdefault(tid, {**tour, 'tour_id': tid})
    return list(seen.values())

def load_combined_tours() -> dict:
    return {'tours': list_all_tours()}

def tour_index() -> dict[str, dict]:
    return {item['tour_id']: item for item in list_all_tours()}

def get_tour(tour_id: str) -> dict:
    return tour_index()[tour_id]

def tours_by_theme(theme: str) -> list[dict]:
    theme = theme.lower().strip()
    return [item for item in list_all_tours() if theme in ' '.join(str(item.get(k, '')) for k in ('title', 'description_en', 'description_de', 'category', 'theme')).lower()]

def tour_summary() -> dict:
    tours = list_all_tours()
    return {'tour_count': len(tours), 'step_count': sum(len(t.get('steps', [])) for t in tours)}
