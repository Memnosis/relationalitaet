from __future__ import annotations
"""UI model builders.

These helpers turn backend payloads into GUI-ready dictionaries without forcing the GUI itself to
know registry internals. The same view models are easy to test and can later back a web frontend.
"""
from .config import list_profiles, list_reference_sets, merge_config
from .parameter_registry import load_parameter_registry
from .relation_registry import grouped_relations
from .dependency import graph_snapshot, explain_node
from .graph_workbench import list_views, canvas_view, list_tours, list_snippets, inspect_node as gw_inspect_node, inspect_edge as gw_inspect_edge


def build_start_view():
    return {
        'profiles': list_profiles(),
        'reference_sets': {name: {'id': name} for name in list_reference_sets()},
        'registry_count': len(load_parameter_registry()),
        'relation_groups': {k: len(v) for k, v in grouped_relations().items()},
        'graph_views': list_views(),
        'graph_tours': list_tours(),
    }


def build_inputs_view(values, profile_name='default_project'):
    cfg = merge_config(profile_name)
    rows = []
    for key, meta in cfg.value_catalog.items():
        rows.append({'id': key, 'value': values.get(key), 'status': meta['status'], 'editable': meta['editable'], 'description_de': meta['description_de'], 'description_en': meta['description_en']})
    return rows


def build_results_view(run):
    return {'metrics': run['metrics'], 'flat_outputs': run['flat_outputs'], 'results': run['results'], 'run_dir': run['run_dir']}


def build_audit_view(run):
    return run['audit']


def build_dependency_view(node_id=None):
    graph = graph_snapshot()
    return {'graph': {'nodes': graph['nodes'], 'edges': graph['edges']}, 'graph_layout': {'positions': graph['positions']}, 'selected': explain_node(node_id) if node_id else None}


def build_dataset_admin_view():
    return {'message': 'dataset admin ready', 'profiles': list_profiles(), 'reference_sets': list_reference_sets()}


def build_graph_views_view():
    return {'views': list_views(), 'tours': list_tours(), 'snippets': list_snippets()}


def build_graph_canvas_view(view_id='core_relational_map', filters=None, group_by=None):
    return canvas_view(view_id, filters=filters, group_by=group_by)


def build_graph_tours_view():
    return {'tours': list_tours()}


def build_graph_snippets_view():
    return {'snippets': list_snippets()}


def build_graph_node_inspector(view_id: str, node_id: str):
    return gw_inspect_node(view_id, node_id)


def build_graph_edge_inspector(view_id: str, edge_id: str):
    return gw_inspect_edge(view_id, edge_id)
