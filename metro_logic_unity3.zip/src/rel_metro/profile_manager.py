from __future__ import annotations
from .config import load_profile, list_profiles as _list_profiles, save_profile as _save_profile


def list_profiles():
    return _list_profiles()


def read_profile(name):
    return load_profile(name)


def save_profile(name, overrides, metadata=None, reference_sets=None):
    payload = {'metadata': metadata or {'title': name}, 'reference_sets': reference_sets or [], 'overrides': overrides}
    return _save_profile(name, payload)
