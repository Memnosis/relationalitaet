
from __future__ import annotations
"""Interactive graph workbench backend.

This module provides a persistent, testable canvas model for the scientific graph UI. It turns
nodes, edges, tours and snippets into first-class runtime objects so that the GUI, API and tests
all use the same semantics.
"""
from dataclasses import dataclass, asdict
import json
from pathlib import Path
from typing import Any

from .pipeline import execute
from .dependency import graph_snapshot

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'


@dataclass(slots=True)
class GraphNode:
    id: str
    label: str
    category: str
    short_info_en: str
    short_info_de: str
    long_info_en: str
    long_info_de: str
    status: str
    x: float = 0.0
    y: float = 0.0
    group: str | None = None
    visible: bool = True
    quality_label: str = 'partial_registry'


@dataclass(slots=True)
class GraphEdge:
    id: str
    source: str
    target: str
    relation_type: str
    editable: bool
    short_info_en: str
    short_info_de: str
    code_snippet_id: str | None
    status: str
    visible: bool = True
    label: str | None = None
    strength: float | None = None
    quality_label: str = 'partial_registry'


class GraphWorkbench:
    def __init__(self) -> None:
        self.registry = self._load_json('graph_registry.json')
        self.overrides = self._load_json('graph_overrides.json')
        self.layout_store = self._load_json('graph_layouts.json')
        self.tours = self._load_json('tour_registry.json').get('tours', [])
        self.snippets = self._load_json('snippet_registry.json').get('snippets', [])
        self._node_index = {n['id']: n for n in self.registry.get('nodes', [])}
        self._edge_index = {e['id']: e for e in self.registry.get('edges', [])}
        self._snippet_index = {s['snippet_id']: s for s in self.snippets}
        self._tour_index = {t['tour_id']: t for t in self.tours}

    def _load_json(self, name: str) -> dict[str, Any]:
        path = CONFIGS / name
        if not path.exists():
            return {}
        return json.loads(path.read_text(encoding='utf-8'))

    def _save_overrides(self) -> None:
        (CONFIGS / 'graph_overrides.json').write_text(json.dumps(self.overrides, ensure_ascii=False, indent=2), encoding='utf-8')

    def _save_layouts(self) -> None:
        (CONFIGS / 'graph_layouts.json').write_text(json.dumps(self.layout_store, ensure_ascii=False, indent=2), encoding='utf-8')

    def list_views(self) -> list[dict[str, Any]]:
        return self.registry.get('views', [])

    def list_tours(self) -> list[dict[str, Any]]:
        return self.tours

    def list_snippets(self) -> list[dict[str, Any]]:
        return self.snippets

    def _quality_label(self, status: str | None) -> str:
        status = (status or '').lower()
        if 'official' in status or 'reference' in status:
            return 'official_reference'
        if 'project' in status or 'provisional' in status:
            return 'relational_hypothesis'
        return 'partial_registry'

    def _base_node(self, node_id: str) -> GraphNode:
        row = self._node_index[node_id]
        return GraphNode(**{k: row.get(k) for k in GraphNode.__dataclass_fields__.keys() if k not in {'x','y','group','visible','quality_label'}}, quality_label=self._quality_label(row.get('status')))

    def _base_edge(self, edge_id: str) -> GraphEdge:
        row = self._edge_index[edge_id]
        return GraphEdge(
            id=row['id'], source=row['from'], target=row['to'], relation_type=row['relation_type'],
            editable=bool(row.get('editable', False)), short_info_en=row.get('short_info_en', ''),
            short_info_de=row.get('short_info_de', ''), code_snippet_id=row.get('code_snippet_id'),
            status=row.get('status', 'unknown'), label=row.get('label'), strength=row.get('strength'),
            quality_label=self._quality_label(row.get('status')),
        )

    def _apply_positions(self, nodes: list[GraphNode], edges: list[GraphEdge], group_by: str | None = None) -> None:
        dep_pos = graph_snapshot().get('positions', {})
        persisted = self.layout_store.get('positions', {})
        categories: dict[str, list[GraphNode]] = {}
        for node in nodes:
            node.group = getattr(node, group_by) if group_by and hasattr(node, group_by) else (node.category if group_by else None)
            categories.setdefault(node.group or 'default', []).append(node)
        group_names = list(categories.keys())
        width = 1200
        height = 700
        cols = max(1, len(group_names))
        col_width = width / cols
        for col, group in enumerate(group_names):
            group_nodes = categories[group]
            for i, node in enumerate(group_nodes):
                if node.id in persisted:
                    node.x = float(persisted[node.id]['x'])
                    node.y = float(persisted[node.id]['y'])
                elif node.id in dep_pos:
                    node.x = 80 + col * col_width + (dep_pos[node.id]['x'] % (col_width - 120))
                    node.y = 80 + (dep_pos[node.id]['y'] % (height - 140))
                else:
                    node.x = 80 + col * col_width + 90 + (i % 3) * 110
                    node.y = 100 + (i // 3) * 95

    def build_canvas(self, view_id: str, filters: dict[str, Any] | None = None, group_by: str | None = None) -> dict[str, Any]:
        filters = filters or {}
        view = next(v for v in self.list_views() if v['view_id'] == view_id)
        nodes = [self._base_node(nid) for nid in view['nodes'] if nid in self._node_index]
        edges = [self._base_edge(eid) for eid in view['edges'] if eid in self._edge_index]
        edge_overrides = self.overrides.get('edges', {})
        node_overrides = self.overrides.get('nodes', {})
        for node in nodes:
            ov = node_overrides.get(node.id, {})
            for key, value in ov.items():
                if hasattr(node, key):
                    setattr(node, key, value)
        for edge in edges:
            ov = edge_overrides.get(edge.id, {})
            for key, value in ov.items():
                if hasattr(edge, key):
                    setattr(edge, key, value)
        category_filter = set(filters.get('categories', [])) if filters.get('categories') else None
        text_filter = (filters.get('text') or '').strip().lower()
        for node in nodes:
            if category_filter and node.category not in category_filter:
                node.visible = False
            if text_filter and text_filter not in node.label.lower() and text_filter not in node.short_info_en.lower() and text_filter not in node.short_info_de.lower():
                node.visible = False
        visible_nodes = {n.id for n in nodes if n.visible}
        for edge in edges:
            if edge.source not in visible_nodes or edge.target not in visible_nodes:
                edge.visible = False
        self._apply_positions(nodes, edges, group_by or view.get('group_by_default'))
        minimap = self._build_minimap([n for n in nodes if n.visible])
        group_summary = {}
        for n in nodes:
            if n.visible:
                group_summary[n.group or 'default'] = group_summary.get(n.group or 'default', 0) + 1
        return {'view': view, 'nodes': [asdict(n) for n in nodes], 'edges': [asdict(e) for e in edges], 'groups': group_summary, 'minimap': minimap, 'filters': filters}

    def _build_minimap(self, nodes: list[GraphNode]) -> dict[str, Any]:
        if not nodes:
            return {'width': 180, 'height': 100, 'nodes': []}
        minx = min(n.x for n in nodes); maxx = max(n.x for n in nodes)
        miny = min(n.y for n in nodes); maxy = max(n.y for n in nodes)
        width = 180; height = 100
        dx = max(1.0, maxx - minx); dy = max(1.0, maxy - miny)
        mapped = []
        for n in nodes:
            mapped.append({'id': n.id, 'x': 10 + ((n.x - minx) / dx) * (width - 20), 'y': 10 + ((n.y - miny) / dy) * (height - 20), 'category': n.category})
        return {'width': width, 'height': height, 'nodes': mapped}

    def node_inspector(self, view_id: str, node_id: str) -> dict[str, Any]:
        canvas = self.build_canvas(view_id)
        node = next((n for n in canvas['nodes'] if n['id'] == node_id), None)
        incoming = [e for e in canvas['edges'] if e['target'] == node_id and e['visible']]
        outgoing = [e for e in canvas['edges'] if e['source'] == node_id and e['visible']]
        related_snippets = [self._snippet_index[e['code_snippet_id']] for e in incoming + outgoing if e.get('code_snippet_id') in self._snippet_index]
        return {'node': node, 'incoming': incoming, 'outgoing': outgoing, 'related_snippets': related_snippets}

    def edge_inspector(self, view_id: str, edge_id: str) -> dict[str, Any]:
        canvas = self.build_canvas(view_id)
        edge = next((e for e in canvas['edges'] if e['id'] == edge_id), None)
        snippet = self._snippet_index.get(edge.get('code_snippet_id')) if edge and edge.get('code_snippet_id') else None
        source = next((n for n in canvas['nodes'] if n['id'] == edge['source']), None) if edge else None
        target = next((n for n in canvas['nodes'] if n['id'] == edge['target']), None) if edge else None
        return {'edge': edge, 'source_node': source, 'target_node': target, 'snippet': snippet}

    def update_edge(self, edge_id: str, updates: dict[str, Any]) -> dict[str, Any]:
        edge = self._base_edge(edge_id)
        if not edge.editable:
            raise ValueError('edge_not_editable')
        allowed = {'label', 'status', 'strength', 'short_info_en', 'short_info_de', 'relation_type'}
        current = self.overrides.setdefault('edges', {}).setdefault(edge_id, {})
        for key, value in updates.items():
            if key in allowed:
                current[key] = value
        self._save_overrides()
        return {'edge_id': edge_id, 'overrides': current}

    def update_node(self, node_id: str, updates: dict[str, Any]) -> dict[str, Any]:
        node = self._base_node(node_id)
        allowed = {'label', 'status', 'short_info_en', 'short_info_de', 'long_info_en', 'long_info_de', 'category'}
        current = self.overrides.setdefault('nodes', {}).setdefault(node_id, {})
        for key, value in updates.items():
            if key in allowed:
                current[key] = value
        self._save_overrides()
        return {'node_id': node_id, 'overrides': current, 'quality_label': self._quality_label(current.get('status', node.status))}

    def update_multiple_edges(self, updates: list[dict[str, Any]]) -> dict[str, Any]:
        return {'updated': [self.update_edge(item['edge_id'], item.get('updates', {})) for item in updates]}

    def update_multiple_nodes(self, updates: list[dict[str, Any]]) -> dict[str, Any]:
        return {'updated': [self.update_node(item['node_id'], item.get('updates', {})) for item in updates]}

    def save_node_positions(self, positions: list[dict[str, Any]]) -> dict[str, Any]:
        store = self.layout_store.setdefault('positions', {})
        for item in positions:
            store[item['node_id']] = {'x': float(item['x']), 'y': float(item['y'])}
        self._save_layouts()
        return {'saved': len(positions), 'positions': store}

    def run_tour(self, tour_id: str, profile_name: str = 'default_project', active_reference_sets: list[str] | None = None) -> dict[str, Any]:
        tour = self._tour_index[tour_id]
        outputs = []
        run_result = None
        for step in tour['steps']:
            action = step['action']
            if action == 'show_view':
                outputs.append({'action': action, 'payload': self.build_canvas(step['focus_id'])})
            elif action == 'inspect_node':
                outputs.append({'action': action, 'payload': self.node_inspector('core_relational_map', step['focus_id'])})
            elif action == 'inspect_edge':
                outputs.append({'action': action, 'payload': self.edge_inspector('core_relational_map', step['focus_id'])})
            elif action == 'run_relation_tests':
                run_result = execute(profile_name, active_reference_sets=active_reference_sets, run_relation_tests=True)
                outputs.append({'action': action, 'payload': {'run_dir': run_result['run_dir'], 'metrics': run_result['metrics'], 'relation_tests': run_result['relation_tests']}})
            elif action == 'run_research_summary':
                run_result = execute(profile_name, active_reference_sets=active_reference_sets, run_relation_tests=True)
                outputs.append({'action': action, 'payload': {'run_dir': run_result['run_dir'], 'research_summary': run_result['research_summary'], 'freedom_balance': run_result['freedom_balance']}})
            else:
                outputs.append({'action': action, 'payload': {'status': 'unknown_action'}})
        return {'tour': tour, 'steps': outputs, 'final_run_dir': run_result['run_dir'] if run_result else None}


_DEFAULT = GraphWorkbench()


def list_views():
    return _DEFAULT.list_views()


def canvas_view(view_id: str, filters: dict[str, Any] | None = None, group_by: str | None = None):
    return _DEFAULT.build_canvas(view_id, filters=filters, group_by=group_by)


def inspect_node(view_id: str, node_id: str):
    return _DEFAULT.node_inspector(view_id, node_id)


def inspect_edge(view_id: str, edge_id: str):
    return _DEFAULT.edge_inspector(view_id, edge_id)


def update_edge(edge_id: str, updates: dict[str, Any]):
    return _DEFAULT.update_edge(edge_id, updates)


def update_multiple_edges(updates: list[dict[str, Any]]):
    return _DEFAULT.update_multiple_edges(updates)


def update_node(node_id: str, updates: dict[str, Any]):
    return _DEFAULT.update_node(node_id, updates)


def update_multiple_nodes(updates: list[dict[str, Any]]):
    return _DEFAULT.update_multiple_nodes(updates)


def save_node_positions(positions: list[dict[str, Any]]):
    return _DEFAULT.save_node_positions(positions)


def list_tours():
    return _DEFAULT.list_tours()


def list_snippets():
    return _DEFAULT.list_snippets()


def run_tour(tour_id: str, profile_name: str = 'default_project', active_reference_sets: list[str] | None = None):
    return _DEFAULT.run_tour(tour_id, profile_name=profile_name, active_reference_sets=active_reference_sets)


# Compatibility helpers retained for older graph tests and docs.
from types import SimpleNamespace

def load_graph_registry() -> dict[str, Any]:
    return GraphWorkbench().registry

def load_tour_registry() -> dict[str, Any]:
    return {'tours': GraphWorkbench().list_tours()}

def load_snippet_registry() -> dict[str, Any]:
    return {'snippets': GraphWorkbench().list_snippets()}

def list_graph_views() -> list[SimpleNamespace]:
    return [SimpleNamespace(view_id=v['view_id'], title=v.get('title', v['view_id'])) for v in GraphWorkbench().list_views()]

def get_view(view_id: str) -> dict[str, Any]:
    return GraphWorkbench().build_canvas(view_id)

def graph_requirements_summary() -> dict[str, int]:
    wb = GraphWorkbench()
    return {
        'graph_views': len(wb.list_views()),
        'tours': len(wb.list_tours()),
        'snippets': len(wb.list_snippets()),
    }
