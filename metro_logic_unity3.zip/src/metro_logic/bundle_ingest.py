from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / "configs"
UPLOAD_DIR = CONFIGS / "upload_bundles"
REGISTRY_PATH = CONFIGS / "upload_bundle_registry.json"


def bundle_schema() -> dict[str, Any]:
    return {
        "required": ["metadata"],
        "optional": ["node_datasheets", "edge_formulas", "snippets", "docs"],
        "metadata_fields": ["bundle_id", "title", "language", "source", "status"],
        "node_datasheet_fields": ["node_id", "label", "title_de", "title_en", "summary_de", "summary_en", "fields", "quality_label"],
        "edge_formula_fields": ["edge_id", "formula_id", "name", "equation_latex", "description_de", "description_en", "inputs", "outputs", "source_doc_id", "status", "quality_label"],
    }


def _slug(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_-]+", "-", value.strip()).strip('-').lower()
    return cleaned or 'bundle'


def _ensure_dirs() -> None:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    if not REGISTRY_PATH.exists():
        REGISTRY_PATH.write_text(json.dumps({"bundles": []}, ensure_ascii=False, indent=2), encoding='utf-8')


def validate_bundle(payload: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    meta = payload.get('metadata')
    if not isinstance(meta, dict):
        errors.append('metadata_missing')
        meta = {}
    bundle_id = _slug(str(meta.get('bundle_id') or meta.get('title') or 'bundle'))
    node_datasheets = payload.get('node_datasheets', []) or []
    edge_formulas = payload.get('edge_formulas', []) or []
    snippets = payload.get('snippets', []) or []
    docs = payload.get('docs', []) or []
    if not isinstance(node_datasheets, list): errors.append('node_datasheets_not_list')
    if not isinstance(edge_formulas, list): errors.append('edge_formulas_not_list')
    if not isinstance(snippets, list): errors.append('snippets_not_list')
    if not isinstance(docs, list): errors.append('docs_not_list')
    for idx, row in enumerate(node_datasheets if isinstance(node_datasheets, list) else []):
        if not row.get('node_id'): errors.append(f'node_datasheet[{idx}]_missing_node_id')
        if not (row.get('title_de') or row.get('title_en') or row.get('label')): errors.append(f'node_datasheet[{idx}]_missing_title')
    for idx, row in enumerate(edge_formulas if isinstance(edge_formulas, list) else []):
        if not row.get('edge_id'): errors.append(f'edge_formula[{idx}]_missing_edge_id')
        if not row.get('formula_id'): errors.append(f'edge_formula[{idx}]_missing_formula_id')
        if not (row.get('equation_latex') or row.get('latex')): errors.append(f'edge_formula[{idx}]_missing_latex')
    valid = not errors
    return {
        'valid': valid,
        'errors': errors,
        'normalized_bundle_id': bundle_id,
        'summary': {
            'node_datasheets': len(node_datasheets) if isinstance(node_datasheets, list) else 0,
            'edge_formulas': len(edge_formulas) if isinstance(edge_formulas, list) else 0,
            'snippets': len(snippets) if isinstance(snippets, list) else 0,
            'docs': len(docs) if isinstance(docs, list) else 0,
        }
    }


def load_upload_bundle_registry() -> dict[str, Any]:
    _ensure_dirs()
    return json.loads(REGISTRY_PATH.read_text(encoding='utf-8'))


def list_uploaded_bundles() -> list[dict[str, Any]]:
    return load_upload_bundle_registry().get('bundles', [])


def _bundle_summary(payload: dict[str, Any], bundle_id: str) -> dict[str, Any]:
    v = validate_bundle(payload)
    meta = payload.get('metadata', {})
    return {
        'bundle_id': bundle_id,
        'title': meta.get('title', bundle_id),
        'language': meta.get('language', 'de'),
        'source': meta.get('source', 'upload'),
        'status': meta.get('status', 'imported'),
        **v['summary'],
    }


def import_bundle(payload: dict[str, Any]) -> dict[str, Any]:
    _ensure_dirs()
    validation = validate_bundle(payload)
    if not validation['valid']:
        return {'imported': False, **validation}
    bundle_id = validation['normalized_bundle_id']
    bundle_path = UPLOAD_DIR / f'{bundle_id}.json'
    bundle_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    registry = load_upload_bundle_registry()
    bundles = [b for b in registry.get('bundles', []) if b.get('bundle_id') != bundle_id]
    bundles.append(_bundle_summary(payload, bundle_id))
    bundles.sort(key=lambda row: row.get('bundle_id', ''))
    REGISTRY_PATH.write_text(json.dumps({'bundles': bundles}, ensure_ascii=False, indent=2), encoding='utf-8')
    return {'imported': True, **validation, 'bundle_path': str(bundle_path), 'bundle': _bundle_summary(payload, bundle_id)}


def load_uploaded_bundle_details() -> list[dict[str, Any]]:
    _ensure_dirs()
    details: list[dict[str, Any]] = []
    for path in sorted(UPLOAD_DIR.glob('*.json')):
        payload = json.loads(path.read_text(encoding='utf-8'))
        validation = validate_bundle(payload)
        details.append({
            'bundle_id': validation['normalized_bundle_id'],
            'metadata': payload.get('metadata', {}),
            'node_datasheets': payload.get('node_datasheets', []),
            'edge_formulas': payload.get('edge_formulas', []),
            'snippets': payload.get('snippets', []),
            'docs': payload.get('docs', []),
            'summary': validation['summary'],
        })
    return details
