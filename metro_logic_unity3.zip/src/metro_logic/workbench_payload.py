
from __future__ import annotations
import json
from pathlib import Path
from metro_logic.docs_catalog import build_docs_index
from metro_logic.bundle_ingest import bundle_schema, list_uploaded_bundles, load_uploaded_bundle_details
from metro_logic.atom_blueprint import list_atom_states
from metro_logic.sm_dataset import list_sm_channels, list_sm_particles, list_sm_auxiliary_objects
from metro_logic.registry_validation import validate_unity3_datasets
from rel_metro.research_workbench import build_workbench_payload as _science_payload

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'

def _read(path: Path, key: str) -> list[dict]:
    if not path.exists():
        return []
    payload = json.loads(path.read_text(encoding='utf-8'))
    return payload.get(key, []) if isinstance(payload, dict) else payload

def _browser_rows(items: list[dict], key_id: str, key_label: str, summary_de_fn, summary_en_fn) -> list[dict]:
    rows = []
    for item in items:
        rows.append({
            'id': item.get(key_id) or item.get('id') or item.get('symbol') or item.get('formula_id'),
            'label': item.get(key_label) or item.get('name_en') or item.get('name_de') or item.get('symbol') or item.get('id'),
            'name_de': item.get('name_de') or item.get('title_de') or item.get('name_en') or item.get('symbol') or item.get(key_label),
            'name_en': item.get('name_en') or item.get('title_en') or item.get('name_de') or item.get('symbol') or item.get(key_label),
            'summary_de': summary_de_fn(item),
            'summary_en': summary_en_fn(item),
            'details': item,
        })
    return rows

def _slim_elements() -> list[dict]:
    return _browser_rows(_read(CONFIGS / 'atom_registry.json', 'elements'),'symbol','symbol',
        lambda item: f"Z={item.get('atomic_number')}, Gruppe {item.get('group')}, Periode {item.get('period')}",
        lambda item: f"Z={item.get('atomic_number')}, group {item.get('group')}, period {item.get('period')}")

def _slim_isotopes() -> list[dict]:
    return _browser_rows(_read(CONFIGS / 'isotope_registry.json', 'isotopes'),'mass_number','element',
        lambda item: f"A={item.get('mass_number')}, N={item.get('neutron_number')}",
        lambda item: f"A={item.get('mass_number')}, N={item.get('neutron_number')}")

def _atom_states() -> list[dict]:
    return _browser_rows(list_atom_states(),'symbol','symbol',
        lambda item: f"Schalen {item.get('shell_distribution')} · Valenz {item.get('default_valence')}",
        lambda item: f"shells {item.get('shell_distribution')} · valence {item.get('default_valence')}")

def _uploaded_node_sheets() -> list[dict]:
    rows = []
    for bundle in load_uploaded_bundle_details():
        for item in bundle.get('node_datasheets', []):
            rows.append({'id': f"bundle-node-{bundle['bundle_id']}-{item.get('node_id')}", 'label': item.get('label') or item.get('title_de') or item.get('title_en') or item.get('node_id'), 'name_de': item.get('title_de') or item.get('label') or item.get('node_id'), 'name_en': item.get('title_en') or item.get('label') or item.get('node_id'), 'summary_de': item.get('summary_de') or f"Bundle {bundle['bundle_id']} · Node {item.get('node_id')}", 'summary_en': item.get('summary_en') or f"Bundle {bundle['bundle_id']} · node {item.get('node_id')}", 'details': {**item, 'bundle_id': bundle['bundle_id']}})
    return rows

def _uploaded_edge_formulas() -> list[dict]:
    rows = []
    for bundle in load_uploaded_bundle_details():
        for item in bundle.get('edge_formulas', []):
            rows.append({'id': f"bundle-edge-{bundle['bundle_id']}-{item.get('formula_id')}", 'label': item.get('name') or item.get('formula_id'), 'name_de': item.get('name') or item.get('formula_id'), 'name_en': item.get('name') or item.get('formula_id'), 'summary_de': item.get('description_de') or f"Kante {item.get('edge_id')}", 'summary_en': item.get('description_en') or f"Edge {item.get('edge_id')}", 'details': {**item, 'bundle_id': bundle['bundle_id']}})
    return rows

def _upload_entries() -> list[dict]:
    rows = []
    for item in list_uploaded_bundles():
        rows.append({'id': item.get('bundle_id'), 'label': item.get('title') or item.get('bundle_id'), 'name_de': item.get('title') or item.get('bundle_id'), 'name_en': item.get('title') or item.get('bundle_id'), 'summary_de': f"{item.get('node_datasheets', 0)} Knotenblätter · {item.get('edge_formulas', 0)} Kantenformeln", 'summary_en': f"{item.get('node_datasheets', 0)} node sheets · {item.get('edge_formulas', 0)} edge formulas", 'details': item})
    return rows

def _slim_questions() -> list[dict]:
    return _browser_rows(_read(CONFIGS / 'force_research_questions_registry.json', 'questions'),'question_id','question_id',
        lambda item: f"{item.get('domain')} · Priorität {item.get('priority')}",
        lambda item: f"{item.get('domain')} · priority {item.get('priority')}")

def build_workbench_payload() -> dict:
    payload = _science_payload()
    validation = validate_unity3_datasets()
    payload['metadata']['app_name'] = 'metro_logic_unity3 Workbench'
    payload['metadata']['app_slug'] = 'metro_logic_unity3'
    payload['docs_index'] = build_docs_index()
    payload['browser_datasets'] = {
        'elements': _slim_elements(),
        'isotopes': _slim_isotopes(),
        'atom_states': _atom_states(),
        'forces': _browser_rows(payload.get('interactions', []),'id','carrier', lambda item: f"Träger {item.get('carrier')} · {item.get('status')}", lambda item: f"carrier {item.get('carrier')} · {item.get('status')}"),
        'sm26': _browser_rows(_read(CONFIGS / 'standard_model_full_registry.json', 'sm26_parameters'),'id','id', lambda item: item.get('name_de') or item.get('name_en') or 'SM26', lambda item: item.get('name_en') or item.get('name_de') or 'SM26'),
        'channels': _browser_rows(list_sm_channels(),'channel_id','label', lambda item: f"{item.get('domain')} · {item.get('status')}", lambda item: f"{item.get('domain')} · {item.get('status')}"),
        'particles': _browser_rows(list_sm_particles(),'id','id', lambda item: f"{item.get('sector')} · beobachtet {item.get('observed')}", lambda item: f"{item.get('sector')} · observed {item.get('observed')}"),
        'auxiliary': _browser_rows(list_sm_auxiliary_objects(),'id','id', lambda item: f"{item.get('role')} · nicht beobachtet", lambda item: f"{item.get('role')} · not observed"),
        'snippets': _browser_rows(payload.get('snippets', []),'snippet_id','title', lambda item: item.get('language','code'), lambda item: item.get('language','code')),
        'node_sheets': _uploaded_node_sheets(),
        'edge_formulas': _uploaded_edge_formulas(),
        'uploads': _upload_entries(),
        'formulas': _browser_rows(payload.get('formulas', []),'formula_id','name', lambda item: f"{item.get('status')} · Inputs {len(item.get('inputs', []))}", lambda item: f"{item.get('status')} · inputs {len(item.get('inputs', []))}"),
        'questions': _slim_questions(),
        'docs': [{'id': entry['path'], 'label': entry['title'], 'name_de': entry['title'], 'name_en': entry['title'], 'summary_de': entry['preview'], 'summary_en': entry['preview'], 'details': entry} for group in build_docs_index().values() for entry in group],
        'tests': [{'id': item.get('id'), 'label': item.get('id'), 'name_de': item.get('title'), 'name_en': item.get('title'), 'summary_de': f"{item.get('category')} · {item.get('path')}", 'summary_en': f"{item.get('category')} · {item.get('path')}", 'details': item} for item in payload.get('tests', {}).get('items', [])],
    }
    payload['upload_support'] = {'schema': bundle_schema(), 'bundles': list_uploaded_bundles(), 'supports_offline_import': True, 'supports_api_import': True}
    payload['validation'] = validation
    inv = dict(validation['inventory'])
    inv['research_questions'] = payload.get('research_program', {}).get('summary', {}).get('question_count', 0)
    inv['formulas'] = len(payload.get('formulas', []))
    payload['dataset_inventory'] = inv
    payload['ui'] = {
        'header_sections': [
            {'id': 'explore', 'title_de': 'Erkunden', 'title_en': 'Explore'},
            {'id': 'physics', 'title_de': 'Physik', 'title_en': 'Physics'},
            {'id': 'chemistry', 'title_de': 'Chemie', 'title_en': 'Chemistry'},
            {'id': 'relational', 'title_de': 'Relational', 'title_en': 'Relational'},
            {'id': 'docs', 'title_de': 'Doku', 'title_en': 'Docs'},
            {'id': 'tests', 'title_de': 'Tests', 'title_en': 'Tests'},
        ],
        'browser_tabs': ['elements', 'isotopes', 'atom_states', 'forces', 'sm26', 'channels', 'particles', 'auxiliary', 'node_sheets', 'edge_formulas', 'snippets', 'formulas', 'questions', 'uploads', 'docs', 'tests'],
    }
    return payload
