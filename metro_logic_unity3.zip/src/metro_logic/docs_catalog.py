from __future__ import annotations
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "docs"

def _preview(path: Path) -> str:
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.strip() and not line.strip().startswith('#'):
            return line.strip()[:220]
    return ""

def build_docs_index() -> dict:
    grouped = {"core": [], "ux": [], "research": [], "uploads": [], "archive": []}
    for path in sorted(DOCS.rglob('*.md')):
        rel = path.relative_to(ROOT).as_posix()
        title = path.stem
        entry = {"title": title, "path": rel, "preview": _preview(path)}
        if 'archive/' in rel:
            grouped['archive'].append(entry)
        elif 'UX' in path.name or 'ARCHITECTURE' in path.name:
            grouped['ux'].append(entry)
        elif 'UPLOAD' in path.name or 'BUNDLE' in path.name:
            grouped['uploads'].append(entry)
        elif 'RESEARCH' in path.name or 'SM_' in path.name or 'ATOM_' in path.name:
            grouped['research'].append(entry)
        else:
            grouped['core'].append(entry)
    return grouped
