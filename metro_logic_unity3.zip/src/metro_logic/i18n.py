from __future__ import annotations

def pick_text(item: dict, de_keys: tuple[str, ...] = ("name_de", "title_de", "summary_de", "description_de"), en_keys: tuple[str, ...] = ("name_en", "title_en", "summary_en", "description_en"), language: str = "de", fallback_keys: tuple[str, ...] = ("label", "name", "title")) -> str:
    search = de_keys if language == "de" else en_keys
    for key in search + fallback_keys:
        value = item.get(key)
        if value:
            return str(value)
    other = en_keys if language == "de" else de_keys
    for key in other:
        value = item.get(key)
        if value:
            return str(value)
    return ""
