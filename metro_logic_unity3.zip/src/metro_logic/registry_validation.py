
from __future__ import annotations
import json
from pathlib import Path
from metro_logic.atom_blueprint import list_atom_states
from metro_logic.sm_dataset import list_sm_channels, list_sm_interactions, list_sm_particles, list_sm_auxiliary_objects
ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'

def _read(name: str, key: str) -> list[dict]:
    payload = json.loads((CONFIGS / name).read_text(encoding='utf-8'))
    return payload.get(key, [])

def inventory_report() -> dict:
    return {
        'elements': len(_read('atom_registry.json','elements')),
        'isotopes': len(_read('isotope_registry.json','isotopes')),
        'atom_states': len(list_atom_states()),
        'sm_interactions': len(list_sm_interactions()),
        'sm26_parameters': len(_read('standard_model_full_registry.json','sm26_parameters')),
        'sm_channels': len(list_sm_channels()),
        'sm_particles': len(list_sm_particles()),
        'sm_auxiliary': len(list_sm_auxiliary_objects()),
    }

def validate_unity3_datasets() -> dict:
    inv = inventory_report()
    checks = {
        'elements_118': inv['elements'] == 118,
        'isotopes_118': inv['isotopes'] == 118,
        'atom_states_118': inv['atom_states'] == 118,
        'sm_interactions_4': inv['sm_interactions'] == 4,
        'sm26_parameters_26': inv['sm26_parameters'] == 26,
        'sm_channels_26': inv['sm_channels'] == 26,
        'particles_nonempty': inv['sm_particles'] >= 10,
        'auxiliary_nonempty': inv['sm_auxiliary'] >= 3,
    }
    return {'inventory': inv, 'checks': checks, 'ok': all(checks.values())}
