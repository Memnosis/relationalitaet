
from __future__ import annotations
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'

def load_standard_model_full_registry() -> dict:
    return json.loads((CONFIGS / 'standard_model_full_registry.json').read_text(encoding='utf-8'))

def list_sm_interactions() -> list[dict]:
    return load_standard_model_full_registry().get('interactions', [])

def list_sm26_parameters() -> list[dict]:
    return load_standard_model_full_registry().get('sm26_parameters', [])

def list_sm_channels() -> list[dict]:
    return load_standard_model_full_registry().get('channels', [])

def list_sm_particles() -> list[dict]:
    return load_standard_model_full_registry().get('particles', [])

def list_sm_auxiliary_objects() -> list[dict]:
    return load_standard_model_full_registry().get('auxiliary', [])
