from rel_metro.ui_app import main

if __name__ == "__main__":
    main()
