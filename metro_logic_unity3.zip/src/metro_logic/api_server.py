
from __future__ import annotations
from rel_metro.api_server import *  # noqa: F401,F403
from metro_logic.atom_blueprint import list_atom_states, get_atom_state
from metro_logic.sm_dataset import list_sm_channels, list_sm_particles, list_sm_auxiliary_objects
from metro_logic.registry_validation import validate_unity3_datasets
from metro_logic.workbench_payload import build_workbench_payload

def get_atom_states() -> dict:
    return {'atom_states': list_atom_states()}

def get_atom_state_by_symbol(symbol: str) -> dict:
    return {'atom_state': get_atom_state(symbol)}

def get_sm_channels() -> dict:
    return {'channels': list_sm_channels()}

def get_sm_particles() -> dict:
    return {'particles': list_sm_particles()}

def get_sm_auxiliary_objects() -> dict:
    return {'auxiliary': list_sm_auxiliary_objects()}

def get_unity3_validation_report() -> dict:
    return validate_unity3_datasets()

def get_unity3_workbench_payload() -> dict:
    return build_workbench_payload()
