
from __future__ import annotations
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ROOT / 'configs'

def load_atom_structure_registry() -> dict:
    return json.loads((CONFIGS / 'atom_structure_registry.json').read_text(encoding='utf-8'))

def list_atom_states() -> list[dict]:
    return load_atom_structure_registry().get('atom_states', [])

def get_atom_state(symbol: str) -> dict | None:
    symbol = symbol.strip().lower()
    for row in list_atom_states():
        if row.get('symbol','').lower() == symbol:
            return row
    return None
