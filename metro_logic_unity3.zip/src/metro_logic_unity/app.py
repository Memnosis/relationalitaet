from __future__ import annotations
from metro_logic.workbench_payload import build_workbench_payload
from metro_logic.docs_catalog import build_docs_index

def build_payload() -> dict:
    return build_workbench_payload()

def docs_index() -> dict:
    return build_docs_index()

def app_identity() -> dict:
    return {
        "name": "metro_logic_unity3",
        "ui_package": "metro_logic",
        "science_package": "rel_metro",
        "status": "integrated_mainline",
    }
