"""Unified public facade for metro_logic_unity."""
from .app import build_payload, docs_index, app_identity
__all__ = ["build_payload", "docs_index", "app_identity"]
