# METRO_LOGIC_UNITY21_ARCHITECTURE

## Trennung der Schichten

- `metro_logic`: UI, Payload, i18n, Docs-Katalog, visuelle Integration
- `rel_metro`: wissenschaftliche Logik, Registries, Analysen, Provenienz, Rechenpfade
- `metro_logic_unity21`: öffentliche Fassade

## Warum diese Trennung?

Die frühere Hauptschwäche war ein wissenschaftlich tiefer, aber UI-seitig zu dünner Stand. Die neue Architektur stellt den browserbasierten Arbeitsfluss in den Vordergrund, ohne die wissenschaftlichen Module zu verwässern.

## Lerneffekt aus n8n/Node-RED

- klare erste Ebene
- Kontext-Hilfe in Reichweite
- zentrales Workspace
- rechte Detailspalte
- nicht alles gleichzeitig sichtbar


## Upload-Bundles
- Neue Knoten-Datenblätter und Kanten-Formeln sind als JSON-Bundles vorgesehen.
- Die Workbench muss Bundle-Schema, Vorschau, Overlay und persistente API-Importe unterstützen.
- Bundle-Daten werden mit QC-Labels als Erweiterungen behandelt, bis sie validiert sind.
