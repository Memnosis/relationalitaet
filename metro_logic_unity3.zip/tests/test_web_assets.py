from pathlib import Path

def test_web_assets_present():
    root = Path(__file__).resolve().parents[1]
    assert (root / 'web' / 'index.html').exists()
    assert (root / 'web' / 'app.js').exists()
