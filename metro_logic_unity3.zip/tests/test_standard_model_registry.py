from rel_metro.standard_model_registry import load_standard_model_registry, interaction_summary

def test_standard_model_registry_has_core_content():
    payload = load_standard_model_registry()
    assert payload['interactions']
    summary = interaction_summary()
    assert summary['interaction_count'] >= 4
