
import json
from pathlib import Path

from rel_metro.pipeline import execute
from rel_metro.sm_relation_lab import official_relation_suite, relational_relation_suite, necessity_suite, combined_research_suite
from rel_metro.api_server import _Handler


def test_official_and_relational_suites_have_content():
    off = official_relation_suite('default_project')
    rel = relational_relation_suite('default_project')
    assert off['relations']
    assert rel['relations']
    assert 'official_on_shell_weinberg' in off['relations']
    assert 'rel_anchor_alpha' in rel['relations']


def test_necessity_suite_contains_w_compensator_probe():
    suite = necessity_suite('default_project')
    assert 'w_compensator_necessity' in suite['tests']
    rec = suite['tests']['w_compensator_necessity']
    assert rec['variants']


def test_pipeline_can_emit_research_suite(tmp_path):
    run = execute('default_project', run_relation_tests=True, run_research_suite=True)
    run_dir = Path(run['run_dir'])
    assert (run_dir / 'outputs' / 'research_suite.json').exists()
    payload = json.loads((run_dir / 'outputs' / 'research_suite.json').read_text())
    assert 'official' in payload and 'relational' in payload and 'necessity' in payload


def test_combined_suite_has_assumptions_and_perturbation():
    suite = combined_research_suite('default_project')
    assert suite['assumptions']['assumptions']
    assert 'sensitivity_matrix' in suite['perturbation']
