
import json
from metro_logic.registry_validation import validate_unity3_datasets
from metro_logic.atom_blueprint import list_atom_states
from metro_logic.sm_dataset import list_sm_channels, list_sm_particles, list_sm_auxiliary_objects

def test_unity3_dataset_counts():
    report = validate_unity3_datasets()
    assert report['ok'] is True
    assert report['inventory']['elements'] == 118
    assert report['inventory']['isotopes'] == 118
    assert report['inventory']['atom_states'] == 118
    assert report['inventory']['sm26_parameters'] == 26
    assert report['inventory']['sm_channels'] == 26

def test_unity3_atom_state_access():
    states = list_atom_states()
    assert len(states) == 118
    assert states[0]['shell_distribution']

def test_unity3_sm_sidecars():
    assert len(list_sm_channels()) == 26
    assert len(list_sm_particles()) >= 10
    assert len(list_sm_auxiliary_objects()) >= 3
    assert any(not row['observed'] for row in list_sm_auxiliary_objects())
