from rel_metro.graph_workbench import load_graph_registry, load_tour_registry, load_snippet_registry, list_graph_views, get_view, graph_requirements_summary
from rel_metro.api_server import make_server
import json, threading, urllib.request


def test_graph_registries_load():
    graph = load_graph_registry()
    tours = load_tour_registry()
    snippets = load_snippet_registry()
    assert graph['views']
    assert tours['tours']
    assert snippets['snippets']


def test_graph_views_and_tours_are_structured():
    views = list_graph_views()
    assert views
    first = get_view(views[0].view_id)
    assert first['nodes'] and first['edges']
    for tour in load_tour_registry()['tours']:
        assert len(tour['steps']) >= 1


def test_graph_api_endpoints():
    httpd = make_server('127.0.0.1', 0)
    port = httpd.server_address[1]
    th = threading.Thread(target=httpd.serve_forever, daemon=True)
    th.start()
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/graph/views') as r:
            payload = json.loads(r.read().decode('utf-8'))
        assert payload['views']
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/graph/tours') as r:
            payload = json.loads(r.read().decode('utf-8'))
        assert payload['tours']
    finally:
        httpd.shutdown(); httpd.server_close()


def test_graph_requirements_summary():
    summary = graph_requirements_summary()
    assert summary['graph_views'] >= 1
    assert summary['tours'] >= 2
    assert summary['snippets'] >= 1
