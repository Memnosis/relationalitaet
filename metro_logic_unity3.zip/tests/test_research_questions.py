from rel_metro.research_questions import data_inventory, research_readiness_report, relational_force_requirements, challenge_map_standard_model

def test_research_inventory_and_readiness():
    inv = data_inventory()
    assert inv['elements'] >= 100
    assert inv['isotopes'] >= 80
    assert research_readiness_report()['gap_count'] >= 0
    assert len(relational_force_requirements()) >= 4
    assert len(challenge_map_standard_model()) >= 4
