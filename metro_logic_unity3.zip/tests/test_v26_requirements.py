from __future__ import annotations
import json
import threading
import time
from pathlib import Path
from urllib.request import Request, urlopen
from rel_metro.pipeline import execute
from rel_metro.relation_registry import load_relation_registry, relations_for_node
from rel_metro.relation_engine import relation_test_suite
from rel_metro.comparison import compare_run_directories
from rel_metro.dataset_importer import validate_profile_payload
from rel_metro.api_server import serve

ROOT = Path(__file__).resolve().parents[1]


def _fetch_json(url, payload=None):
    data = None if payload is None else json.dumps(payload).encode('utf-8')
    req = Request(url, data=data)
    req.add_header('Content-Type', 'application/json')
    with urlopen(req, timeout=5) as resp:
        return json.loads(resp.read().decode('utf-8'))


def test_named_starters_and_contracts_exist():
    assert (ROOT / 'start-microsoft.bat').exists()
    assert (ROOT / 'start-apple.command').exists()
    contracts = json.loads((ROOT / 'configs' / 'contracts.json').read_text(encoding='utf-8'))
    assert any(item['id'] == 'starter_names' for item in contracts['immutable_contracts'])


def test_official_and_relational_relations_expanded():
    registry = load_relation_registry()['relations']
    ids = {r['relation_id'] for r in registry}
    assert 'official_ckm_first_row_unitarity' in ids
    assert 'official_wolfenstein_to_vcb' in ids
    assert 'relational_anchor_to_delta_alpha' in ids
    assert 'relational_generator_to_observable_bridge' in ids


def test_relation_suite_produces_sensitivity_and_influence():
    payload = relation_test_suite('default_project', layers=['official', 'relational_known', 'relational_assumed'])
    assert payload['sensitivity_matrix']
    assert payload['influence_matrix']
    assert 'anchor_ln_R0_lp' in payload['influence_matrix']


def test_compare_run_directories_works():
    left = execute('default_project', run_relation_tests=True)
    right = execute('sanity_shifted', run_relation_tests=True)
    payload = compare_run_directories(left['run_dir'], right['run_dir'])
    assert 'output_comparison' in payload
    assert payload['output_comparison']


def test_dataset_validation_reports_unknown_keys():
    errors = validate_profile_payload({'overrides': {'alpha_ideal_inv': 1.0}, 'bad': 1})
    assert errors and 'unknown keys' in errors[0]


def test_relations_for_node_reports_touching_relations():
    payload = relations_for_node('anchor_ln_R0_lp')
    assert payload['touching_relations']


def test_api_compare_runs_and_benchmarks_series():
    port = 8794
    thread = threading.Thread(target=serve, kwargs={'host': '127.0.0.1', 'port': port}, daemon=True)
    thread.start()
    time.sleep(0.4)
    left = execute('default_project')
    right = execute('closure_inherited')
    compare_payload = _fetch_json(f'http://127.0.0.1:{port}/compare-runs', {'left_run_dir': left['run_dir'], 'right_run_dir': right['run_dir']})
    assert 'output_comparison' in compare_payload
    bench_payload = _fetch_json(f'http://127.0.0.1:{port}/benchmarks/series', {'profiles': ['default_project', 'sanity_shifted'], 'run_relation_tests': True})
    assert 'runs' in bench_payload and len(bench_payload['runs']) == 2
