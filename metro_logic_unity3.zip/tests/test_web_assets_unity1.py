from pathlib import Path

def test_web_app_mentions_upload_tabs_and_unity2():
    text = Path('web/app.js').read_text(encoding='utf-8')
    assert 'node_sheets' in text
    assert 'edge_formulas' in text
    assert 'uploadTitle' in text
    assert 'metro_logic_unity2.layout' in text
