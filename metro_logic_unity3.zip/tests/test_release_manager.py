from rel_metro.release_manager import build_manifest, create_release_zip, verify_release_zip

def test_release_manager_creates_valid_zip(tmp_path):
    assert build_manifest()['file_count'] > 0
    zip_path = create_release_zip(tmp_path / 'release.zip')
    report = verify_release_zip(zip_path)
    assert report['ok']
    assert report['entry_count'] > 0
