import json
from urllib.request import urlopen, Request
from rel_metro.api_server import make_server


def test_bundle_schema_endpoint():
    server = make_server(port=0)
    port = server.server_address[1]
    import threading
    thread = threading.Thread(target=server.handle_request)
    thread.start()
    with urlopen(f'http://127.0.0.1:{port}/bundle/schema') as resp:
        payload = json.loads(resp.read().decode('utf-8'))
    server.server_close(); thread.join()
    assert 'optional' in payload


def test_bundle_registry_endpoint():
    server = make_server(port=0)
    port = server.server_address[1]
    import threading
    thread = threading.Thread(target=server.handle_request)
    thread.start()
    with urlopen(f'http://127.0.0.1:{port}/bundle/registry') as resp:
        payload = json.loads(resp.read().decode('utf-8'))
    server.server_close(); thread.join()
    assert 'bundles' in payload
