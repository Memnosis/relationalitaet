from rel_metro.snippet_library import list_snippets, snippet_catalog_summary, search_snippets

def test_snippet_library_catalog():
    assert list_snippets()
    summary = snippet_catalog_summary()
    assert summary['snippet_count'] >= 1
    assert isinstance(search_snippets('alpha'), list)
