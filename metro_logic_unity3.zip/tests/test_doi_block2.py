
import json
import threading
import time
from urllib.request import urlopen
from pathlib import Path

from rel_metro.paper_registry import load_paper_registry
from rel_metro.formula_registry import load_formula_registry, formulas_for_relation
from rel_metro.doi_provenance import relation_provenance, paper_effect_summary
from rel_metro.api_server import serve

ROOT = Path(__file__).resolve().parents[1]

def test_paper_and_formula_registries_present():
    papers = load_paper_registry()['papers']
    formulas = load_formula_registry()['formulas']
    assert any(p['doc_id'] == 'proj_rel_chemistry' for p in papers)
    assert any(f['formula_id'] == 'f_rel_valence_tension_bridge' for f in formulas)


def test_relation_provenance_has_paper_formula_and_outputs():
    payload = relation_provenance('relational.valence_tension_bridge')
    assert payload['papers']
    assert payload['formulas']
    assert 'bridge_tendency' in payload['affected_outputs']


def test_paper_effect_summary_has_relations():
    payload = paper_effect_summary('proj_rel_chemistry')
    assert payload['relation_count'] >= 3
    assert 'outer_electrons' in payload['affected_outputs']


def test_gui_file_has_doi_tabs():
    text = (ROOT / 'src' / 'rel_metro' / 'ui_app.py').read_text(encoding='utf-8')
    assert 'Papers' in text and 'Formulas' in text and 'Effects' in text


def test_api_endpoints_for_provenance():
    port = 8893
    thread = threading.Thread(target=serve, kwargs={'host': '127.0.0.1', 'port': port}, daemon=True)
    thread.start()
    time.sleep(0.3)
    with urlopen(f'http://127.0.0.1:{port}/papers', timeout=5) as resp:
        papers = json.loads(resp.read().decode('utf-8'))
    with urlopen(f'http://127.0.0.1:{port}/formulas', timeout=5) as resp:
        formulas = json.loads(resp.read().decode('utf-8'))
    with urlopen(f'http://127.0.0.1:{port}/relation-provenance?relation_id=relational.valence_tension_bridge', timeout=5) as resp:
        rel = json.loads(resp.read().decode('utf-8'))
    with urlopen(f'http://127.0.0.1:{port}/paper-effects?doc_id=proj_rel_chemistry', timeout=5) as resp:
        eff = json.loads(resp.read().decode('utf-8'))
    assert papers['papers']
    assert formulas['formulas']
    assert rel['papers'] and rel['formulas']
    assert eff['relation_count'] >= 3
