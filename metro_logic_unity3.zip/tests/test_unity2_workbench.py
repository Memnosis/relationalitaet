
from metro_logic.workbench_payload import build_workbench_payload

def test_unity3_workbench_tabs_and_inventory():
    payload = build_workbench_payload()
    tabs = payload['ui']['browser_tabs']
    for required in ['atom_states','sm26','channels','particles','auxiliary']:
        assert required in tabs
    inv = payload['dataset_inventory']
    assert inv['elements'] == 118
    assert inv['atom_states'] == 118
    assert inv['sm_channels'] == 26

def test_unity3_workbench_datasets_populated():
    payload = build_workbench_payload()
    assert len(payload['browser_datasets']['elements']) == 118
    assert len(payload['browser_datasets']['atom_states']) == 118
    assert len(payload['browser_datasets']['channels']) == 26
