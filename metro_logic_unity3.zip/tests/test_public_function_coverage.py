import ast, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def test_every_public_function_has_matrix_entry():
    matrix = json.loads((ROOT / 'configs' / 'function_test_matrix.json').read_text(encoding='utf-8'))
    mapped = {item['function'] for item in matrix['entries']}
    funcs = set()
    for path in (ROOT / 'src' / 'rel_metro').glob('*.py'):
        tree = ast.parse(path.read_text(encoding='utf-8'))
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and not node.name.startswith('_'):
                funcs.add(f'rel_metro.{path.stem}.{node.name}')
    assert funcs <= mapped
