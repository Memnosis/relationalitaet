from __future__ import annotations
import json
from pathlib import Path

from rel_metro.graph_workbench import list_views, canvas_view, inspect_node, inspect_edge, update_edge, update_multiple_edges, list_tours, run_tour
from metro_logic.graph_workbench import canvas_view as metro_canvas_view
from rel_metro.ui_models import build_graph_canvas_view, build_graph_edge_inspector, build_graph_node_inspector


def test_graph_views_and_minimap_exist():
    views = list_views()
    assert any(v['view_id'] == 'core_relational_map' for v in views)
    payload = canvas_view('core_relational_map')
    assert payload['minimap']['nodes']
    assert payload['groups']


def test_graph_filter_and_grouping():
    payload = canvas_view('core_relational_map', filters={'text': 'anchor'}, group_by='status')
    visible = [n for n in payload['nodes'] if n['visible']]
    assert visible
    assert all(('anchor' in n['label'].lower() or 'anchor' in n['short_info_en'].lower() or 'anchor' in n['short_info_de'].lower()) for n in visible)
    assert payload['groups']


def test_node_and_edge_inspector():
    node_info = inspect_node('core_relational_map', 'anchor_ln_R0_lp')
    assert node_info['node']['id'] == 'anchor_ln_R0_lp'
    edge_info = inspect_edge('core_relational_map', 'edge_anchor_delta')
    assert edge_info['edge']['id'] == 'edge_anchor_delta'
    assert edge_info['snippet']['snippet_id'] == 'snippet_anchor_delta'


def test_edge_update_and_batch_update_persist():
    single = update_edge('edge_anchor_delta', {'label': 'Anchor → delta', 'strength': 0.75, 'status': 'implemented'})
    assert single['overrides']['label'] == 'Anchor → delta'
    batch = update_multiple_edges([
        {'edge_id': 'edge_delta_alpha', 'updates': {'label': 'delta → alpha', 'strength': 0.5}},
        {'edge_id': 'edge_delta_higgs', 'updates': {'label': 'delta → higgs', 'strength': 0.6}},
    ])
    assert len(batch['updated']) == 2
    edge_info = inspect_edge('core_relational_map', 'edge_delta_higgs')
    assert edge_info['edge']['label'] == 'delta → higgs'


def test_tour_runs_and_metro_logic_alias():
    tours = list_tours()
    assert any(t['tour_id'] == 'software_intro' for t in tours)
    payload = run_tour('software_intro')
    assert payload['steps']
    assert payload['final_run_dir']
    alias_payload = metro_canvas_view('core_relational_map')
    assert alias_payload['view']['view_id'] == 'core_relational_map'


def test_ui_model_builders():
    graph = build_graph_canvas_view('core_relational_map')
    assert graph['view']['view_id'] == 'core_relational_map'
    node = build_graph_node_inspector('core_relational_map', 'REL0')
    assert node['node']['id'] == 'REL0'
    edge = build_graph_edge_inspector('core_relational_map', 'edge_anchor_delta')
    assert edge['edge']['id'] == 'edge_anchor_delta'
