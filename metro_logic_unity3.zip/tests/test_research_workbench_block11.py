
from rel_metro.research_workbench import build_workbench_payload, write_workbench_payload


def test_workbench_payload_contains_visual_sections(tmp_path):
    payload = build_workbench_payload()
    assert payload['canvas']['nodes']
    assert payload['formulas']
    assert payload['interactions']
    assert payload['tests']['count'] >= 1
    assert 'explore' in payload['menu_explanations']


def test_workbench_payload_can_be_written(tmp_path):
    target = tmp_path / 'payload.json'
    write_workbench_payload(target)
    assert target.exists()
    assert 'canvas' in target.read_text(encoding='utf-8')
