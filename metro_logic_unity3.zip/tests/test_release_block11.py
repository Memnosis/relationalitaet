
from pathlib import Path
from rel_metro.release_manager import build_manifest, create_release_zip, verify_release_zip


def test_release_manifest_excludes_runs_and_pyc(tmp_path):
    project = tmp_path / 'proj'
    (project / 'runs').mkdir(parents=True)
    (project / '__pycache__').mkdir(parents=True)
    (project / 'src').mkdir(parents=True)
    (project / 'runs' / 'x.txt').write_text('ignore', encoding='utf-8')
    (project / '__pycache__' / 'x.pyc').write_bytes(b'bad')
    (project / 'src' / 'keep.txt').write_text('ok', encoding='utf-8')
    manifest = build_manifest(project)
    paths = {item['path'] for item in manifest['files']}
    assert 'src/keep.txt' in paths
    assert 'runs/x.txt' not in paths


def test_release_zip_is_valid(tmp_path):
    project = tmp_path / 'proj'
    project.mkdir()
    (project / 'README.md').write_text('hello', encoding='utf-8')
    zip_path = tmp_path / 'out.zip'
    create_release_zip(zip_path, project)
    report = verify_release_zip(zip_path)
    assert report['ok'] is True
