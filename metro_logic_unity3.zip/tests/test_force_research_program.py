from rel_metro.force_research_program import load_force_research_questions, list_force_research_questions, question_summary, research_gap_matrix, software_requirement_matrix, recommended_next_steps, relational_research_program_report
from rel_metro.research_questions import force_question_inventory


def test_registry_contains_100_questions():
    payload = load_force_research_questions()
    assert payload['metadata']['question_count'] == 100
    assert len(payload['questions']) == 100
    assert len(payload['metadata']['themes']) == 10


def test_summary_and_filters_are_consistent():
    summary = question_summary()
    assert summary['question_count'] == 100
    assert summary['theme_count'] == 10
    assert summary['blocked_question_count'] > 0
    assert len(list_force_research_questions(theme_id='ew_coupling')) == 10
    assert len(list_force_research_questions(force='weak')) > 0
    assert force_question_inventory()['question_count'] == 100


def test_gap_and_software_matrices_have_pressure():
    gaps = research_gap_matrix()
    software = software_requirement_matrix()
    assert gaps[0]['status'] in {'missing', 'partial', 'present'}
    assert any(row['status'] == 'missing' and row['question_count'] > 0 for row in gaps)
    assert software[0]['question_count'] > 0


def test_recommended_next_steps_and_report():
    next_steps = recommended_next_steps()
    report = relational_research_program_report()
    assert len(next_steps) > 0
    assert next_steps[0]['impact_score'] >= next_steps[-1]['impact_score']
    assert report['question_summary']['question_count'] == 100
    assert len(report['gap_matrix']) >= 5
