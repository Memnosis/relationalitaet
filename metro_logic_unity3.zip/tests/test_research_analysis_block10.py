from rel_metro.research_analysis import (
    official_force_map,
    clear_object_relationships,
    dataset_reliability_summary,
    relational_recalculation_targets,
    optimization_results,
    scientific_analysis_report,
)


def test_official_force_map_and_relationships():
    forces = official_force_map()
    ids = {row['force_id'] for row in forces}
    assert {'electromagnetic', 'weak', 'strong'}.issubset(ids)
    relationships = clear_object_relationships()
    assert any(row['left'] == 'electromagnetic' and row['right'] == 'weak' and row['relationship_status'] == 'officially_clear' for row in relationships)
    assert any('gravity_interface' in {row['left'], row['right']} and row['needs_relational_recalculation'] for row in relationships)


def test_dataset_reliability_and_recalculation_targets():
    summary = dataset_reliability_summary()
    assert summary['inventory']['elements'] >= 118
    assert summary['dataset_status_counts']['missing'] > 0
    targets = relational_recalculation_targets()
    target_ids = {row['force'] for row in targets}
    assert {'electromagnetic', 'weak', 'strong', 'gravity_interface'}.issubset(target_ids)
    assert any(row['missing_or_partial_datasets'] for row in targets)


def test_optimization_results_and_report():
    results = optimization_results()
    assert len(results['top_software_priorities']) >= 3
    assert len(results['top_dataset_priorities']) >= 3
    assert any('running-coupling' in item for item in results['recommended_expansions'])
    report = scientific_analysis_report()
    assert 'dataset_reliability' in report
    assert 'optimization_results' in report
