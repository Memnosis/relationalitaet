from pathlib import Path
import json
from metro_logic_unity import app_identity, build_payload, docs_index

ROOT = Path(__file__).resolve().parents[1]


def test_unity_docs_present():
    for name in [
        'METRO_LOGIC_UNITY3_SPEC.md',
        'METRO_LOGIC_UNITY3_REQUIREMENTS.md',
        'METRO_LOGIC_UNITY3_PFLICHTENHEFT.md',
        'METRO_LOGIC_UNITY3_DOCS_INDEX.md',
        'METRO_LOGIC_UNITY3_ARCHITECTURE.md',
        'METRO_LOGIC_UNITY3_UX_GUIDE.md',
    ]:
        assert (ROOT / 'docs' / name).exists()


def test_unity_integration_registry_present():
    data = json.loads((ROOT / 'configs' / 'unity_integration_registry.json').read_text(encoding='utf-8'))
    assert data['name'] == 'metro_logic_unity3'
    assert data['legacy_docs_archived'] is True
    assert 'workbench_payload.py' in data['public_modules']


def test_unity_facade_identity_and_payload():
    assert app_identity()['name'] == 'metro_logic_unity3'
    payload = build_payload()
    assert payload['metadata']['app_slug'] == 'metro_logic_unity3'
    assert 'browser_datasets' in payload
    assert payload['dataset_inventory']['research_questions'] == 100
    assert 'archive' in docs_index()
