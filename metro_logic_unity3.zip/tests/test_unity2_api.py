
from metro_logic.api_server import get_atom_states, get_sm_channels, get_sm_particles, get_sm_auxiliary_objects, get_unity3_validation_report

def test_unity3_api_payloads():
    assert len(get_atom_states()['atom_states']) == 118
    assert len(get_sm_channels()['channels']) == 26
    assert len(get_sm_particles()['particles']) >= 10
    assert len(get_sm_auxiliary_objects()['auxiliary']) >= 3
    assert get_unity3_validation_report()['ok'] is True
