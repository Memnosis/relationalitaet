from rel_metro.completeness_guard import evaluate_completeness

def test_completeness_guard_passes():
    report = evaluate_completeness()
    assert report['required_files_present']
    assert report['ok']
