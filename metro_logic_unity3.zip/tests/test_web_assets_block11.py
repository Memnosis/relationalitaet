from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_visual_workbench_assets_are_present():
    html = (ROOT / 'web' / 'index.html').read_text(encoding='utf-8')
    js = (ROOT / 'web' / 'app.js').read_text(encoding='utf-8')
    assert 'browserTabs' in html
    assert 'browserDetail' in html
    assert 'headerNext' in html
    assert 'renderBrowser' in js
    assert 'formulaCardsHtml' in js
    assert 'docsCardHtml' in js
