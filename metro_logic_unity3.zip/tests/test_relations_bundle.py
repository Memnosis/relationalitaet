import json
import threading
import time
import urllib.request
from pathlib import Path

from rel_metro.pipeline import execute
from rel_metro.dependency import impacted_nodes
from rel_metro.parameter_registry import registry_index
from rel_metro.relation_registry import load_relation_registry, relations_for_node
from rel_metro.relation_engine import evaluate_all_relations, relation_test_suite
from rel_metro.dataset_importer import load_profile_payload
from rel_metro.ui_models import build_dependency_view, build_dataset_admin_view
from rel_metro.api_server import serve


def test_foundation_and_dependency_registry():
    result = execute('default_project')
    assert 'alpha_inverse' in result['flat_outputs']
    assert 'higgs_mass_gev' in result['flat_outputs']
    assert 'alpha_inverse' in impacted_nodes(['anchor_ln_R0_lp'])
    assert 'alpha_inverse' in registry_index()


def test_relation_registry_and_node_mapping():
    registry = load_relation_registry()
    ids = {item['relation_id'] for item in registry['relations']}
    assert 'official_on_shell_weinberg' in ids
    assert 'rel_anchor_alpha' in ids
    node_map = relations_for_node('alpha_inverse')
    assert any(item['relation_id'] == 'rel_anchor_alpha' for item in node_map['incoming_relations'])


def test_relation_evaluation_and_sensitivity_outputs():
    run = execute('default_project', run_relation_tests=True)
    values = {**run['config']['values'], **run['flat_outputs']}
    results = evaluate_all_relations(values)
    assert 'official_on_shell_weinberg' in results
    suite = relation_test_suite('default_project', epsilon=1e-2, layers=['official', 'relational_known'])
    assert 'anchor_ln_R0_lp' in suite['sensitivity_matrix']


def test_schema_validation_and_views(tmp_path: Path):
    payload_path = tmp_path / 'profile.json'
    payload_path.write_text(json.dumps({'profile_name': 'tmp', 'reference_sets': ['nist_codata_2022'], 'overrides': {'alpha_ideal_inv': 137.0}}), encoding='utf-8')
    payload = load_profile_payload(payload_path)
    assert payload['overrides']['alpha_ideal_inv'] == 137.0
    view = build_dependency_view('alpha_inverse')
    assert 'graph_layout' in view
    admin = build_dataset_admin_view()
    assert 'default_project' in admin['profiles']


def test_api_compare_and_benchmarks():
    port = 8879
    server_thread = threading.Thread(target=serve, kwargs={'host': '127.0.0.1', 'port': port}, daemon=True)
    server_thread.start()
    time.sleep(0.2)
    def get_json(url, data=None):
        req = urllib.request.Request(url)
        if data is not None:
            body = json.dumps(data).encode('utf-8')
            req = urllib.request.Request(url, data=body, headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode('utf-8'))
    relations = get_json(f'http://127.0.0.1:{port}/relations')
    assert any(item['relation_id'] == 'rel_anchor_alpha' for item in relations['relations'])
    comparison = get_json(f'http://127.0.0.1:{port}/compare', {'left_profile': 'default_project', 'right_profile': 'sanity_shifted'})
    assert 'output_comparison' in comparison
    bench = get_json(f'http://127.0.0.1:{port}/benchmarks/run', {'profiles': ['default_project', 'sanity_shifted'], 'run_relation_tests': True})
    assert 'comparisons' in bench
