import json
from urllib.request import urlopen, Request
from threading import Thread
from rel_metro.api_server import make_server


def _get_json(url: str):
    with urlopen(url) as response:
        return json.loads(response.read().decode('utf-8'))


def test_research_api_endpoints():
    server = make_server(port=0)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    try:
        summary = _get_json(base + '/research/questions/summary')
        assert summary['question_count'] == 100
        questions = _get_json(base + '/research/questions?theme_id=chemical_patterns')
        assert len(questions['questions']) == 10
        gaps = _get_json(base + '/research/gaps')
        assert any(row['status'] == 'missing' for row in gaps['gaps'])
        caps = _get_json(base + '/research/software-requirements')
        assert len(caps['capabilities']) >= 5
        report = _get_json(base + '/research/program-report')
        assert report['question_summary']['question_count'] == 100
        analysis = _get_json(base + '/research/scientific-analysis')
        assert len(analysis['official_force_map']) >= 4
        assert analysis['dataset_reliability']['inventory']['elements'] >= 118
    finally:
        server.shutdown()
        server.server_close()
