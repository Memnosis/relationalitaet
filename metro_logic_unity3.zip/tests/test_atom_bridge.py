from rel_metro.atom_registry import list_elements, get_element
from rel_metro.atom_bridge import build_atom_state, periodic_trend_slice, atom_dependency_overview


def test_atom_registry_first20_present():
    elems = list_elements()
    assert len(elems) >= 20
    assert get_element('H')['atomic_number'] == 1
    assert get_element('Ne')['group'] == 18


def test_build_atom_state_has_vector_and_observables():
    state = build_atom_state('O')
    assert state['state_vector']['loop_level'] == 2
    assert state['observables']['typical_valence'] == 6
    assert state['status']['compute_ready'] is True


def test_periodic_trend_slice_and_dependency_overview():
    rows = periodic_trend_slice()
    assert rows[0]['symbol'] == 'H'
    ov = atom_dependency_overview('Na')
    assert 'global_anchor_387_26' in ov['direct_dependencies']
    assert 'isotope_stability_rule' in ov['known_unknowns']
