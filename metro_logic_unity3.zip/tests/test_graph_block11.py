
import json
from rel_metro.graph_workbench import GraphWorkbench


def test_node_position_persistence(tmp_path, monkeypatch):
    wb = GraphWorkbench()
    wb.layout_store = {'positions': {}}
    saved = {}
    def fake_save():
        saved.update(wb.layout_store)
    monkeypatch.setattr(wb, '_save_layouts', fake_save)
    result = wb.save_node_positions([{'node_id': 'REL0', 'x': 123, 'y': 456}])
    assert result['saved'] == 1
    assert saved['positions']['REL0'] == {'x': 123.0, 'y': 456.0}


def test_node_update_adds_override(monkeypatch):
    wb = GraphWorkbench()
    wb.overrides = {}
    monkeypatch.setattr(wb, '_save_overrides', lambda: None)
    result = wb.update_node('REL0', {'label': 'REL0X', 'status': 'official_reference'})
    assert result['overrides']['label'] == 'REL0X'
    assert result['quality_label'] == 'official_reference'
