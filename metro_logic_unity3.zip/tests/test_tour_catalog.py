from rel_metro.tour_catalog import list_all_tours, tour_summary

def test_tour_catalog_merges_sources():
    tours = list_all_tours()
    assert tours
    summary = tour_summary()
    assert summary['tour_count'] >= 3
    assert summary['step_count'] >= summary['tour_count']
