import json
from pathlib import Path
from metro_logic.bundle_ingest import bundle_schema, validate_bundle, import_bundle, load_uploaded_bundle_details
from metro_logic.workbench_payload import build_workbench_payload


def test_bundle_schema_contains_new_sections():
    schema = bundle_schema()
    assert 'node_datasheets' in schema['optional']
    assert 'edge_formulas' in schema['optional']


def test_validate_and_import_bundle(tmp_path, monkeypatch):
    from metro_logic import bundle_ingest as bi
    monkeypatch.setattr(bi, 'CONFIGS', tmp_path)
    monkeypatch.setattr(bi, 'UPLOAD_DIR', tmp_path / 'upload_bundles')
    monkeypatch.setattr(bi, 'REGISTRY_PATH', tmp_path / 'upload_bundle_registry.json')
    payload = {
        'metadata': {'bundle_id': 'test_bundle', 'title': 'Test Bundle'},
        'node_datasheets': [{'node_id': 'REL0', 'title_de': 'REL0 Blatt'}],
        'edge_formulas': [{'edge_id': 'edge_rel0_rel1', 'formula_id': 'f_test', 'equation_latex': 'R=1'}],
    }
    validation = validate_bundle(payload)
    assert validation['valid'] is True
    result = import_bundle(payload)
    assert result['imported'] is True
    details = load_uploaded_bundle_details()
    assert details[0]['bundle_id'] == 'test_bundle'


def test_workbench_payload_exposes_uploads():
    payload = build_workbench_payload()
    assert 'node_sheets' in payload['browser_datasets']
    assert 'edge_formulas' in payload['browser_datasets']
    assert 'uploads' in payload['browser_datasets']
    assert payload['upload_support']['supports_offline_import'] is True
