
from rel_metro.pipeline import execute
from rel_metro.atom_registry import list_elements, list_isotopes
from rel_metro.research_core import load_assumptions, load_necessity_registry, necessity_report
from rel_metro.relation_registry import all_relations


def test_chemistry_registry_integrated():
    assert len(list_elements()) == 118
    assert len(list_isotopes()) == 118


def test_pipeline_has_chemistry_sector_and_research_outputs():
    run = execute('default_project', run_relation_tests=True)
    assert 'chemistry' in run['results']
    assert 'chemistry_element_count' in run['flat_outputs']
    assert 'freedom_balance' in run
    assert 'research_summary' in run
    assert run['flat_outputs']['chemistry_element_count'] == 118


def test_assumption_and_necessity_registries_present():
    assert len(load_assumptions()['assumptions']) >= 3
    assert len(load_necessity_registry()['features']) >= 3


def test_necessity_report_has_w_paths():
    run = execute('default_project')
    rep = necessity_report(run['config']['values'], run['flat_outputs'])
    assert 'w_paths' in rep
    assert rep['w_paths']['difference_abs'] >= 0


def test_relation_registry_merged_with_chemistry():
    ids = {r['relation_id'] for r in all_relations()}
    assert 'official_on_shell_weinberg' in ids
    assert 'periodic.group_outer_electrons.main_group' in ids
    assert 'relational.valence_tension_bridge' in ids
