from metro_logic.workbench_payload import build_workbench_payload


def test_unity_workbench_payload_has_rich_browser_datasets():
    payload = build_workbench_payload()
    assert payload['metadata']['app_name'] == 'metro_logic_unity3 Workbench'
    assert set(['elements', 'isotopes', 'forces', 'snippets', 'formulas', 'questions', 'docs', 'tests']).issubset(payload['browser_datasets'])
    assert len(payload['browser_datasets']['elements']) >= 50
    assert len(payload['browser_datasets']['questions']) == 100
    assert 'docs_index' in payload
