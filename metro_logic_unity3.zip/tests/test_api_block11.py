
import json
import urllib.request
from threading import Thread
from rel_metro.api_server import make_server


def fetch_json(url: str, data: dict | None = None):
    req = urllib.request.Request(url, data=None if data is None else json.dumps(data).encode('utf-8'), headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=10) as response:
        return json.loads(response.read().decode('utf-8'))


def test_research_workbench_endpoint():
    httpd = make_server(port=0)
    thread = Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        port = httpd.server_address[1]
        payload = fetch_json(f'http://127.0.0.1:{port}/research/workbench')
        assert payload['canvas']['nodes']
        assert payload['scientific_analysis']['clear_relationships']
    finally:
        httpd.shutdown(); httpd.server_close(); thread.join(timeout=5)


def test_graph_node_update_endpoint():
    httpd = make_server(port=0)
    thread = Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        port = httpd.server_address[1]
        payload = fetch_json(f'http://127.0.0.1:{port}/graph/node/update', {'node_id': 'REL0', 'updates': {'label': 'REL0 Test'}})
        assert payload['node_id'] == 'REL0'
        assert payload['overrides']['label'] == 'REL0 Test'
    finally:
        httpd.shutdown(); httpd.server_close(); thread.join(timeout=5)
