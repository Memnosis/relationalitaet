# METRO_LOGIC_UNITY3_FINAL

metro_logic_unity3 ist der aktuelle Hauptstand mit bereinigtem Release, vereinheitlichter Unity3-Benennung und klarerem Abstand zur echten Finalversion.

Siehe:
- `METRO_LOGIC_UNITY3_STATUS.md`
- `METRO_LOGIC_UNITY3_TEST_REPORT.md`
- `docs/METRO_LOGIC_UNITY3_FINAL_GAP_MAP.md`
- `docs/METRO_LOGIC_UNITY3_RELEASE_ASSURANCE.md`
