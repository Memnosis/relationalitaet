# METRO_LOGIC_UNITY2_DATA_NOTES

Die 118 Elemente und 118 Isotope werden aus dem reicheren Block-4-Stand übernommen. Der Atomaufbau wird in Unity2 als eigenes Register abgeleitet. Das SM-Register bleibt bei 4 offiziellen Sektoren plus 26 Parametern, wird aber um 26 Kanäle, Partikel und Hilfsobjekte erweitert. Hilfsobjekte dienen der Modellierung, Fehlerbehandlung oder Renormierung und sind nicht als direkt beobachtete Teilchen markiert.
