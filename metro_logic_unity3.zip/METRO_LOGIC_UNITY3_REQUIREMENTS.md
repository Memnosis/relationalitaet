# METRO_LOGIC_UNITY2_REQUIREMENTS

## Muss-Anforderungen
1. Alle Kernregister müssen vollständig lesbar und validierbar sein.
2. Jeder öffentliche Funktionspfad in rel_metro, metro_logic und metro_logic_unity muss einer Testdatei zugeordnet sein.
3. Release-Artefakte dürfen keine Cache- oder Laufzeitreste enthalten.
4. Die Web-Workbench muss Elemente, Isotope, Atomzustände, SM26, Kanäle, Partikel, Hilfsobjekte, Formeln, Fragen, Uploads, Docs und Tests browsen können.
5. Hilfsobjekte wie Ghosts, Counterterms und Nuisance-Objekte müssen klar als nicht beobachtete Artefakte markiert sein.
