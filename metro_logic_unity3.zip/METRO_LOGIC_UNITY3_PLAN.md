# METRO_LOGIC_UNITY3_PLAN

## Was jetzt in Unity3 umgesetzt wurde
- stabile Release-Basis ohne Laufzeitballast
- vereinheitlichte Unity3-Benennung
- harte Completeness- und Testkontrolle
- klarer Gap-Plan zur echten Finalversion

## Was bis zu einer wirklichen Finalversion noch fehlt
1. tiefere browserseitige Interaktion für Knoten/Kanten/Formeln
2. serverseitige Persistenz direkt aus der UI
3. stärkere facettierte Browser für große Chemie-/Atom-/SM-Datenmengen
4. robuste Upload-Workflows mit Konfliktauflösung
5. End-to-End-Tests für UI-Flüsse und Touren
