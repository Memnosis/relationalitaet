# METRO_LOGIC_UNITY2_FINALIZATION_PLAN

1. stabile Basis sichern
2. Kernregister auf Vollständigkeit ziehen
3. Validierung und Inventar scharf schalten
4. UI/Browser an neue Register anbinden
5. Release-Hygiene erzwingen
6. finale Version auf dieser Basis vorbereiten
