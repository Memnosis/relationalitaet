# metro_logic_unity3

metro_logic_unity3 ist der finalisierte Hauptstand für visuelle relationale Forschung zwischen Physik, Chemie und dem Standardmodell.

## Leitidee

Die Software verbindet eine browserbasierte Forschungsoberfläche mit belastbaren wissenschaftlichen Registries, Provenienz, Formeln, Anforderungen, Pflichten und umfassender Testkontrolle.

## Kernbereiche

- `src/metro_logic/`: browser-first Oberfläche, Workbench-Payload, API, UI-Helfer, Datenvalidierung
- `src/rel_metro/`: wissenschaftliche Kernmodule, Relationen, Formeln, Atom-/Chemie-/SM-Brücken
- `src/metro_logic_unity/`: vereinheitlichte Fassade und Startpunkte
- `configs/`: Registries, Verträge, Testsets, Formeln, Touren, Forschungsfragen, Upload-Bundles
- `web/`: statische Workbench mit Canvas, Browsern, Touren, Tests und Dokumentation
- `docs/`: vereinheitlichte Spezifikation, Anforderungen, Pflichten, UX- und Architekturleitfäden
- `tests/`: Release-, UI-, Graph-, Forschungs- und Integrationsprüfungen

## Startpunkte

- `METRO_LOGIC_UNITY3_FINAL.md`
- `METRO_LOGIC_UNITY3_SPEC.md`
- `METRO_LOGIC_UNITY3_REQUIREMENTS.md`
- `METRO_LOGIC_UNITY3_PFLICHTENHEFT.md`
- `METRO_LOGIC_UNITY3_DOCS_INDEX.md`
- `web/index.html`

## Release-Hygiene

Das Release ist bewusst klein gehalten. Laufzeitverzeichnisse wie `runs/`, Cache-Artefakte und alte Block-Root-Dateien gehören nicht in das Auslieferungsarchiv.

## Upload-Bundles

- Neue Knoten-Datenblätter und Kanten-Formeln sind als JSON-Bundles vorgesehen.
- Die Workbench unterstützt Bundle-Schema, Vorschau, Overlay und persistente API-Importe.
- Bundle-Daten werden mit QC-Labels als Erweiterungen behandelt, bis sie validiert sind.
