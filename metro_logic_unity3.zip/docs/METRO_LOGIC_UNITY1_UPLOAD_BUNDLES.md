# METRO_LOGIC_UNITY1 Upload Bundles

## Ziel
Neue Knoten-Datenblätter und Kanten-Formeln sollen künftig direkt als Bundle eingebracht werden können, ohne dass der Kernbestand manuell umgebaut werden muss.

## Bundle-Typen
- `node_datasheets`: zusätzliche Datenblätter für vorhandene oder künftige Knoten
- `edge_formulas`: Formeln, Beschreibungen und LaTeX für Kanten/Relationen
- `snippets`: optionaler Codebezug
- `docs`: optionale Kurz-Dokumente oder Notizen

## Mindestformat
```json
{
  "metadata": {"bundle_id": "my_bundle", "title": "My Bundle", "language": "de"},
  "node_datasheets": [{"node_id": "REL0", "title_de": "REL0 Blatt", "summary_de": "..."}],
  "edge_formulas": [{"edge_id": "edge_rel0_rel1", "formula_id": "f_rel0_rel1", "equation_latex": "R=..."}]
}
```

## UX
- Upload-Ansicht im Browser
- Schema-Vorschau direkt in der Oberfläche
- lokale Overlay-Ansicht ohne Server
- API-Import für persistente Ablage über `/bundle/import`

## Qualitätsregel
Upload-Bundles sind standardmäßig `bundle_extension` oder `bundle_draft`, bis sie als Referenzdaten bestätigt wurden.
