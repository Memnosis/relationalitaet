# Anforderungen an Atommodell und Chemie

## Zweck

Diese Spezifikation fasst die Anforderungen an eine zukünftige Atom- und Chemieebene innerhalb von `rel_metro` zusammen. Sie dient als Brücke zwischen der bisherigen Teilchen-/Metrologieebene und einer relationalen Beschreibung von Atomen, Elementen, Isotopen und chemischen Mustern.

Der Leitgedanke lautet:

> Um weitere Größen wirklich berechenbar zu machen, werden nicht nur neue Endformeln benötigt, sondern belastbare Zwischenobjekte und Zwischenstufen.

## 1. Atome und Elemente als berechenbare Zustände

Atome und chemische Elemente dürfen in der Software nicht nur als Namen, Ordnungszahlen oder Tabellenwerte vorkommen. Sie müssen als relationale Zustandsobjekte formulierbar werden.

### Mindestanforderung an einen atomaren Zustandsvektor

Ein zukünftiger Zustandsvektor kann in einer ersten Arbeitsform so beschrieben werden:

\[
A=(\ell, K, \Phi, Z, N, R, \rho)
\]

mit möglichen Komponenten:

- \(\ell\): Loop- oder Schalenniveau
- \(K\): Knotenklasse / topologische Klasse
- \(\Phi\): Phasenlage oder Resonanzlage
- \(Z\): Protonenzahl
- \(N\): Neutronenzahl bzw. Neutronenmodus
- \(R\): Resonanz- oder Radiusklasse
- \(\rho\): lokale Gitterspannungsdichte

## 2. Übersetzung zwischen Teilchenebene und Atomzustand

Die offene Projektlücke „Geometrie → Operator → Observable“ muss für den Atom- und Chemiebereich als explizite Brückenschicht formuliert werden.

Die Software muss abbilden können, wie atomare Zustände aus relationalen Grundgrößen entstehen, z. B. aus:

- globalem Anker
- REL0-/REL1-Schichten
- Gitterspannung
- Family-/Layer-/Threshold-Termen
- Generator-/Operatorstrukturen
- Vererbungs- und Closure-Regeln

## 3. Stabilitätskriterien für Elemente und Isotope

Für Elemente und Isotope braucht die Software künftig:

- ein Stabilitätskriterium
- ein Metastabilitätskriterium
- ein Zerfallskriterium
- ein Isotopen-Variationsmodell

Leitfragen:

- Wann ist ein Elementzustand stabil?
- Wann metastabil?
- Wann zerfällt der Zustand?
- Wann ist ein Neutronenzusatz nur eine Modulation des Grundtons?
- Wann kippt ein Isotop in einen qualitativ anderen Zustand?

## 4. Schalen- und Loop-Regeln

Nicht nur einzelne Elemente sollen fitbar sein, sondern Regeln der Form:

- welche Loop-Struktur erzeugt welche Schalenlogik?
- wann schließen sich Loops?
- welche Resonanzklassen entsprechen Perioden?
- welche Knotenwechsel entsprechen Gruppenwechseln?

## 5. Atomare Observable-Matrix

Die Atom-/Chemieebene muss auf direkt vergleichbare Größen zielen, etwa:

- Atomradius
- Ionisierungsenergie
- Elektronenaffinität
- Hauptvalenz / Oxidationsklassen
- Isotopenstabilität
- Bindungspräferenzen
- Periodentrends

## 6. Rolle des Elektrons als Brücke

Der Elektron-Threshold ist auf der Teilchenseite bereits ein klarer Spezialfall. Genau deshalb ist das Elektron wahrscheinlich die wichtigste Brücke zur Chemie:

- Schalen
- Bindung
- Ionisation
- Periodizität
- Valenz

## 7. Fraktalitätsprüfung über Skalen

Die Software soll später prüfen können:

- Gibt es dieselbe Form von Stabilitätsregel auf mehreren Skalen?
- Wiederholen sich dieselben Operator- oder Snap-in-Muster bei Teilchen, Atomzuständen, Elementfamilien und chemischen Resonanzen?

## 8. Minimale Softwareobjekte für die nächste Stufe

Die nächste ausbaubare Stufe benötigt mindestens:

- `atom_registry.json`
- `atom_bridge.py`
- `atom_state`-Objekte
- erste Observable-Matrix
- Stabilitäts- und Trendtests
- Markierung von `compute_ready`, `provisional` und `roadmap_only`

## 9. Sofort testbare erste Ziele

Vor voller Chemiemodellierung sollte zuerst geprüft werden:

1. Periodizität / Schalenabschluss als Strukturmuster
2. Elektronenbezug und Valenzklassen
3. Stabil vs. metastabil bei ausgewählten Isotopen
4. Trendrichtungen für erste 20 Elemente
5. Brücke zwischen relationalem Teilchenmodell und atomarer Diskretheit
