# Coder Guide

## Core modules
- `config.py`: project defaults, profiles, reference selection
- `dependency.py`: dependency graph, impact plan, graph layout
- `relation_registry.py`: relation catalog
- `relation_engine.py`: relation evaluation and perturbation-based tests
- `pipeline.py`: orchestration, logging, artifact writing
- `api_server.py`: external access for run, compare, benchmark and relation listing
- `ui_app.py`: multi-field editor, graphical dependency explorer, benchmark trigger

## Debug order
1. inspect `meta/config_diff.json`
2. inspect `meta/recompute_plan.json`
3. inspect `outputs/relation_results.json`
4. inspect `outputs/relation_test_suite.json`
5. inspect `outputs/sensitivity_matrix.json`
6. inspect `reports/relation_validation.md`
