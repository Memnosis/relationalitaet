# Coder Guide: Graph-Workbench Block 1

## Architekturidee
Die Graph-Workbench sitzt oberhalb von Register-, Relations- und Provenienzschicht.

## Datenmodell
- Nodes und Edges werden deklarativ in `graph_registry.json` gehalten.
- Touren werden in `tour_registry.json` gehalten.
- Snippets werden in `snippet_registry.json` gehalten.

## Warum deklarativ?
Damit spätere Erweiterungen und Tests ohne UI-Refactoring möglich bleiben.

## Teststrategie
- Registry-Dateien müssen strukturell vollständig sein.
- Jede Tour muss mindestens einen Schritt enthalten.
- Jede View muss Knoten und Kanten referenziell konsistent abbilden.
- API-Endpunkte müssen die neuen Register ausliefern.
