# REL_METRO_UNITY_SOURCE_MATRIX

## Was aus welchem Archiv übernommen wurde
- **Block 14**: Web-Workbench, Release-Disziplin, Completeness Guard, Research Workbench, Standard-Model-/Snippet-/Tour-Schichten.
- **Master Final Graph Block 1**: Graph-Workbench-Dokumentation und Testlinie, breiter wissenschaftlicher rel_metro-Kern.
- **v2.6 Requirements Audit**: Anforderungs- und Auditdenken, das bereits in den beibehaltenen Verträgen, Dokus und Tests sichtbar ist.
- **v2.8 Atom Bridge**: `sm_relation_lab.py`, Atom-/Research-Testsets, Annahme-/Notwendigkeits-Registry und passende Fachdokus/Tests.

## Warum diese Fusion
Der wissenschaftliche Unterbau war in den größeren Archiven stärker, die saubere Auslieferung und sichtbare UI dagegen im sicheren Block-14-Zweig. rel_metro_unity verbindet beides und hält Releases klein.
