# Anwendung

## Sichtbare Funktionen
- mehrfeldrige Eingabemaske
- grafischer Dependency-Explorer
- relationale und offizielle Beziehungen in derselben Arbeitsumgebung
- Benchmark-Serie
- API für externe Steuerung

## Wichtige Unterscheidung
Die Software trennt:
- offizielle Referenzwerte
- offiziell/definitorisch bekannte Beziehungen
- relationale Modellbeziehungen
- experimentelle Profiländerungen
