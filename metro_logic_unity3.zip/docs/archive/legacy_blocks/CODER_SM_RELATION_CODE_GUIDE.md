
# Coder Guide: SM relation code and research diagnostics

## New configuration files

- `configs/assumption_registry.json`
- `configs/necessity_registry.json`
- `configs/research_testset.json`

## New module

- `src/rel_metro/sm_relation_lab.py`

## Design rule

Do not bury scientific relations only inside sector code. Keep them registrable and separately testable.

## What is tested

- Official relations against references or current model values
- Relational relations against model outputs and references where available
- Necessity of optional relational shifts / compensators
- Sensitivities under small perturbations

## Why this matters for coding

If a relation is wrong or underspecified, that is both a scientific issue and a coding-maintenance issue. The software therefore treats relation definitions as versionable code artefacts.

## Safe extension pattern

1. Register the relation in JSON
2. Implement or reuse a code binding
3. Add a test in `tests/test_sm_relation_lab.py`
4. Check research suite outputs and regression impact
