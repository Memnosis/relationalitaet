# Pflichtenheft der Funktionseinheiten

## Ziel
Dieses Pflichtenheft definiert die Funktionseinheiten von `rel_metro`, ihre Aufgaben, die dazugehörigen Tests und die unveränderbaren Verträge.

## Funktionseinheiten

### 1. Start- und Einstiegsebene
- Benutzerdateien: `start-microsoft.bat`, `start-apple.command`
- Pflicht: direkter Einstieg ohne Umbenennung der Startdateien
- Test: Dateien vorhanden, Startlogik verweist auf `rel_metro.start_ui`

### 2. Konfigurationsschicht
- Modul: `config.py`
- Pflicht: Projektdefaults, Referenzsätze und Profile getrennt halten
- Test: Merge lädt Standardprofil und Referenzsatz korrekt

### 3. Parameterregister
- Modul: `parameter_registry.py`
- Pflicht: Parameter sind identifizierbar, klassifiziert und dokumentiert
- Test: Register lässt sich laden, enthält Kernelemente

### 4. Abhängigkeitsschicht
- Modul: `dependency.py`
- Pflicht: Graph-Snapshot und Recompute-Plan müssen erzeugbar sein
- Test: geänderte Inputs erzeugen konsistente `affected_nodes`

### 5. Relationsschicht
- Module: `relation_registry.py`, `relation_engine.py`
- Pflicht: offizielle und relationale Relationen sind einzeln testbar
- Test: Relation Registry lädt, Relation-Test-Suite erzeugt Sensitivitäts- und Einflussmatrix

### 6. Rechenmodule
- Module: `models_*`
- Pflicht: jeder Fachbereich liefert strukturierte Outputs
- Test: Pipeline-Run liefert Outputs für alle Kernsektoren

### 7. Pipeline
- Modul: `pipeline.py`
- Pflicht: pro Run Artefakte schreiben und Relationstests optional mitführen
- Test: Run-Ordner enthält Pflichtdateien laut Vertrag

### 8. GUI
- Modul: `ui_app.py`
- Pflicht: Inputs, Import, Compare, Dependencies und Relations darstellen
- Test: GUI-Helfer lassen sich ohne laufende Mainloop prüfen

### 9. API
- Modul: `api_server.py`
- Pflicht: Run, Vergleich, Benchmark-Serie und Relationenzugriff
- Test: Health, Run, Compare-Runs und Benchmark-Endpoints antworten

## Unveränderbare Verträge
Siehe `configs/contracts.json`.


### 10. Forschungsprogramm und Datengaps
- Module: `research_questions.py`, `force_research_program.py`
- Pflicht: Forschungsfragen müssen messbare Observable, benötigte Datensätze und notwendige Softwarefähigkeiten referenzieren
- Test: Registry lädt mit 100 Fragen; Gap-Matrix und Next-Step-Liste sind konsistent

### 11. Release-Härte
- Module: `release_manager.py`, `completeness_guard.py`
- Pflicht: Release gilt nur als vollständig, wenn Pflichtdateien, Testmatrix und Archivprüfung konsistent sind
- Test: ZIP-Verifikation, Completeness-Guard und Pflicht-Datei-Liste bestehen gemeinsam
