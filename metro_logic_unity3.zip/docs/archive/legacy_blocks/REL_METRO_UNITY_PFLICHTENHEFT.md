# REL_METRO_UNITY_PFLICHTENHEFT

## Pflichtblöcke
### P1 Oberfläche
- Web-Workbench mit Navigation, Canvas, Inspector, Test-/Tour-/Docs-Zugang
- Layout-Speicherung und Reset
- Bereichserklärung im Header

### P2 Wissenschaftlicher Kern
- Relation Engine
- Standard Model Registry
- Atom Registry und Atom Bridge
- Chemistry Explorer
- Formula Registry, DOI Provenance, Paper Registry
- SM Relation Lab

### P3 Forschungsbetrieb
- 100-Fragen-Programm
- Research Analysis / Workbench
- Gap- und Missing-Profile-Registry
- Snippet Library

### P4 Absicherung
- Completeness Guard
- Release Manager
- Function/Test Matrix
- Release-Manifest und SHA-256

## Pflichtreferenz auf Dateien
- Spezifikation: `docs/REL_METRO_UNITY_SPEC.md`
- Anforderungen: `docs/REL_METRO_UNITY_REQUIREMENTS.md`
- Funktion/Test-Matrix: `configs/function_test_matrix.json`
- Integrationsmatrix: `configs/unity_integration_registry.json`

## Pflichtreferenz auf Tests
- Release/Guard: `tests/test_release_block11.py`, `tests/test_completeness_guard.py`
- UI/Web: `tests/test_web_assets.py`, `tests/test_web_assets_block11.py`
- Graph: `tests/test_graph_workbench.py`, `tests/test_graph_block11.py`
- Forschung: `tests/test_force_research_program.py`, `tests/test_research_workbench_block11.py`, `tests/test_research_analysis_block10.py`
- Wissenschaftliche Module: `tests/test_atom_bridge.py`, `tests/test_sm_relation_lab.py`, `tests/test_standard_model_registry.py`, `tests/test_doi_block2.py`
