
# MASTER FINAL – Block A+B Specification

This package implements the first two execution blocks of the `master_final` plan.

## Block A – Full Integration Core
- one shared codebase under `src/rel_metro`
- unified configs for project values, parameter registry, dependencies and relations
- chemistry/atom bridge merged into the same package and pipeline
- one run artifact model for particle, relation and chemistry outputs
- benannte starter: `start-microsoft.bat`, `start-apple.command`

## Block B – Research Core
- relation tests for official and relational relations
- sensitivity and influence matrix generation
- freedom / prediction balance bookkeeping
- assumption inventory
- necessity probes for anchor layer, W-shift variants and chemistry bridge

## Not yet final
- complete final GUI
- full chemistry explorer UI polish
- full `master_final` D-level end-user release quality
