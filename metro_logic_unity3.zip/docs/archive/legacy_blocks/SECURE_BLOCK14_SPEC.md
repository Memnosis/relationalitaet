# Secure Block 14 Spec

## Fokus
Block 14 vertieft die sichtbare Forschungsoberfläche aus Block 13/11:

- Menügruppen statt flacher Hauptnavigation
- kontextuelle Hilfe im Header
- nächste sinnvolle Schritte je Bereich
- Browser-Vorschauen für ausgewählte Datenklassen
- stärker verzahnte Explore/Physics/Chemistry/Relational/Tours/Tests/Docs-Sichten

## Technische Punkte
- `web/app.js` erweitert
- `web/data/workbench_payload.json` um `menu_groups`, `help_sections`, `browser_previews`, `next_steps` ergänzt
- lokaler Layout-Key auf `rel_metro_block14_layout` gehoben
