# Secure Block 11 Status

- Browserbasierte visuelle Workbench ersetzt den Platzhalter.
- Graph-Canvas mit stabilen Knoten/Kanten, Hover, Inspector, Minimap und lokaler Layout-Speicherung.
- API erweitert um Workbench-Payload, Node-Update und Positionspersistenz.
- Release-Bau schließt runs/, __pycache__ und Archivmüll aus.
- Forschungsdaten, Formeln, Touren, Tests und Doku im UI sichtbar.
