# Secure Block 8 Spec

- valid ZIP release
- manifest and checksum support
- completeness contract
- browseable registries for forces, snippets and tours
