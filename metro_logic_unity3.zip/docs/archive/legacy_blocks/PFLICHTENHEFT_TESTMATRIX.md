# Pflichten/Test-Matrix

Alle öffentlichen Funktionen in `src/rel_metro` sind in `configs/function_test_matrix.json` referenziert.


## Block 9 Ergänzung
- Jede neue öffentliche Funktion in `force_research_program.py` ist in `configs/function_test_matrix.json` eingetragen.
- Forschungsfragen sind nicht nur Dokumentation, sondern testbares Datenobjekt.
- API-Endpunkte für Forschungsfragen und Gap-Analyse haben Verhaltenstests.
