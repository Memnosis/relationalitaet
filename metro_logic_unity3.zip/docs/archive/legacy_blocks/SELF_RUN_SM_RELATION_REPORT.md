# Self-run SM Relation Report

- profile: default_project
- run_dir: /mnt/data/rel_metro_v2_7_sm_relation_lab/runs/rel_metro_20260315_003816_187222
- relation tests enabled: yes
- research suite enabled: yes

## Included research layers

- official relation suite: 12 relations
- relational relation suite: 18 relations
- assumptions inventoried: 5
- necessity probes: 4
- perturbation sources: 24

## Example probes

- official_on_shell_weinberg present: True
- rel_anchor_alpha present: True
- w_compensator_necessity present: True

## Notes

This self-run does not prove any theory. It verifies that the software can execute, compare and store:
- official Standard Model relation tests,
- relational relation tests,
- necessity checks for optional shifts/compensators,
- assumption inventory,
- sensitivity and influence diagnostics.
