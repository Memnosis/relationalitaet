# Block 9 Stabilität, Forschung und Usability

## Verstärkungen in diesem Block
- 100-Fragen-Forschungsprogramm als strukturierte Registry
- API-Zugriff auf Fragen, Gaps, Softwareanforderungen und Programmreport
- explizite Koppelung von Datengaps an Forschungsfragen
- explizite Koppelung von Softwarefähigkeiten an blockierte Fragen
- Erweiterung des Pflichtenhefts um Forschungsprogramm und Release-Härte

## Direkte Produktverbesserungen
- Forschung kann nicht mehr nur narrativ beschrieben werden, sondern als durchsuchbarer Katalog
- Tours, Graph und Snippets können künftig dieselben Fragestellungen tragen
- UI/Explorer kann auf priorisierte Fragen statt auf lose Datenlisten gehen
- Fehlende Datensätze sind als erste Objekte sichtbar und testbar
