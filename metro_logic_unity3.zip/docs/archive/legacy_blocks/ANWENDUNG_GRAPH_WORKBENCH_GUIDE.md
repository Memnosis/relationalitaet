# Anwendung: Graph-Workbench Block 1

Die neue Graph-Workbench zeigt in vorbereiteten Ansichten:
- welche Kernobjekte zusammenhängen,
- welche Touren verfügbar sind,
- und welche Code-/Formel-Snippets zu zentralen Beziehungen hinterlegt sind.

In Block 1 ist dies als vorbereitende Workbench-Sicht implementiert. Spätere Blöcke machen daraus einen voll interaktiven Canvas.
