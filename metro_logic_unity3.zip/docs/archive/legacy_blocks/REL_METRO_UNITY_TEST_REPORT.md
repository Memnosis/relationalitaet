# REL_METRO_UNITY_TEST_REPORT

Executed checks:
- `python -m py_compile src/rel_metro/*.py src/metro_logic/*.py`
- `pytest -q tests/test_rel_metro_unity.py`
- `pytest -q tests/test_web_assets_block11.py`
- `pytest -q tests/test_release_block11.py`
- `pytest -q tests/test_completeness_guard.py`
- `pytest -q tests/test_graph_workbench.py`
- `pytest -q tests/test_atom_bridge.py`
- `pytest -q tests/test_sm_relation_lab.py`
- `pytest -q tests/test_standard_model_registry.py`

Result: 19 tests passed.
