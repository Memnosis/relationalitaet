# Secure Block 11 Spec

Ziel: sichtbare Workbench zuerst.

Umfang:
- echtes Web-Frontend statt Platzhalter
- Header-Erklärungen, Sprachumschaltung DE/EN
- Canvas, Inspector, Formeln, Touren, Tests, Docs
- Node-Update + Knotenpositionspersistenz
- Workbench-Export als statische JSON für Offline-Nutzung
- sauberer Release-Prozess ohne runs/ und __pycache__
