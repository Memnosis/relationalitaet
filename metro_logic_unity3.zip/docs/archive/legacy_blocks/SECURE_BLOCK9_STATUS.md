# Secure Block 9 Status

- Forschungsprogramm mit 100 Fragen integriert
- API für Fragen/Gaps/Softwareanforderungen integriert
- Pflichtenheft und Testmatrix erweitert
- Release wieder als verifiziertes ZIP gebaut
