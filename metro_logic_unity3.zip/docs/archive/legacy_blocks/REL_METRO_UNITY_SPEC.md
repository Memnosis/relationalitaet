# REL_METRO_UNITY_SPEC

## Zweck
rel_metro_unity vereinigt den wissenschaftlich stärkeren rel_metro-Unterbau mit der saubereren, browserbasierten metro_logic-Workbench.

## Systemkern
1. **Browser-Workbench** in `web/` mit Navigation, Canvas, Inspector, Tour-/Test-/Doku-Zugang.
2. **Wissenschaftliche Kernmodule** in `src/rel_metro/` für Relationen, Standardmodell, Atom-/Chemie-Brücken, Formel- und Paper-Registry.
3. **Release- und Vollständigkeitsmechanik** über `release_manager.py` und `completeness_guard.py`.
4. **Forschungsprogramme** für 100 Fragen, Datengaps, QC-Labels und relationale Hypothesen.

## Integrierte Quellen
- `metro_logic_secure_block14_2026-03-16.zip` als saubere Release-/UI-Basis
- `rel_metro_master_final_graph_block1.zip` für Graph-Workbench- und Registry-Linie
- `rel_metro_v2.6_requirements_audit_bundle.zip` für Audit-/Anforderungsdisziplin
- `rel_metro_v2.8_atom_bridge_bundle.zip` für SM-Relation-Lab und Atom-Bridge-Erweiterung

## Leitprinzipien
- UI zuerst sichtbar, Daten/API dienen der Oberfläche
- Referenzdaten strikt getrennt von relationalen Hypothesen
- Formeln, Papers, Provenienz und Datengaps sind erstklassige Objekte
- jede öffentliche Funktion soll einer Pflicht und einem Test zuordenbar sein
- Releases sind klein, reproduzierbar und validierbar

## Hauptobjekte
- Graph-Knoten/Kanten
- Standardmodell-Kräfte und Partikel
- Elemente, Isotope, Atom-/Chemie-Brücken
- Relationen, Annahmen, Notwendigkeiten, Snippets, Touren, Formeln, Papers
- Forschungsfragen, Datengaps, QC-Labels

## Sichtbare Produktflächen
- Explore / Physics / Chemistry / Relational / Tours / Tests / Docs
- Inspector mit Kurzbeschreibung, Formelpfaden, Datenqualität und nächsten Schritten
- Mehrsprachigkeit DE/EN mit späterer Erweiterbarkeit

## Nicht-Ziele dieses Release
- kein vollständiger n8n-Ersatz
- keine vollwertige serverseitige Multiuser-Persistenz
- keine fertige relationale Kraftrechnung; stattdessen vorbereitete Workbench mit Gap- und Provenienzstruktur
