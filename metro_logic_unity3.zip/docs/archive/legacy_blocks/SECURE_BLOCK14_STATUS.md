# Secure Block 14 Status

Dieser Stand wurde aus dem wieder hochgeladenen Block-11-Anker rekonstruiert und die Block-14-Vertiefung erneut eingezogen.

## Enthalten
- vertiefte browserbasierte Workbench
- gruppierte Menüs
- stärkere Header-Erklärung mit Hilfetext und nächsten Schritten
- Browser-Vorschauen für Kräfte, Elemente, Snippets und Tests
- Block-14-Layoutspeicher

## Prüfstatus
- Web-Dateien syntaktisch geprüft
- Release-/Completeness-Tests bestanden
- Archiv wird vor Auslieferung erneut geprüft
