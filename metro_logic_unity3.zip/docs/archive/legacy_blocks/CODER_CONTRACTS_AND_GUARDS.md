# Coder Contracts and Guards

## Nicht ohne bewusste Migration verändern

1. Root-Starter-Namen: `start-microsoft.bat`, `start-apple.command`
2. Schutzstatus-Wortschatz: `reference_locked`, `project_fixed`, `project_provisional`, `open_experimental`
3. Drei Datenschichten: Projektdefaults, Referenzsätze, Profile
4. Kernartefakte pro Run: Manifest, Inputs, Results, Audit, Summary
5. Kern-API-Pfade: `/health`, `/run`, `/compare-runs`, `/benchmarks/series`, `/relations`, `/dependencies`

## Warum diese Guards existieren
Diese Guards verhindern, dass spätere Erweiterungen das Grundmodell der Software zerreißen. Sie dienen auch dazu, Regressionen für autonome Weiterentwicklung abzufangen.
