
# Anwendung: Forschungs-Testset für Standardmodell- und relationale Beziehungen

Diese Stufe der Software erzeugt zusätzliche Testberichte für Beziehungen zwischen Größen.

## Was geprüft wird

- wissenschaftlich bekannte Beziehungen,
- relationale angenommene Beziehungen,
- optionale Kompensationsterme,
- Sensitivitäten bei kleinen Änderungen.

## Wofür das nützlich ist

Damit wird sichtbar,

- welche Beziehungen stabil sind,
- welche nur im relationalen Modell auftreten,
- welche Zusatzterme wirklich etwas verbessern,
- und welche Felder besonders starken Einfluss auf andere Größen haben.

## Wichtige Dateien pro Run

- `outputs/research_suite.json`
- `reports/research_suite.md`

## Hinweis

Ein Testresultat bedeutet nicht automatisch „physikalisch bewiesen“. Es bedeutet zunächst: Die Software hat eine registrierte Beziehung mit dem aktiven Datensatz und den aktiven Referenzen geprüft.
