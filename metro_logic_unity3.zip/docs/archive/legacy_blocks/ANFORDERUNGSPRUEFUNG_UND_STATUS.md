# Anforderungsprüfung und Status

## Direkt adressierte Anforderungen in dieser Stufe

1. Start-Ebene für **Microsoft** und **Apple** ist namentlich gekennzeichnet.
2. Vollere GUI-Importfunktion mit Dateidialog und sichtbaren Fehlermeldungen.
3. Run-zu-Run-Vergleich direkt in der GUI.
4. Sichtbarere Sensitivitäts- und Einflussmatrix.
5. Mehr offiziell anerkannte Beziehungen in der Registry.
6. Mehr relationale Thread-Elemente direkt als Relation-Objekte.
7. Pflichtenheft aller Funktionseinheiten inklusive unveränderbarer Verträge.
8. Testbarkeit wissenschaftlich bekannter und relational angenommener Beziehungen.
9. API-Endpunkte für Run-Vergleich und Benchmark-Serien.

## Eingebaut in Software

- `start-microsoft.bat`
- `start-apple.command`
- GUI-Tab **Datasets** mit Dateidialog und Schema-Validierung
- GUI-Tab **Compare**
- GUI-Tab **Relations** mit Sensitivitäts-/Einflussdarstellung
- Registry-Dateien für offizielle und relationale Relationen
- Relation-Test-Framework in `relation_engine.py`
- Verträge in `configs/contracts.json`
- Tests gegen Verträge und Kernfunktionen

## Noch offen oder später auszubauen

- DE/EN-umschaltbare Tooltips für jede einzelne Zeile in der GUI
- Dateidialog mit Mehrformat-Unterstützung jenseits JSON
- noch dichtere offizielle Beziehungsabdeckung für das volle SM/SM+nu-Netz
- vollwertiger visueller Graph-Explorer mit Zoom/Pan und Klickinspektion
