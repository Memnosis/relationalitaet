# metro_logic Secure Block 2 — Spezifikation

## Ziel
Dieser Block erweitert den letzten gesicherten Hauptstand um eine interaktive Graph-Workbench in der GUI.

## Umgesetzt
- Umbenennung der Oberfläche und des Projektpakets zu `metro_logic`
- echter interaktiver Canvas auf Basis eines testbaren Graph-Modells
- Inspector für Knoten und Kanten
- bearbeitbare Verbindungen direkt aus der Oberfläche
- mehrfeldrige Kantenbearbeitung im Inspector
- visuelle Filterung nach Text
- Gruppierung der Graphansicht
- Minimap
- tourgesteuerte Testauslösung
- additive Beibehaltung der bisherigen DOI-/Paper-/Formula-Tabs
- API-Endpunkte für Graph-Views, Knoten, Kanten und Touren

## Nicht verändert
- bestehende Register- und Relationsebene
- Pipeline-Logik
- Audit-Logik
- bestehende DOI-/Provenienzschnittstellen
- bestehende Tests des Ankerstands

## Nächste offene Punkte
- vollwertiger Web-Canvas (z. B. React-Flow-Schicht)
- Drag-Persistenz für Knotenpositionen
- Knotenbearbeitung direkt im Inspector
- visuelle Gruppencontainer
- Minimap mit Viewport-Rahmen
