# REL_METRO_UNITY_REQUIREMENTS

## Produktanforderungen
1. Die Oberfläche muss browserbasiert und direkt aus dem Release nutzbar sein.
2. Jeder Hauptbereich muss im Header kurz erklärt werden.
3. Knoten, Kanten, Formeln, Touren, Tests und Doku müssen aus der Oberfläche erreichbar sein.
4. DE/EN-Umschaltung muss vorbereitet und im UI sichtbar sein.
5. Große Datenmengen müssen mindestens browsebar, filterbar und inspizierbar sein.

## Wissenschaftliche Anforderungen
6. Referenzdaten, partielle Daten und relationale Hypothesen müssen getrennt markiert werden.
7. Formeln und Paper müssen als eigene Registries vorliegen.
8. Standardmodell-, Atom- und Chemie-Objekte müssen über Relationen verknüpfbar sein.
9. Datengaps und Forschungsfragen müssen als Datenobjekte vorhanden sein.
10. Relationale Datensätze dürfen nur mit Kennzeichnung und Nachrechenbedarf verwendet werden.

## Qualitätsanforderungen
11. Releases dürfen kein `runs/`, keine `__pycache__`-Ordner und keine alten Archive enthalten.
12. Vollständigkeitsprüfung und ZIP-Verifikation müssen vor Auslieferung laufen.
13. Jede öffentliche Funktion soll in Matrix, Pflicht oder Test referenziert sein.
14. Kritische Module brauchen Verhaltenstests, nicht nur Import-Smoke-Tests.
15. Spezifikation, Anforderungen, Pflichten und Doku müssen im Release mitgeliefert werden.
