
# MASTER FINAL – Block A+B Test Plan

## Goals
1. keep the previously stable core green
2. verify chemistry integration into the pipeline
3. verify research summary and freedom balance outputs
4. verify relation registry remains merged and accessible
5. verify GUI chemistry tab code path does not break import

## Guardrails
- startup file names must remain `start-microsoft.bat` and `start-apple.command`
- existing relation and requirement tests must stay green
- run pipeline must still create reproducible run artifacts
