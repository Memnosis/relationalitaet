# Self-run relation report

```json
{
  "relation_count": 23,
  "sensitivity_inputs": [
    "Vcb",
    "Vcd",
    "Vcs",
    "Vub",
    "Vud",
    "Vus",
    "alpha_ideal_inv",
    "alpha_s_mz",
    "anchor_ln_R0_lp",
    "delta_alpha_had_5_mz",
    "gamma_family",
    "gap_cs",
    "gap_mu_e",
    "gap_tb",
    "kappa_w",
    "lambda_l",
    "lambda_q",
    "m_z_gev",
    "sigma_e",
    "sin2_theta_w_ideal",
    "top_mass_gev",
    "vev_gev",
    "wolf_A",
    "wolf_lambda"
  ],
  "benchmark_profiles": [
    "default_project",
    "sanity_shifted",
    "closure_inherited"
  ],
  "benchmark_comparisons": [
    "default_project_vs_sanity_shifted",
    "default_project_vs_closure_inherited"
  ]
}
```
