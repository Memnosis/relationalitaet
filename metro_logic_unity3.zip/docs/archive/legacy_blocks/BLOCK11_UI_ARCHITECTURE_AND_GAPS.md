# Block 11 UI Architecture and Gaps

## Umgesetzte Korrekturen
- sichtbarer Web-Canvas als Primäroberfläche
- Menüs mit erklärendem Headertext
- rechte Inspector-Spalte mit Formeln, QC-Labels und Beziehungsdetails
- Touren-, Test- und Doku-Zugriff im selben UI
- DE/EN Umschaltung mit UI-Texten und Daten-Fallbacks

## Noch offen für nächsten Block
- echter serverseitiger Persistenzpfad direkt aus dem Frontend
- tieferes Physics/Chemistry Browsing mit Tabellen- und Facettenansicht
- mathematische Renderung via MathJax/KaTeX oder serverseitig vorbereitete Formelansichten
- größere Graphen mit mehreren Views und Collapse/Expand-Gruppen
- klickbare Testausführung im Browser

## Mehrsprachigkeit
- UI-Texte getrennt von Fachinhalten
- Datensätze nutzen de/en Felder mit Fallback
- Formeln bleiben sprachneutral
