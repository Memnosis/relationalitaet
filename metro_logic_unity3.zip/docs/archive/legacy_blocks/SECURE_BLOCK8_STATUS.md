# Secure Block 8 Status

- Integrated older codebase with richer data registries
- Added release verification and completeness guard
- Added Standard Model, snippet, tour and research-gap access layers

- element inventory sees 118 via rel_chemistry registry; executable isotope registry currently remains at 86 and is flagged as a data-depth gap
