# METRO_LOGIC_UNITY1 STATUS

## Schwerpunkt
- Upload-Bundles für neue Knoten-Datenblätter und Kanten-Formeln
- Spezifikation, Anforderungen, Pflichten und UX auf Unity1 vereinheitlicht
- Browser-first Workbench mit Upload-Overlay, Schema-Vorschau und Bundle-Registry

## Neu
- src/metro_logic/bundle_ingest.py
- API-Endpunkte /bundle/schema, /bundle/registry, /bundle/import
- Browser-Tabs: node_sheets, edge_formulas, uploads
- Demo-Bundle unter configs/upload_bundles/
- Unity1-Dokumente und Upload-Bundle-Doku

## Qualitätsstand
- keine Cache-Artefakte im Release
- statische Workbench-Payload im Bundle vorhanden
- Upload-Bundles offline im Browser overlay-fähig
- Upload-Bundles serverseitig persistierbar via API
