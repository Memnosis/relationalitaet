# METRO_LOGIC_UNITY1 SPEC

## Ziel
Metro Logic Unity1 finalisiert die bisherigen Ansätze als browser-first Forschungsoberfläche mit integrierter Wissenschafts-, Doku- und Upload-Schicht.

## Neue Kernfähigkeit
Neue Datenblätter für Knoten und Formeln für Kanten können als JSON-Bundles direkt eingebracht werden.

## Bundle-Verhalten
- Offline: Upload in der Oberfläche blendet Bundles lokal als Overlay ein
- API: POST /bundle/import persistiert Bundles unter configs/upload_bundles/
- Registry: Upload-Bundles werden in configs/upload_bundle_registry.json zusammengefasst
- QC: Bundle-Inhalte werden als Erweiterungen markiert, bis sie validiert sind
