# Spezifikation: Graph-Workbench Block 1

## Eingeführte Register
- `graph_registry.json`
- `tour_registry.json`
- `snippet_registry.json`

## Neue Module
- `graph_workbench.py`

## API
- `GET /graph/views`
- `GET /graph/view?view_id=...`
- `GET /graph/tours`
- `GET /graph/snippets`

## UI-Sichtbarkeit
Block 1 liefert noch keinen vollgrafischen Canvas, aber bereits die semantische Grundlage:
- verfügbare Views
- verfügbare Touren
- verfügbare Snippets

## Anschlussfähigkeit
Block 1 dient als Grundlage für einen späteren interaktiven Canvas mit klickbaren Knoten und Kanten, Inspector und Testauslösung.
