# METRO_LOGIC_UNITY11_PFLICHTENHEFT

## Pflichtbereiche

### P1 Release-Hygiene
- Root enthält nur Kernordner und Startdateien.
- `.pytest_cache`, `runs`, `__pycache__`, `.pyc` und alte Release-Dateien fehlen.

### P2 Workbench UI
- Header mit Bereichserklärung und nächsten Schritten.
- Navigation gruppiert statt flach.
- Browser-Tabs für Kernobjekte.
- Canvas mit konsistenter Knoten-/Kantenbewegung.
- Inspector mit Details, Formeln, Beziehungen und Quellenhinweisen.

### P3 Wissenschaftliche Tiefe sichtbar machen
- Elemente, Isotope, Kräfte, Snippets, Formeln und Forschungsfragen sind browsebar.
- Qualitätslabels sind im UI sichtbar.
- Forschungsfragen sind mit Datengaps und nächsten Schritten verknüpft.

### P4 Dokumentation
- Hauptdokumente tragen den Namen `METRO_LOGIC_UNITY11_*`.
- Legacy-Dokumente liegen nur noch im Archiv.

### P5 Tests
- Release, Web, Vollständigkeit und Unity-Fassade sind testbar.
- Neue UI-Funktionen haben mindestens Smoke- oder Verhaltenstests.


## Upload-Bundles
- Neue Knoten-Datenblätter und Kanten-Formeln sind als JSON-Bundles vorgesehen.
- Die Workbench muss Bundle-Schema, Vorschau, Overlay und persistente API-Importe unterstützen.
- Bundle-Daten werden mit QC-Labels als Erweiterungen behandelt, bis sie validiert sind.
