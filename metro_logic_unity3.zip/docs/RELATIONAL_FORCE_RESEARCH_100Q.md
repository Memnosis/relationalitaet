# 100 Testfragen zur relationalen Erforschung der Grundkräfte

Dieses Dokument verankert ein Forschungsprogramm mit 100 Testfragen. Die operative Quelle ist `configs/force_research_questions_registry.json`.

## Ziel
- messbare Wechselwirkungen zwischen Standardmodell-Kräften strukturieren
- ausgehend von `rel0`, `rel1`, Schwarzes-Loch-Brücke und den derzeit robusteren relationalen Aussagen logische Zwischenstufen bilden
- Physik und Chemie gemeinsam als Beobachtungsschicht nutzen
- Softwareanforderungen direkt an blockierende Datenlücken koppeln

## Leitprinzipien
1. Jede Frage muss an mindestens ein messbares Observable gebunden sein.
2. Jede Frage muss die benötigten Datensätze nennen.
3. Jede Frage muss benennen, welche Softwarefähigkeit zur Bearbeitung nötig ist.
4. Fehlende Datensätze werden nicht versteckt, sondern priorisiert.
5. Jede Tour soll Forschungsmodus, Physikmodus und Chemiemodus erklären können.

## Themenblöcke
- Rel0/Rel1-Anker
- Elektroschwache Kopplung
- Starke Kraft und Übergänge
- Gravitative Brücke
- Atomare Observable
- Chemische Muster
- Schwellen und Skalen
- Extreme Materiezustände
- Messprotokolle und Falsifikation
- Softwarefähigkeiten und Forschungsprozess

## Wichtigste aktuelle Lücken
- normierte Skalenraster für laufende Kopplungen
- einheitliche Schwellen- und Übergangsmatrizen
- spektrale Brückendaten zwischen Atom, Chemie und Teilchenebene
- Bindungsenergie-Landschaften mit Kraftzerlegung
- dimensionlose Schwarzes-Loch-Ankerkandidaten als Registry
- Unsicherheits- und Provenienzfortpflanzung über relationale Ableitungsschritte

## Software, die metro_logic dafür leisten muss
- Graph-Layer für mehrere Kräfte gleichzeitig
- browsebarer Snippet- und Formel-Katalog
- Datengap-Dashboard
- relationale Solver-Hooks
- Unsicherheits-Pipeline
- Forschungs-Tourmodus
- Registry für extreme Zustände
- Chemie-Kraft-Zerlegung
- Falsifikations-Matrix
- rebuild- und release-sichere Auslieferung
