# Relation Test Framework

This bundle adds a dedicated relation layer on top of the sector pipeline.

## Main goals

1. Keep official/definitional relations separate from relational project relations.
2. Make each relation individually testable.
3. Generate perturbation-based sensitivity information.
4. Preserve observability through run artifacts, logs, API and GUI.

## New outputs

When relation tests are enabled, each run can write:
- `outputs/relation_results.json`
- `outputs/relation_test_suite.json`
- `outputs/sensitivity_matrix.json`
- `reports/relation_validation.md`
- `reports/sensitivity_summary.md`
