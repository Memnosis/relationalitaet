
# Standard Model assumptions and error probes

This document explains what the software currently means by testing the Standard Model.

## The software does not claim to falsify the SM automatically

Instead, it can probe:

1. whether officially registered relations are implemented and evaluated consistently,
2. whether current reference values satisfy the registered consistency relations within their declared interpretation,
3. whether relational overlays improve, worsen or leave unchanged selected observables,
4. whether optional compensators appear necessary inside the active relational layer.

## What counts as an "SM error probe" here

An SM error probe in rel_metro is currently one of the following:

- a consistency relation with visible deviation from its target,
- a mismatch between coded and registered relation structure,
- a sensitivity / propagation anomaly,
- or a case where a simpler or alternative relation layer performs at least as well as a more complicated one for the chosen observable set.

These are software-supported research diagnostics, not automatic claims against the Standard Model as a physical theory.
