# METRO_LOGIC_UNITY11_REQUIREMENTS

## Produktanforderungen

- Der Release-Root heißt `metro_logic_unity11`.
- Das Release enthält keine Cache-, Run- oder Build-Reste.
- Die Workbench ist offline aus `web/index.html` nutzbar.
- Jeder Hauptmenüpunkt erklärt Zweck, Möglichkeiten und nächste Schritte.
- Browser-Datensätze umfassen mindestens Elemente, Isotope, Kräfte, Snippets, Formeln, Fragen, Docs und Tests.
- Der Inspector zeigt bei Auswahl strukturierte Details und Qualitätsstatus.
- Formeln werden mit LaTeX, Inputs, Outputs, Code-Binding und Qualitätsklasse angezeigt.
- Touren und Tests sind in der Oberfläche direkt erreichbar.
- Dokumentation ist vereinheitlicht; alte Blocknamen dominieren die Hauptdoku nicht mehr.

## Architekturanforderungen

- `src/metro_logic` enthält die UI-orientierte Integrationsschicht.
- `src/rel_metro` enthält die wissenschaftlichen Kernmodule.
- `src/metro_logic_unity11` bietet eine schmale öffentliche Fassade.
- Die Workbench-Payload wird aus echten Konfigurationen und wissenschaftlichen Modulen erzeugt.

## Forschungsanforderungen

- Referenzdaten und relationale Hypothesen werden getrennt behandelt.
- Fehlende Datensätze werden als Datengaps sichtbar gemacht.
- Forschungsfragen bleiben mit Datenbedarf, logischem Zwischenschritt und relationalen Ankern verknüpft.


## Upload-Bundles
- Neue Knoten-Datenblätter und Kanten-Formeln sind als JSON-Bundles vorgesehen.
- Die Workbench muss Bundle-Schema, Vorschau, Overlay und persistente API-Importe unterstützen.
- Bundle-Daten werden mit QC-Labels als Erweiterungen behandelt, bis sie validiert sind.
