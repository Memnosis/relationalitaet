# Pflichtenheft: Visuelle Graph-Workbench (Block 1)

Dieses Pflichtenheft erweitert die bestehenden Pflichten additive und erhält die bisherige Schutz-, Test- und Provenienzlogik.

## Ziel
`rel_metro` erhält eine visuelle Graph-Schicht im Stil einer Workflow-/Relation-Workbench. Sie dient nicht als Ersatz der bestehenden Register, sondern als sichtbare Organisations- und Interaktionsschicht.

## Muss-Anforderungen
1. Es gibt eine `graph_registry` mit Knotentypen, Kantentypen und mindestens einer initialen Kernansicht.
2. Es gibt eine `tour_registry` mit mindestens zwei Touren:
   - Einführung in die Software
   - Einführung in die Neue Relationale
3. Es gibt eine `snippet_registry` für sichtbare Code-/Formelrepräsentationen.
4. Graph-Views, Touren und Snippets sind über API abrufbar.
5. Die Workbench ist in UI-Modellen und Text-/Statusansicht sichtbar.
6. Bestehende Pflichten und Tests bleiben gültig.

## Darf nicht verändert werden
- Statusklassen offizieller/projektinterner Werte dürfen nicht durch die Graphschicht umdefiniert werden.
- Die Graphschicht darf wissenschaftliche Provenienz nicht ersetzen, sondern nur sichtbar machen.
- Vorhandene API-Endpunkte und Testmatrix dürfen nicht brechen.
