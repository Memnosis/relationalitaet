# METRO_LOGIC_UNITY3_RELEASE_ASSURANCE

Dieses Release ist nur gültig, wenn alle folgenden Bedingungen erfüllt sind:
- ZIP formal intakt (`unzip -t`)
- Manifest vorhanden
- keine `runs/`, `__pycache__`, `.pytest_cache`, `.pyc` im Archiv
- Vollständigkeits-Guard grün
- Kernsuite aus Daten-, Payload-, API- und Release-Tests grün
