# METRO_LOGIC_UNITY1_SPEC

## Zweck

metro_logic_unity1 ist eine browser-first Forschungs-Workbench für Physik, Chemie und relationale Modelle. Das System verbindet visuelle Exploration, wissenschaftliche Registries, Formelpfade, Provenienz, Touren, Tests und Dokumentation.

## Systemkern

1. **Workbench UI**: Canvas, Browser, Inspector, Header-Hilfe, Sprachumschaltung, Touren- und Testzugang.
2. **Scientific Core**: Atom-, Isotopen-, Standardmodell-, Formel-, Paper- und Forschungsmodule.
3. **Research Separation**: harte Trennung zwischen Referenzdaten, partiellen Daten und relationalen Hypothesen.
4. **Release Discipline**: kleine Releases, keine Laufzeitartefakte, Manifest, Prüfsumme, Vollständigkeitsprüfung.

## Primäre Nutzerpfade

- Explore: Graph, Browser und schnelle Datenerkundung
- Physics: Kräfte, Träger, Formeln, Fragen
- Chemistry: Elemente, Isotope, Brücken zur Physik
- Relational: Forschungsfragen, Gap-Matrix, Ableitungsdruck
- Docs/Tests: Selbsterklärung, Qualitätssicherung, Einstieg in Forschung

## UI-Grundsätze

- sichtbare Oberfläche zuerst
- keine Überladung der ersten Ebene
- Header erklärt den aktuellen Bereich und nächste Schritte
- Hover, Klick und Inspector müssen alle zentralen Datenobjekte tragen
- Formeln sind erstklassige Objekte, keine Randnotiz
- Deutsch/Englisch mit klarer Trennung von UI-Text und Fachinhalten

## Qualitätsklassen

- `official_reference`
- `partial_registry`
- `derived`
- `relational_hypothesis`

Jeder Forschungs- und Formelpfad muss mindestens einer Qualitätsklasse zugeordnet sein.


## Upload-Bundles
- Neue Knoten-Datenblätter und Kanten-Formeln sind als JSON-Bundles vorgesehen.
- Die Workbench muss Bundle-Schema, Vorschau, Overlay und persistente API-Importe unterstützen.
- Bundle-Daten werden mit QC-Labels als Erweiterungen behandelt, bis sie validiert sind.
