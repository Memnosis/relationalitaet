# Relations and Dependency Tests

## Testgruppen

### Offizielle Beziehungen
- On-shell Weinberg-Beziehung
- inverser On-shell W-Zusammenhang
- CKM-Unitariät 1. und 2. Zeile
- Wolfenstein-Parameterisierung für `Vus` und `Vcb`

### Relationale Beziehungen
- Anchor -> delta alpha
- Anchor -> alpha inverse
- Anchor -> Higgs
- Anchor -> Weinberg
- Family scale -> Normgrößen
- Lambda inheritance -> W-Masse
- Closure bridge -> closure/bridge strength

## Diagnostik
- Existenztest der Relation im Register
- Ausführungstest der Relation
- Perturbationstest
- Einflussklassifikation
- Vergleich von Relation und Pipeline-Output
