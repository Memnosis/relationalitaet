# METRO_LOGIC_UNITY1_UX_GUIDE

## Prinzipien

- erst Orientierung, dann Tiefe
- kein flacher Menüfriedhof
- jedes Objekt hat Hover, Klick oder Detailpfad
- Header erklärt immer: Was ist das? Was kann ich hier tun? Was ist der nächste Schritt?

## Sprachumschaltung

UI-Texte werden getrennt von Fachdaten lokalisiert. Formeln bleiben sprachneutral. Datensätze tragen bevorzugt `*_de` und `*_en`, sonst greift ein Fallback.

## Browserlogik

- Explore: Überblick
- Physics/Chemistry/Relational: gefilterte Kontexte
- Inspector: eine Auswahl, viele Details
- Docs/Tests: jederzeit erreichbar, aber nicht im Weg


## Upload-Bundles
- Neue Knoten-Datenblätter und Kanten-Formeln sind als JSON-Bundles vorgesehen.
- Die Workbench muss Bundle-Schema, Vorschau, Overlay und persistente API-Importe unterstützen.
- Bundle-Daten werden mit QC-Labels als Erweiterungen behandelt, bis sie validiert sind.
