# Atom Bridge – nächste Softwarestufe

## Ziel

Diese Stufe führt eine erste Atom-/Element-Brücke in `rel_metro` ein. Sie bildet noch keine vollständige relationale Chemie, aber sie macht die klaren, bereits formulierbaren Teile softwarefähig:

- Elementregister
- atomare Zustandsobjekte
- provisorische relationale Zustandszuordnung
- Trends und erste Observable-Matrix
- explizite Kennzeichnung, was bereits berechnet, nur vorgeschlagen oder noch offen ist

## Enthalten

- `configs/atom_registry.json`
- `configs/atom_testset.json`
- `src/rel_metro/atom_registry.py`
- `src/rel_metro/atom_bridge.py`
- Tests für Laden, Zustandserzeugung und Trendmatrix

## Reifegrad

Diese Stufe ist absichtlich konservativ:

- keine Behauptung vollständiger relationaler Chemie
- keine vorgetäuschte Präzisionsmodellierung
- klare Trennung zwischen `compute_ready`, `provisional` und `roadmap_only`

## Nächster Ausbau danach

- Isotopenregister
- erste Stabilitätsregeln
- Elektron-/Valenzbrücke
- chemische Observable-Matrix
- GUI-Explorer für Elemente und atomare Zustände
