
# SM Relation Lab and Research Test Suite

This layer adds a research-oriented test architecture on top of the existing rel_metro relation and dependency system.

## Goals

- Execute officially recognized relation tests automatically.
- Execute relationally assumed relation tests automatically.
- Inventory explicit assumptions and givens.
- Probe whether optional compensators or relational shifts are necessary for better agreement with references.
- Produce machine-readable artefacts that can be consumed by GUI, API and regression tests.

## Main outputs

- `outputs/research_suite.json`
- `reports/research_suite.md`
- `outputs/relation_test_suite.json`
- `outputs/sensitivity_matrix.json`
- `outputs/influence_matrix.json`

## Included suites

1. Official relation validation
2. Relational relation validation
3. Assumption inventory
4. Necessity tests
5. Single-field perturbation / sensitivity matrix

## Scientific interpretation

This does **not** claim that the Standard Model is replaced. Instead, it exposes what the software currently treats as:

- officially constrained or definitional relations,
- relational overlays or hypotheses,
- optional compensators,
- open assumptions.

That makes later model changes testable instead of implicit.
