# METRO_LOGIC_UNITY21_DOCS_INDEX

## Kern
- `METRO_LOGIC_UNITY21_SPEC.md`
- `METRO_LOGIC_UNITY21_REQUIREMENTS.md`
- `METRO_LOGIC_UNITY21_PFLICHTENHEFT.md`
- `METRO_LOGIC_UNITY21_UX_GUIDE.md`
- `METRO_LOGIC_UNITY21_ARCHITECTURE.md`

## Forschung
- `RELATIONAL_FORCE_RESEARCH_100Q.md` (Archiv, historischer Forschungskern)
- `SM_RELATION_LAB.md` (Archiv)
- `ATOM_CHEMISTRY_REQUIREMENTS.md` (Archiv)

## Archiv
- `docs/archive/legacy_blocks/`


## Upload-Bundles
- Neue Knoten-Datenblätter und Kanten-Formeln sind als JSON-Bundles vorgesehen.
- Die Workbench muss Bundle-Schema, Vorschau, Overlay und persistente API-Importe unterstützen.
- Bundle-Daten werden mit QC-Labels als Erweiterungen behandelt, bis sie validiert sind.
